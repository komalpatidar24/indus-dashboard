import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import {
  Filter, Search, FileDown, RefreshCw, Settings, Eye, EyeOff, RotateCcw,
} from "lucide-react";
import { postRequest } from '../api/api';
import {
  IconButton, Tooltip, Snackbar, Alert, Button, Menu, MenuItem,
  Box, Typography, Paper, TextField, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Checkbox, Stack, CircularProgress,
  InputAdornment, ListItemIcon, ListItemText, Autocomplete, Chip,
} from '@mui/material';
import * as XLSX from 'xlsx';

const fmt = (v) => (v === null || v === undefined || v === "" ? "-" : v);

const formatDate = (dateString) => {
  if (!dateString || dateString === "-" || dateString === "null") return "-";
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "-";
    return [
      String(date.getDate()).padStart(2, "0"),
      String(date.getMonth() + 1).padStart(2, "0"),
      date.getFullYear(),
    ].join("-");
  } catch { return "-"; }
};

const extractContentsID = (row) => {
  const val =
    row.JobBookingJobCardContentsID ??
    row.jobBookingJobCardContentsID ??
    row.JobBookingJobCardContentID  ??
    row.jobBookingJobCardContentID  ??
    row.ContentsID                  ??
    row.contentsID;
  return val != null ? String(val).trim() : null;
};

const getStatusStyle = (status) => {
  if (!status || status === "-") return { text: "-", color: "#6b7280" };
  const s = status.toLowerCase().trim();
  let color = "#6b7280";
  if      (s === "done" || s === "completed")                       color = "#10b981";
  else if (s === "pending")                                         color = "#eab308";
  else if (["in progress", "in process", "wip"].includes(s))       color = "#3b82f6";
  else if (s === "cancelled" || s === "cancel" || s === "rejected") color = "#ef4444";
  return { text: status, color };
};

const StatusCell = ({ status }) => {
  const { text, color } = getStatusStyle(status);
  return (
    <Typography sx={{ color, fontWeight: 700, fontSize: "0.73rem", whiteSpace: "nowrap" }}>
      {text}
    </Typography>
  );
};

const DaysDelayCell = ({ value }) => {
  const num = parseFloat(value);
  let color = "#6b7280", display = "-";
  if (value == null || value === "" || value === "-") {
    display = "-";
  } else if (!isNaN(num)) {
    if (num <= 0) { display = "On Time"; color = "#10b981"; }
    else          { display = `${num} day${num !== 1 ? "s" : ""}`; color = "#ef4444"; }
  } else {
    display = String(value); color = "#6b7280";
  }
  return (
    <Typography sx={{ color, fontWeight: 700, fontSize: "0.73rem", textAlign: "center", whiteSpace: "nowrap" }}>
      {display}
    </Typography>
  );
};

const STEPS = [
  {
    id: "step1", label: "Step 1", name: "PAPER/REEL INDENT CREATION",
    api: "GetPaperReelIndent", bgColor: "#fce4ec",
    fields: { planDate: "PlanDate", actualDate: "IndentDate", daysDelay: "Delays", status: "Status", docNo: "IndentNo", docDate: "IndentDate" },
  },
  {
    id: "step2", label: "Step 2", name: "PURCHASE REQUISITION",
    api: "GetPurchaseRequisition", bgColor: "#f3e5f5",
    fields: { planDate: "PlanDate", actualDate: "RequisitionDate", daysDelay: "Delays", status: "Status", docNo: "RequisitionNo", docDate: "RequisitionDate" },
  },
  {
    id: "step3", label: "Step 3", name: "PURCHASE ORDER",
    api: "GetPurchaseOrder", bgColor: "#e3f2fd",
    fields: { planDate: "PlanDate", actualDate: "PurchaseOrderDate", daysDelay: "Delays", status: "Status", docNo: "PurchaseOrderNo", docDate: "PurchaseOrderDate" },
  },
  {
    id: "step4", label: "Step 4", name: "FMS GRN",
    api: "GetFMSGRN", bgColor: "#e8f5e9",
    fields: { planDate: "PlanDate", actualDate: "GRNDate", daysDelay: "Delays", status: "Status", docNo: "GRNNo", docDate: "GRNDate" },
  },
  {
    id: "step5", label: "Step 5", name: "ITEM ISSUE",
    api: "GetItemIssue", bgColor: "#fff8e1",
    fields: { planDate: "PlanDate", actualDate: "IssueDate", daysDelay: "Delays", status: "Status", docNo: "IssueNo", docDate: "IssueDate" },
  },
];

const STEP_COLS = [
  { key: "planDate",   label: "Plan Date"   },
  { key: "actualDate", label: "Actual Date" },
  { key: "daysDelay",  label: "Days Delay"  },
  { key: "status",     label: "Status"      },
  { key: "docNo",      label: "Doc No"      },
  { key: "docDate",    label: "Doc Date"    },
];

// CHANGE 1: "Size W"->"Size W Inch", "Size L"->"Size L Inch"
// CHANGE 2: Added JobBookingDate ("Job Date") column
// CHANGE 5: Added CustomerName column after JobName
const PAPER_BASE_COLS = [
  { key: "JobCardContentNo", label: "Job No",        apiKey: "JobCardContentNo" },
  { key: "JobName",          label: "Job Name",      apiKey: "JobName"          },
  { key: "CustomerName",     label: "Customer Name", apiKey: "CustomerName"     },
  { key: "JobBookingDate",   label: "Job Date",      apiKey: "JobBookingDate"   },
  { key: "PlanContName",     label: "Content Name",  apiKey: "PlanContName"     },
  { key: "ItemName",         label: "Item Name",     apiKey: "ItemName"         },
  { key: "SizeW",            label: "Size W Inch",   apiKey: "SizeW"            },
  { key: "SizeL",            label: "Size L Inch",   apiKey: "SizeL"            },
  { key: "GSM",              label: "GSM",           apiKey: "GSM"              },
  { key: "Quality",          label: "Quality",       apiKey: "Quality"          },
  { key: "Quantity",         label: "Quantity",      apiKey: "Quantity"         },
  { key: "QuantityKG",       label: "Qty (KG)",      apiKey: "QuantityKG"       },
  { key: "Reams",            label: "Reams",         apiKey: "Reams"            },
];

const ColumnResizer = ({ columnKey, resizeRef, forceUpdate }) => {
  const isActive = resizeRef.current.isResizing && resizeRef.current.columnKey === columnKey;
  return (
    <Box
      onMouseDown={(e) => {
        e.preventDefault(); e.stopPropagation();
        resizeRef.current = {
          ...resizeRef.current,
          isResizing: true,
          columnKey,
          startX    : e.clientX,
          startWidth: resizeRef.current.widths[columnKey] ?? 120,
        };
        document.body.style.cursor     = "col-resize";
        document.body.style.userSelect = "none";
        forceUpdate({});
      }}
      sx={{
        position: "absolute", right: -2, top: 0,
        width: "4px", height: "100%",
        cursor: "col-resize", userSelect: "none", zIndex: 100,
        bgcolor: isActive ? "#3b82f6" : "transparent",
        "&:hover": { bgcolor: "#3b82f6" },
      }}
    />
  );
};

const PaperFMS = () => {
  const [paperRows, setPaperRows] = useState([]);
  const [stepData,  setStepData]  = useState(Object.fromEntries(STEPS.map((s) => [s.id, []])));
  const [loading,   setLoading]   = useState(false);

  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // CHANGE 3: Extended filters with customerName + 5 doc-number filters
  const [filters, setFilters] = useState({
    JobCardContentNo: "",
    status          : "",
    fromDate        : "",
    toDate          : "",
    customerName    : "",
    indentNo        : "",
    requisitionNo   : "",
    orderNo         : "",
    grnNo           : "",
    issueNo         : "",
  });

  const [uniqueJobCardContentNos, setUniqueJobCardContentNos] = useState([]);
  const [uniqueStatuses,          setUniqueStatuses]          = useState([]);
  const [uniqueCustomerNames,     setUniqueCustomerNames]     = useState([]);

  const [selected,      setSelected]      = useState([]);
  const [exportAnchor,  setExportAnchor]  = useState(null);
  const [colMenuAnchor, setColMenuAnchor] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "success" });

  const row1Ref = useRef(null);
  const [row1Height, setRow1Height] = useState(72);

  // CHANGE 2+5: Added CustomerName, JobBookingDate
  const [visibleColumns, setVisibleColumns] = useState({
    JobCardContentNo: true,
    JobName         : true,
    CustomerName    : true,
    JobBookingDate  : true,
    PlanContName    : true,
    Quality         : true,
    ItemName        : true,
    SizeW           : true,
    SizeL           : true,
    GSM             : true,
    Quantity        : true,
    QuantityKG      : true,
    Reams           : true,
    step1: true, step2: true, step3: true, step4: true, step5: true,
  });

  // CHANGE 2+5: Added CustomerName, JobBookingDate widths
  const initWidths = () => {
    const w = {
      checkbox        : 50,
      JobCardContentNo: 160,
      JobName         : 180,
      CustomerName    : 160,
      JobBookingDate  : 100,
      PlanContName    : 120,
      Quality         : 150,
      ItemName        : 190,
      SizeW           : 90,
      SizeL           : 90,
      GSM             : 70,
      Quantity        : 90,
      QuantityKG      : 90,
      Reams           : 80,
    };
    STEPS.forEach((s) => STEP_COLS.forEach((c) => {
      w[`${c.key}-${s.id}`] =
        c.key === "docNo"     ? 150 :
        c.key === "daysDelay" ? 90  :
        c.key === "status"    ? 100 : 110;
    }));
    return w;
  };

  const [colWidths, setColWidths] = useState(initWidths);
  const resizeRef = useRef({ isResizing: false, columnKey: null, startX: 0, startWidth: 0, widths: colWidths });
  resizeRef.current.widths = colWidths;
  const [, forceUpdate] = useState({});

  const handleMouseMove = useCallback((e) => {
    if (!resizeRef.current.isResizing) return;
    const { columnKey, startX, startWidth } = resizeRef.current;
    setColWidths((p) => ({ ...p, [columnKey]: Math.max(50, startWidth + (e.clientX - startX)) }));
  }, []);

  const handleMouseUp = useCallback(() => {
    if (resizeRef.current.isResizing) {
      resizeRef.current.isResizing   = false;
      document.body.style.cursor     = "";
      document.body.style.userSelect = "";
      forceUpdate({});
    }
  }, []);

  useEffect(() => {
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup",   handleMouseUp);
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup",   handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  useEffect(() => {
    const el = row1Ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => {
      const h = entry.borderBoxSize?.[0]?.blockSize ?? entry.contentRect.height;
      if (h > 0) setRow1Height(Math.ceil(h));
    });
    ro.observe(el);
    setRow1Height(Math.ceil(el.getBoundingClientRect().height) || 72);
    return () => ro.disconnect();
  }, []);

  const toArr = (r) => {
    let d = Array.isArray(r) ? r : (r?.data ?? r);
    if (!Array.isArray(d)) d = d?.data ?? [];
    return Array.isArray(d) ? d : [];
  };

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [paperRes, ...stepResults] = await Promise.all([
        postRequest("GetPaperDetail", {}),
        ...STEPS.map((s) => postRequest(s.api, {}).catch(() => [])),
      ]);

      const paperData = toArr(paperRes);
      setPaperRows(paperData);
      setUniqueJobCardContentNos(
        [...new Set(paperData.map((r) => r.JobCardContentNo).filter(Boolean))].sort()
      );
      // CHANGE 3+5: customer name dropdown
      setUniqueCustomerNames(
        [...new Set(paperData.map((r) => r.CustomerName).filter(Boolean))].sort()
      );

      const updates     = {};
      const allStatuses = new Set();
      STEPS.forEach((s, idx) => {
        const rows = toArr(stepResults[idx]);
        updates[s.id] = rows;
        rows.forEach((r) => {
          const st = r.Status ?? r.status ?? r.currentStatus;
          if (st) allStatuses.add(st);
        });
      });
      setStepData(updates);
      setUniqueStatuses([...allStatuses].sort());

      console.log("PaperDetail keys:", paperData.length > 0 ? Object.keys(paperData[0]) : []);
      STEPS.forEach((s, idx) => {
        const rows = toArr(stepResults[idx]);
        if (rows.length > 0) {
          console.log(`${s.api} keys:`, Object.keys(rows[0]));
        }
      });
      showSnackbar("Data loaded successfully", "success");
    } catch (e) {
      console.error("fetchAll:", e);
      showSnackbar("Failed to load data", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchAll(); }, []); // eslint-disable-line

  const showSnackbar = (msg, sev = "success") =>
    setSnackbar({ open: true, message: msg, severity: sev });

  const stepMaps = useMemo(() => {
    const maps = {};
    STEPS.forEach((s) => {
      const map = {};
      (stepData[s.id] ?? []).forEach((row) => {
        const id = extractContentsID(row);
        if (id && !map[id]) map[id] = row;
      });
      maps[s.id] = map;
    });
    return maps;
  }, [stepData]);

  // CHANGE 3: filteredRows with customerName + 5 doc-number filters
  const filteredRows = useMemo(() => {
    return paperRows.filter((row) => {
      const q = searchQuery.toLowerCase();
      const matchSearch = !searchQuery ||
        String(row.JobCardContentNo ?? "").toLowerCase().includes(q) ||
        String(row.JobName          ?? "").toLowerCase().includes(q) ||
        String(row.CustomerName     ?? "").toLowerCase().includes(q) ||
        String(row.ItemName         ?? "").toLowerCase().includes(q) ||
        String(row.PlanContName     ?? "").toLowerCase().includes(q);

      const matchJobNo = !filters.JobCardContentNo ||
        String(row.JobCardContentNo ?? "").trim().toUpperCase() ===
        filters.JobCardContentNo.trim().toUpperCase();

      const matchStatus = !filters.status ||
        String(row.Status ?? "").toLowerCase() === filters.status.toLowerCase();

      const matchCustomer = !filters.customerName ||
        String(row.CustomerName ?? "").toLowerCase().includes(filters.customerName.toLowerCase());

      const rowDate = row.JobBookingDate ?? row.PlanDate;
      const matchDate =
        (!filters.fromDate || new Date(rowDate) >= new Date(filters.fromDate)) &&
        (!filters.toDate   || new Date(rowDate) <= new Date(filters.toDate));

      const contId = extractContentsID(row);
      const matchIndent = !filters.indentNo || (() => {
        const sr = contId ? (stepMaps["step1"]?.[contId] ?? {}) : {};
        return String(sr.IndentNo ?? "").toLowerCase().includes(filters.indentNo.toLowerCase());
      })();
      const matchRequisition = !filters.requisitionNo || (() => {
        const sr = contId ? (stepMaps["step2"]?.[contId] ?? {}) : {};
        return String(sr.RequisitionNo ?? "").toLowerCase().includes(filters.requisitionNo.toLowerCase());
      })();
      const matchOrder = !filters.orderNo || (() => {
        const sr = contId ? (stepMaps["step3"]?.[contId] ?? {}) : {};
        return String(sr.PurchaseOrderNo ?? "").toLowerCase().includes(filters.orderNo.toLowerCase());
      })();
      const matchGRN = !filters.grnNo || (() => {
        const sr = contId ? (stepMaps["step4"]?.[contId] ?? {}) : {};
        return String(sr.GRNNo ?? "").toLowerCase().includes(filters.grnNo.toLowerCase());
      })();
      const matchIssue = !filters.issueNo || (() => {
        const sr = contId ? (stepMaps["step5"]?.[contId] ?? {}) : {};
        return String(sr.IssueNo ?? "").toLowerCase().includes(filters.issueNo.toLowerCase());
      })();

      return matchSearch && matchJobNo && matchStatus && matchCustomer &&
             matchDate && matchIndent && matchRequisition && matchOrder && matchGRN && matchIssue;
    });
  }, [paperRows, filters, searchQuery, stepMaps]);

  const handleFilterChange = (name, val) => setFilters((p) => ({ ...p, [name]: val }));
  const clearFilters = () => {
    setFilters({
      JobCardContentNo: "", status: "", fromDate: "", toDate: "",
      customerName: "", indentNo: "", requisitionNo: "", orderNo: "", grnNo: "", issueNo: "",
    });
    setSearchQuery("");
  };

  const handleSelectAll = (e) =>
    setSelected(e.target.checked ? filteredRows.map((_, i) => i) : []);
  const handleSelectRow = (i) =>
    setSelected((p) => p.includes(i) ? p.filter((x) => x !== i) : [...p, i]);

  // CHANGE 4: Complete export with CustomerName, JobDate, renamed sizes, all step doc nos + dates
  const handleExport = (type) => {
    const rows = selected.length > 0
      ? filteredRows.filter((_, i) => selected.includes(i))
      : filteredRows;
    if (!rows.length) { showSnackbar("No data to export", "warning"); return; }

    const flat = rows.map((r) => {
      const contId = extractContentsID(r);
      const s1 = contId ? (stepMaps["step1"]?.[contId] ?? {}) : {};
      const s2 = contId ? (stepMaps["step2"]?.[contId] ?? {}) : {};
      const s3 = contId ? (stepMaps["step3"]?.[contId] ?? {}) : {};
      const s4 = contId ? (stepMaps["step4"]?.[contId] ?? {}) : {};
      const s5 = contId ? (stepMaps["step5"]?.[contId] ?? {}) : {};
      return {
        "Job No"                    : fmt(r.JobCardContentNo),
        "Job Name"                  : fmt(r.JobName),
        "Customer Name"             : fmt(r.CustomerName),
        "Job Date"                  : formatDate(r.JobBookingDate),
        "Content Name"              : fmt(r.PlanContName),
        "Item Name"                 : fmt(r.ItemName),
        "Size W Inch"               : fmt(r.SizeW),
        "Size L Inch"               : fmt(r.SizeL),
        "GSM"                       : fmt(r.GSM),
        "Quality"                   : fmt(r.Quality),
        "Quantity"                  : fmt(r.Quantity),
        "Qty (KG)"                  : fmt(r.QuantityKG),
        "Reams"                     : fmt(r.Reams),
        "Indent No"                 : fmt(s1.IndentNo),
        "Indent Plan Date"          : formatDate(s1.PlanDate),
        "Indent Actual Date"        : formatDate(s1.IndentDate),
        "Indent Days Delay"         : fmt(s1.Delays),
        "Indent Status"             : fmt(s1.Status),
        "Requisition No"            : fmt(s2.RequisitionNo),
        "Requisition Plan Date"     : formatDate(s2.PlanDate),
        "Requisition Actual Date"   : formatDate(s2.RequisitionDate),
        "Requisition Days Delay"    : fmt(s2.Delays),
        "Requisition Status"        : fmt(s2.Status),
        "Purchase Order No"         : fmt(s3.PurchaseOrderNo),
        "Purchase Order Plan Date"  : formatDate(s3.PlanDate),
        "Purchase Order Actual Date": formatDate(s3.PurchaseOrderDate),
        "Purchase Order Days Delay" : fmt(s3.Delays),
        "Purchase Order Status"     : fmt(s3.Status),
        "GRN No"                    : fmt(s4.GRNNo),
        "GRN Plan Date"             : formatDate(s4.PlanDate),
        "GRN Actual Date"           : formatDate(s4.GRNDate),
        "GRN Days Delay"            : fmt(s4.Delays),
        "GRN Status"                : fmt(s4.Status),
        "Issue No"                  : fmt(s5.IssueNo),
        "Issue Plan Date"           : formatDate(s5.PlanDate),
        "Issue Actual Date"         : formatDate(s5.IssueDate),
        "Issue Days Delay"          : fmt(s5.Delays),
        "Issue Status"              : fmt(s5.Status),
      };
    });

    const ws = XLSX.utils.json_to_sheet(flat);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "PaperFMS");
    const dateStr = new Date().toISOString().split("T")[0];
    if (type === "excel") {
      XLSX.writeFile(wb, `PaperFMS_${dateStr}.xlsx`);
      showSnackbar("Exported to Excel", "success");
    } else {
      const csv  = XLSX.utils.sheet_to_csv(ws);
      const blob = new Blob([csv], { type: "text/csv" });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a"); a.href = url;
      a.download = `PaperFMS_${dateStr}.csv`; a.click();
      showSnackbar("Exported to CSV", "success");
    }
    setExportAnchor(null);
  };

  const baseColSpan = useMemo(() =>
    1 + PAPER_BASE_COLS.filter((c) => visibleColumns[c.key]).length,
  [visibleColumns]);

  const renderStepCell = (step, col, stepRow, hasIssueNo = false) => {
    const ck       = `${col.key}-${step.id}`;
    const apiField = step.fields[col.key];
    const raw      = stepRow[apiField];
    const isLast   = col.key === "docDate";
    const cellSx = {
      bgcolor     : step.bgColor,
      minWidth    : colWidths[ck],
      maxWidth    : colWidths[ck],
      fontSize    : "0.75rem",
      overflow    : "hidden",
      textOverflow: "ellipsis",
      whiteSpace  : "nowrap",
      borderRight : isLast ? "2px solid #94a3b8" : undefined,
      padding     : "4px 8px",
    };
    const stepDocField = step.fields["docNo"];
    const stepDocVal   = stepRow[stepDocField];
    const stepHasNoDoc = !stepDocVal || String(stepDocVal).trim() === "" || String(stepDocVal).trim() === "-";
    const showAsDone   = hasIssueNo && step.id !== "step5" && stepHasNoDoc;

    if (col.key === "planDate" || col.key === "actualDate" || col.key === "docDate") {
      return <TableCell key={ck} sx={cellSx}>{showAsDone ? "-" : formatDate(raw)}</TableCell>;
    }
    if (col.key === "daysDelay") {
      return (
        <TableCell key={ck} align="center" sx={cellSx}>
          <DaysDelayCell value={showAsDone ? null : raw} />
        </TableCell>
      );
    }
    if (col.key === "status") {
      return (
        <TableCell key={ck} align="center" sx={cellSx}>
          <StatusCell status={showAsDone ? "Done" : fmt(raw)} />
        </TableCell>
      );
    }
    if (col.key === "docNo") {
      const display = showAsDone ? "-" : fmt(raw);
      return (
        <TableCell key={ck} sx={{ ...cellSx, fontWeight: 600, color: display === "-" ? "#94a3b8" : "#0f766e" }}>
          {display}
        </TableCell>
      );
    }
    return <TableCell key={ck} sx={cellSx}>{fmt(raw)}</TableCell>;
  };

  return (
    <Box sx={{ p: 2, bgcolor: "#f8fafc", minHeight: "100vh", position: "relative" }}>
      {loading && (
        <Box sx={{ position: "fixed", inset: 0, bgcolor: "rgba(255,255,255,0.15)", backdropFilter: "blur(1px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999 }}>
          <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 1.5 }}>
            <CircularProgress size={40} thickness={4} sx={{ color: "#0f766e" }} />
            <Typography variant="body2" sx={{ fontWeight: 600, color: "#0f766e" }}>Loading...</Typography>
          </Box>
        </Box>
      )}

      <Typography variant="caption" sx={{ display: "block", textAlign: "center", letterSpacing: 4, fontWeight: 700, color: "text.secondary", mb: 3 }}>
        PAPER FMS
      </Typography>

      <Paper elevation={2} sx={{ borderRadius: 2, overflow: "hidden" }}>
        {/* Toolbar */}
        <Box sx={{ p: 1.5, bgcolor: "#f1f5f9", borderBottom: "1px solid #e2e8f0" }}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Tooltip title="Toggle Filters">
              <IconButton size="small" onClick={() => setShowFilters(!showFilters)} sx={{ border: "1px solid #cbd5e1", borderRadius: 1, bgcolor: showFilters ? "#0f766e" : "white", color: showFilters ? "white" : "inherit" }}>
                <Filter size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Column Settings">
              <IconButton size="small" onClick={(e) => setColMenuAnchor(e.currentTarget)} sx={{ border: "1px solid #cbd5e1", borderRadius: 1, bgcolor: "white" }}>
                <Settings size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Refresh">
              <IconButton size="small" onClick={fetchAll} disabled={loading} sx={{ border: "1px solid #cbd5e1", borderRadius: 1, bgcolor: "white" }}>
                <RefreshCw size={18} style={{ animation: loading ? "spin 1s linear infinite" : "none", transformOrigin: "center" }} />
              </IconButton>
            </Tooltip>
            <TextField size="small" placeholder="Search job, item, content..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} sx={{ bgcolor: "white", width: 260 }} InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} /></InputAdornment> }} />
            <Box sx={{ flexGrow: 1 }} />
            <Button size="small" variant="contained" startIcon={<FileDown size={16} />} onClick={(e) => setExportAnchor(e.currentTarget)} sx={{ bgcolor: "#3b82f6", borderRadius: 1 }}>EXPORT</Button>
            <Chip label={`${filteredRows.length} / ${paperRows.length} Records`} size="small" sx={{ bgcolor: filteredRows.length === paperRows.length ? "#10b981" : "#3b82f6", color: "white", fontWeight: 700, fontSize: "0.75rem", height: 28 }} />
          </Stack>
        </Box>

        <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>

        {/* Export menu */}
        <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)} onClose={() => setExportAnchor(null)}>
          <MenuItem onClick={() => handleExport("excel")}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to Excel</ListItemText></MenuItem>
          <MenuItem onClick={() => handleExport("csv")}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to CSV</ListItemText></MenuItem>
        </Menu>

        {/* Column visibility menu */}
        <Menu anchorEl={colMenuAnchor} open={Boolean(colMenuAnchor)} onClose={() => setColMenuAnchor(null)}>
          <Typography variant="overline" sx={{ px: 2, fontWeight: 900 }}>Paper Detail</Typography>
          {PAPER_BASE_COLS.map(({ key, label }) => (
            <MenuItem key={key} onClick={() => setVisibleColumns((p) => ({ ...p, [key]: !p[key] }))} sx={{ py: 0.5 }}>
              <ListItemIcon>{visibleColumns[key] ? <Eye size={16} /> : <EyeOff size={16} />}</ListItemIcon>
              <ListItemText primary={label} primaryTypographyProps={{ fontSize: "0.75rem" }} />
              <Checkbox size="small" checked={!!visibleColumns[key]} color="primary" />
            </MenuItem>
          ))}
          <Typography variant="overline" sx={{ px: 2, fontWeight: 900, display: "block", mt: 1 }}>Steps</Typography>
          {STEPS.map((s) => (
            <MenuItem key={s.id} onClick={() => setVisibleColumns((p) => ({ ...p, [s.id]: !p[s.id] }))} sx={{ py: 0.5 }}>
              <ListItemIcon>{visibleColumns[s.id] ? <Eye size={16} /> : <EyeOff size={16} />}</ListItemIcon>
              <ListItemText primary={`${s.label} — ${s.name}`} primaryTypographyProps={{ fontSize: "0.75rem" }} />
              <Checkbox size="small" checked={!!visibleColumns[s.id]} color="primary" />
            </MenuItem>
          ))}
        </Menu>

        {/* CHANGE 3: Filters panel */}
        {showFilters && (
          <Box sx={{ p: 1.5, bgcolor: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
              {/* Job No — auto-width so long IDs are readable */}
              <Autocomplete freeSolo options={uniqueJobCardContentNos}
                value={filters.JobCardContentNo}
                onChange={(_, v)      => handleFilterChange("JobCardContentNo", v || "")}
                onInputChange={(_, v) => handleFilterChange("JobCardContentNo", v || "")}
                renderInput={(p) => <TextField {...p} label="Job No" size="small" />}
                sx={{ minWidth: 140, "& .MuiInputBase-root": { minWidth: 140 } }}
                componentsProps={{ popper: { style: { width: "auto", minWidth: 220 } } }}
              />
              {/* Customer Name — selectable + free-type (CHANGE 3+5) */}
              <Autocomplete freeSolo options={uniqueCustomerNames}
                value={filters.customerName}
                onChange={(_, v)      => handleFilterChange("customerName", v || "")}
                onInputChange={(_, v) => handleFilterChange("customerName", v || "")}
                renderInput={(p) => <TextField {...p} label="Customer Name" size="small" />}
                sx={{ width: 190 }}
                componentsProps={{ popper: { style: { width: "auto", minWidth: 230 } } }}
              />
              <Autocomplete freeSolo options={uniqueStatuses}
                value={filters.status}
                onChange={(_, v)      => handleFilterChange("status", v || "")}
                onInputChange={(_, v) => handleFilterChange("status", v || "")}
                renderInput={(p) => <TextField {...p} label="Status" size="small" />}
                sx={{ width: 130 }}
              />
              <TextField label="From Date" type="date" size="small" InputLabelProps={{ shrink: true }} value={filters.fromDate} onChange={(e) => handleFilterChange("fromDate", e.target.value)} sx={{ width: 150 }} />
              <TextField label="To Date" type="date" size="small" InputLabelProps={{ shrink: true }} value={filters.toDate} onChange={(e) => handleFilterChange("toDate", e.target.value)} sx={{ width: 150 }} />
              {/* Doc-number filters — colour-coded to match step colours */}
              <TextField label="Indent No" size="small" value={filters.indentNo} onChange={(e) => handleFilterChange("indentNo", e.target.value)} sx={{ width: 130, "& .MuiOutlinedInput-root": { bgcolor: "#fce4ec" } }} />
              <TextField label="Requisition No" size="small" value={filters.requisitionNo} onChange={(e) => handleFilterChange("requisitionNo", e.target.value)} sx={{ width: 148, "& .MuiOutlinedInput-root": { bgcolor: "#f3e5f5" } }} />
              <TextField label="Order No" size="small" value={filters.orderNo} onChange={(e) => handleFilterChange("orderNo", e.target.value)} sx={{ width: 120, "& .MuiOutlinedInput-root": { bgcolor: "#e3f2fd" } }} />
              <TextField label="GRN No" size="small" value={filters.grnNo} onChange={(e) => handleFilterChange("grnNo", e.target.value)} sx={{ width: 110, "& .MuiOutlinedInput-root": { bgcolor: "#e8f5e9" } }} />
              <TextField label="Issue No" size="small" value={filters.issueNo} onChange={(e) => handleFilterChange("issueNo", e.target.value)} sx={{ width: 110, "& .MuiOutlinedInput-root": { bgcolor: "#fff8e1" } }} />
              <Button size="small" color="error" onClick={clearFilters} title="Clear all filters"><RotateCcw size={22} strokeWidth={3} /></Button>
            </Stack>
          </Box>
        )}

        {/* Table */}
        <TableContainer sx={{ maxHeight: "75vh", overflow: "auto", "&::-webkit-scrollbar": { display: "none" }, scrollbarWidth: "none", msOverflowStyle: "none" }}>
          <Table size="small" stickyHeader sx={{ borderCollapse: "separate" }}>
            <TableHead>
              {/* Row 1 – group headers */}
              <TableRow ref={row1Ref}>
                <TableCell colSpan={baseColSpan} align="center" sx={{ bgcolor: "#cbd5e1", fontWeight: 700, fontSize: "0.7rem", borderBottom: "2px solid #94a3b8", padding: "8px", whiteSpace: "nowrap", position: "sticky", top: 0, zIndex: 4 }}>
                  📋 PAPER DETAIL
                </TableCell>
                {STEPS.map((step) => !visibleColumns[step.id] ? null : (
                  <TableCell key={step.id} colSpan={STEP_COLS.length} align="center" sx={{ bgcolor: step.bgColor, fontWeight: 700, borderRight: "2px solid #94a3b8", borderBottom: "2px solid #94a3b8", padding: "6px 4px", position: "sticky", top: 0, zIndex: 4 }}>
                    <Typography variant="caption" sx={{ fontWeight: 900, color: "#0f766e", display: "block", fontSize: "0.6rem" }}>{step.label}</Typography>
                    <Typography variant="caption" sx={{ fontWeight: 800, display: "block", fontSize: "0.68rem" }}>{step.name}</Typography>
                  </TableCell>
                ))}
              </TableRow>

              {/* Row 2 – column headers */}
              <TableRow>
                <TableCell padding="checkbox" sx={{ bgcolor: "#f1f5f9", minWidth: colWidths.checkbox, maxWidth: colWidths.checkbox, borderRight: "1px solid #e0e0e0", position: "sticky", top: row1Height, zIndex: 3 }}>
                  <Box sx={{ position: "relative", width: "100%", height: "100%" }}>
                    <Checkbox size="small" color="primary" onChange={handleSelectAll} checked={selected.length === filteredRows.length && filteredRows.length > 0} />
                    <ColumnResizer columnKey="checkbox" resizeRef={resizeRef} forceUpdate={forceUpdate} />
                  </Box>
                </TableCell>
                {PAPER_BASE_COLS.map(({ key, label }) => !visibleColumns[key] ? null : (
                  <TableCell key={key} sx={{ bgcolor: "#f1f5f9", minWidth: colWidths[key], maxWidth: colWidths[key], fontWeight: 700, color: "#0f766e", fontSize: "0.7rem", borderRight: "1px solid #e0e0e0", position: "sticky", top: row1Height, zIndex: 3 }}>
                    <Box sx={{ position: "relative", width: "100%", height: "100%" }}>
                      {label}
                      <ColumnResizer columnKey={key} resizeRef={resizeRef} forceUpdate={forceUpdate} />
                    </Box>
                  </TableCell>
                ))}
                {STEPS.map((step) => !visibleColumns[step.id] ? null : (
                  <React.Fragment key={step.id}>
                    {STEP_COLS.map((col) => {
                      const ck = `${col.key}-${step.id}`;
                      return (
                        <TableCell key={ck} sx={{ bgcolor: step.bgColor, minWidth: colWidths[ck], maxWidth: colWidths[ck], fontWeight: 600, fontSize: "0.7rem", textAlign: col.key === "daysDelay" || col.key === "status" ? "center" : "left", borderRight: col.key === "docDate" ? "2px solid #94a3b8" : undefined, position: "sticky", top: row1Height, zIndex: 3 }}>
                          <Box sx={{ position: "relative", width: "100%", height: "100%" }}>
                            {col.label}
                            <ColumnResizer columnKey={ck} resizeRef={resizeRef} forceUpdate={forceUpdate} />
                          </Box>
                        </TableCell>
                      );
                    })}
                  </React.Fragment>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {filteredRows.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={200} align="center" sx={{ py: 6, color: "#94a3b8", fontSize: "0.85rem" }}>
                    {loading ? "" : "No records found"}
                  </TableCell>
                </TableRow>
              ) : (
                filteredRows.map((paper, i) => {
                  const isSel  = selected.includes(i);
                  const rowBg  = isSel ? "#e0f2fe" : i % 2 === 0 ? "#ffffff" : "#f8fafc";
                  const contId = extractContentsID(paper);

                  return (
                    <TableRow key={i} hover>
                      <TableCell padding="checkbox" sx={{ bgcolor: rowBg, minWidth: colWidths.checkbox, maxWidth: colWidths.checkbox }}>
                        <Checkbox size="small" color="primary" checked={isSel} onChange={() => handleSelectRow(i)} />
                      </TableCell>

                      {visibleColumns.JobCardContentNo && (
                        <TableCell sx={{ bgcolor: rowBg, fontWeight: 700, fontSize: "0.75rem", minWidth: colWidths.JobCardContentNo, maxWidth: colWidths.JobCardContentNo, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {fmt(paper.JobCardContentNo)}
                        </TableCell>
                      )}
                      {visibleColumns.JobName && (
                        <TableCell sx={{ bgcolor: rowBg, fontWeight: 600, fontSize: "0.75rem", minWidth: colWidths.JobName, maxWidth: colWidths.JobName, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {fmt(paper.JobName)}
                        </TableCell>
                      )}
                      {/* CHANGE 5: Customer Name */}
                      {visibleColumns.CustomerName && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", minWidth: colWidths.CustomerName, maxWidth: colWidths.CustomerName, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {fmt(paper.CustomerName)}
                        </TableCell>
                      )}
                      {/* CHANGE 2: Job Date */}
                      {visibleColumns.JobBookingDate && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", textAlign: "center", minWidth: colWidths.JobBookingDate, maxWidth: colWidths.JobBookingDate, whiteSpace: "nowrap" }}>
                          {formatDate(paper.JobBookingDate)}
                        </TableCell>
                      )}
                      {visibleColumns.PlanContName && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", minWidth: colWidths.PlanContName, maxWidth: colWidths.PlanContName, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {fmt(paper.PlanContName)}
                        </TableCell>
                      )}
                      {visibleColumns.ItemName && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", minWidth: colWidths.ItemName, maxWidth: colWidths.ItemName, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {fmt(paper.ItemName)}
                        </TableCell>
                      )}
                      {/* CHANGE 1: Size W Inch */}
                      {visibleColumns.SizeW && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", textAlign: "center", minWidth: colWidths.SizeW, maxWidth: colWidths.SizeW }}>
                          {fmt(paper.SizeW)}
                        </TableCell>
                      )}
                      {/* CHANGE 1: Size L Inch */}
                      {visibleColumns.SizeL && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", textAlign: "center", minWidth: colWidths.SizeL, maxWidth: colWidths.SizeL }}>
                          {fmt(paper.SizeL)}
                        </TableCell>
                      )}
                      {visibleColumns.GSM && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", textAlign: "center", minWidth: colWidths.GSM, maxWidth: colWidths.GSM }}>
                          {fmt(paper.GSM)}
                        </TableCell>
                      )}
                      {visibleColumns.Quality && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", minWidth: colWidths.Quality, maxWidth: colWidths.Quality, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {fmt(paper.Quality)}
                        </TableCell>
                      )}
                      {visibleColumns.Quantity && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", textAlign: "center", minWidth: colWidths.Quantity, maxWidth: colWidths.Quantity }}>
                          {fmt(paper.Quantity)}
                        </TableCell>
                      )}
                      {visibleColumns.QuantityKG && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", textAlign: "center", minWidth: colWidths.QuantityKG, maxWidth: colWidths.QuantityKG }}>
                          {fmt(paper.QuantityKG)}
                        </TableCell>
                      )}
                      {visibleColumns.Reams && (
                        <TableCell sx={{ bgcolor: rowBg, fontSize: "0.75rem", textAlign: "center", minWidth: colWidths.Reams, maxWidth: colWidths.Reams }}>
                          {fmt(paper.Reams)}
                        </TableCell>
                      )}

                      {/* Step cells */}
                      {(() => {
                        const step5Row   = contId ? (stepMaps["step5"]?.[contId] ?? {}) : {};
                        const issueNoVal = step5Row["IssueNo"] ?? step5Row["issueNo"] ?? "";
                        const hasIssueNo = Boolean(issueNoVal && String(issueNoVal).trim() !== "" && String(issueNoVal).trim() !== "-");
                        return STEPS.map((step) => {
                          if (!visibleColumns[step.id]) return null;
                          const stepRow = contId ? (stepMaps[step.id]?.[contId] ?? {}) : {};
                          return (
                            <React.Fragment key={step.id}>
                              {STEP_COLS.map((col) => renderStepCell(step, col, stepRow, hasIssueNo))}
                            </React.Fragment>
                          );
                        });
                      })()}
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Snackbar open={snackbar.open} autoHideDuration={3000} onClose={() => setSnackbar((p) => ({ ...p, open: false }))} anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert severity={snackbar.severity} variant="filled">{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default PaperFMS;