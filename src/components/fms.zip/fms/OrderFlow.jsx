import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  Filter, Search, Info,
  FileDown, RefreshCw, Settings, Eye, EyeOff, RotateCcw
} from "lucide-react";
import { postRequest } from '../api/api';
import {
  IconButton, Tooltip, Snackbar, Alert, Button, Menu, MenuItem,
  Box, Typography, Paper, TextField, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Checkbox, FormControl,
  InputLabel, Select, Stack, CircularProgress,
  InputAdornment, ListItemIcon, ListItemText, Autocomplete, Chip
} from '@mui/material';
import * as XLSX from 'xlsx';

const DIRECT_SALES_TYPE = 'job for direct sales order';

const OrderFlow = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [entries, setEntries] = useState([]);
  const [filteredEntries, setFilteredEntries] = useState([]);
  const [selectedEntries, setSelectedEntries] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [exportMenuAnchor, setExportMenuAnchor] = useState(null);
  const [columnMenuAnchor, setColumnMenuAnchor] = useState(null);

  // ─── Refs ────────────────────────────────────────────────────────────────
  const resizeStateRef = useRef({ isResizing: false, columnKey: null, startX: 0, startWidth: 0 });
  const [, forceUpdate] = useState({});
  const tableRef  = useRef(null);
  const row1Ref   = useRef(null);   // measures Row-1 height for Row-2 sticky top
  const [row1Height, setRow1Height] = useState(72); // default fallback px

  const [visibleColumns, setVisibleColumns] = useState({
    enquiryDate: true, enquiryNo: true, customerName: true, titleName: true,
    sizeWidth: true, sizeHeight: true, pages: true, qty: true,
    typeOfBinding: true, action: true,
    costEstimation: true, quotationToCustomer: true, sendForOrder: true
  });

  const [uniqueEnquiryNos, setUniqueEnquiryNos] = useState([]);
  const [uniqueStatuses, setUniqueStatuses]     = useState([]);
  const [filters, setFilters] = useState({ enquiryNo: '', currentStatus: '', fromDate: '', toDate: '' });

  const workflowStages = [
    {
      id: 'costEstimation', name: 'COST ESTIMATION', stepNumber: 'Step 1',
      tat: 'Sales', tatHours: 24, bgColor: '#f3e5f5', editable: true, showDeptName: true,
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'quotationToCustomer', name: 'SEND COSTING TO CUSTOMER', stepNumber: 'Step 2',
      tat: 'Costing', tatHours: 4, bgColor: '#e3f2fd', editable: true, showDeptName: true,
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'sendForOrder', name: 'SEND FOR ORDER (SFO)', stepNumber: 'Step 3',
      tat: 'Sales', tatHours: 24, bgColor: '#e8f5e9', editable: true, showDeptName: true,
      statusOptions: ['Confirmed', 'Rejected', 'Negotiation', 'Price Approved', 'Order Received'],
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    }
  ];

  const [columnWidths, setColumnWidths] = useState({
    checkbox: 50, enquiryDate: 110, enquiryNo: 110, customerName: 150,
    titleName: 160, sizeWidth: 85, sizeHeight: 85, pages: 70, qty: 70,
    typeOfBinding: 120, action: 90,
    'plannedDate-costEstimation': 110, 'actualDate-costEstimation': 110,
    'daysDelay-costEstimation': 120,   'status-costEstimation': 120,
    'delayReason-costEstimation': 150, 'doerName-costEstimation': 130,
    'plannedDate-quotationToCustomer': 110, 'actualDate-quotationToCustomer': 110,
    'daysDelay-quotationToCustomer': 120,   'status-quotationToCustomer': 120,
    'delayReason-quotationToCustomer': 150, 'doerName-quotationToCustomer': 130,
    'plannedDate-sendForOrder': 110, 'actualDate-sendForOrder': 110,
    'daysDelay-sendForOrder': 120,   'status-sendForOrder': 120,
    'delayReason-sendForOrder': 150, 'doerName-sendForOrder': 130,
  });

  // ─── Helpers ─────────────────────────────────────────────────────────────

  const getDepartmentNameForStage = (stageId) => {
    if (!filteredEntries || filteredEntries.length === 0) return '';
    const deptNames = filteredEntries
      .map(entry => entry.stages[stageId]?.departmentName)
      .filter(name => typeof name === 'string' && name.trim() !== '');
    if (deptNames.length === 0) return '';
    const frequency = {};
    deptNames.forEach(name => { frequency[name] = (frequency[name] || 0) + 1; });
    return Object.keys(frequency).reduce((a, b) => frequency[a] > frequency[b] ? a : b);
  };

  // Returns true when plannedDate is strictly in the past (date-only, ignores time).
  // Handles DD-MM-YYYY (API format), YYYY-MM-DD, and full ISO strings.
  const isPastDate = (dateStr) => {
    if (!dateStr || dateStr === '-') return false;
    const str = String(dateStr).trim();
    if (!str || str === 'null' || str === 'undefined') return false;

    let d;
    // DD-MM-YYYY must be reordered to YYYY-MM-DD for correct Date parsing
    if (/^\d{2}-\d{2}-\d{4}$/.test(str)) {
      const [dd, mm, yyyy] = str.split('-');
      d = new Date(`${yyyy}-${mm}-${dd}`);
    } else {
      d = new Date(str);
    }
    if (isNaN(d.getTime())) return false;

    // Date-only comparison so today itself is NOT counted as past
    const planDay  = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const todayDay = new Date();
    todayDay.setHours(0, 0, 0, 0);
    return planDay < todayDay;
  };

  // ─── getStatusText ────────────────────────────────────────────────────────
  // Priority:
  //   1. status=Pending + plan date is in the past → "Delay" (red)
  //   2. status=Pending + daysDelay contains "day"/"+") → "Delay" (red)
  //   3. status=Pending (not yet due) → "Pending" (yellow)
  //   4. All other statuses → normal colour logic
  const getStatusText = (status, stageId = null, daysDelay = null, plannedDate = null) => {
    if (!status || status === '-') return { text: '-', color: '#6b7280' };

    const s         = status.toLowerCase();
    const delayStr  = String(daysDelay || '');
    const hasDelay  = daysDelay && daysDelay !== '-' &&
                      (delayStr.includes('day') || delayStr.includes('+'));
    const isPending = s === 'pending';
    const isDone    = s === 'done' || s === 'completed';

    // ── Rule 1 & 2: Pending + overdue (date-based OR delay-string-based)
    if (isPending && !isDone && (isPastDate(plannedDate) || hasDelay)) {
      return { text: 'Delay', color: '#ef4444' };
    }

    // ── Rule 3: Pending but not yet overdue
    if (isPending) return { text: status, color: '#eab308' };

    // ── Rule 4: sendForOrder special statuses
    if (stageId === 'sendForOrder') {
      if (s === 'order received' || s === 'orderreceived') return { text: status, color: '#10b981' };
      if (s === 'price approved'  || s === 'priceapproved') return { text: status, color: '#6b7280' };
      if (s === 'confirmed')   return { text: status, color: '#10b981' };
      if (s === 'rejected')    return { text: status, color: '#ef4444' };
      if (s === 'negotiation') return { text: status, color: '#f59e0b' };
      return { text: status, color: '#6b7280' };
    }

    // ── Rule 5: General statuses
    if (isDone) return { text: status, color: '#10b981' };
    if (['approval in progress','in process','in progress','approval pending',
         'pending price approval','running','order not received','processing',
         'wip','work in progress'].includes(s)) return { text: status, color: '#3b82f6' };
    if (['approved','yes','costing done','price approval done',
         'order booked','confirmed'].includes(s)) return { text: status, color: '#10b981' };
    if (['rejected','no','cancelled','delay','delayed'].includes(s)) return { text: status, color: '#ef4444' };

    return { text: status, color: '#6b7280' };
  };

  const StatusCell = ({ status, stageId, daysDelay, plannedDate }) => {
    const { text, color } = getStatusText(status, stageId, daysDelay, plannedDate);
    return (
      <Typography sx={{ color, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
        {text}
      </Typography>
    );
  };

  // ─── DaysDelayCell ────────────────────────────────────────────────────────
  const DaysDelayCell = ({ delayText, isDirectSalesOrder = false, status = '' }) => {
    const isDone = ['done','completed'].includes(String(status || '').toLowerCase().trim());

    // Direct Sales Order + Done → always "On Time" (green)
    if (isDirectSalesOrder && isDone) {
      return (
        <Typography sx={{ color: '#10b981', fontWeight: 700, fontSize: '0.75rem', textAlign: 'center', whiteSpace: 'nowrap' }}>
          On Time
        </Typography>
      );
    }

    const textStr = String(delayText || '-');
    let color = '#6b7280';
    let displayText = textStr;

    const numericValue = parseFloat(textStr);
    if (!isNaN(numericValue) && numericValue < 0) {
      displayText = '-'; color = '#6b7280';
    } else if (!textStr || textStr === '-' || textStr === 'null' || textStr === 'undefined') {
      displayText = '-'; color = '#6b7280';
    } else if (textStr.toLowerCase().includes('on time')) {
      color = '#10b981';
    } else if (textStr.includes('min') || textStr.includes('hr')) {
      color = '#f59e0b';
    } else if (textStr.includes('day') || textStr.includes('+')) {
      color = '#ef4444';
    } else if (!isNaN(numericValue) && numericValue > 0) {
      color = '#ef4444';
    }

    return (
      <Typography sx={{ color, fontWeight: 700, fontSize: '0.75rem', textAlign: 'center', whiteSpace: 'nowrap' }}>
        {displayText && displayText !== '-' ? `${displayText} Day` : displayText || '-'}
      </Typography>
    );
  };

  const toggleColumn = (key) => setVisibleColumns(prev => ({ ...prev, [key]: !prev[key] }));

  const activeBaseColumnsCount = useMemo(() =>
    ['enquiryDate','enquiryNo','customerName','titleName','sizeWidth',
     'sizeHeight','pages','qty','typeOfBinding','action']
      .filter(key => visibleColumns[key]).length + 1,
  [visibleColumns]);

  // ─── formatDate: zero-safe ────────────────────────────────────────────────
  const formatDate = (dateString) => {
    if (dateString === null || dateString === undefined) return '-';
    const str = String(dateString).trim();
    if (str === '' || str === '-' || /^0+$/.test(str) ||
        str === 'null' || str === 'undefined' || str === 'Invalid Date') return '-';
    try {
      if (/^\d{2}-\d{2}-\d{4}$/.test(str)) return str;
      const date = new Date(str);
      if (isNaN(date.getTime())) return '-';
      if (date.getUTCFullYear() === 1970 && date.getUTCMonth() === 0 &&
          date.getUTCDate() === 1 && date.getUTCHours() === 0) return '-';
      return [
        String(date.getDate()).padStart(2, '0'),
        String(date.getMonth() + 1).padStart(2, '0'),
        date.getFullYear()
      ].join('-');
    } catch { return '-'; }
  };

  // ─── Column resize ────────────────────────────────────────────────────────
  const handleMouseDown = useCallback((e, columnKey) => {
    e.preventDefault(); e.stopPropagation();
    resizeStateRef.current = { isResizing: true, columnKey, startX: e.clientX, startWidth: columnWidths[columnKey] };
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    forceUpdate({});
  }, [columnWidths]);

  const handleMouseMove = useCallback((e) => {
    if (!resizeStateRef.current.isResizing) return;
    const { columnKey, startX, startWidth } = resizeStateRef.current;
    setColumnWidths(prev => ({ ...prev, [columnKey]: Math.max(50, startWidth + (e.clientX - startX)) }));
  }, []);

  const handleMouseUp = useCallback(() => {
    if (resizeStateRef.current.isResizing) {
      resizeStateRef.current.isResizing = false;
      resizeStateRef.current.columnKey  = null;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      forceUpdate({});
    }
  }, []);

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup',   handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup',   handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  useEffect(() => { fetchOrderFlowData(); }, []);

  // ─── Sticky header: ResizeObserver measures Row-1 live ───────────────────
  // Row 1 (group headers) → top: 0
  // Row 2 (column names)  → top: row1Height  (measured live, never guessed)
  useEffect(() => {
    const el = row1Ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => {
      const h = entry.borderBoxSize?.[0]?.blockSize ?? entry.contentRect.height;
      if (h > 0) setRow1Height(Math.ceil(h));
    });
    ro.observe(el);
    setRow1Height(Math.ceil(el.getBoundingClientRect().height) || 72);
    return () => ro.disconnect();
  }, []);

  const stickyRow1 = { position: 'sticky', top: 0,           zIndex: 4 };
  const stickyRow2 = { position: 'sticky', top: row1Height,  zIndex: 3 };

  // ─── Data fetch ───────────────────────────────────────────────────────────
  const fetchOrderFlowData = async () => {
    setLoading(true);
    try {
      const [salesEnquiryRes, costingRes, quotationRes, salesOrderRes] = await Promise.all([
        postRequest('GetSalesEnquiry'),
        postRequest('GetCosting'),
        postRequest('GetQuotationToCustomer'),
        postRequest('GetSalesOrder')
      ]);

      const toArr = (r) => Array.isArray(r?.data) ? r.data : Array.isArray(r) ? r : [];

      const salesEnquiryData = toArr(salesEnquiryRes);
      const costingData      = toArr(costingRes);
      const quotationData    = toArr(quotationRes);
      const salesOrderData   = toArr(salesOrderRes);

      const costingMap = {};
      costingData.forEach(item => { const id = item.EnquiryID || item.enquiryid; if (id) costingMap[id] = item; });

      const quotationMap = {};
      quotationData.forEach(item => { const id = item.EnquiryID || item.enquiryid; if (id) quotationMap[id] = item; });

      const salesOrderMap = {};
      salesOrderData.forEach(item => { const id = item.EnquiryID || item.enquiryid; if (id) salesOrderMap[id] = item; });

      const transformedData = salesEnquiryData.map((enquiry, index) => {
        const enquiryID  = enquiry.EnquiryID || enquiry.enquiryid;
        const costing    = costingMap[enquiryID]    || {};
        const quotation  = quotationMap[enquiryID]  || {};
        const salesOrder = salesOrderMap[enquiryID] || {};

        const jobForEnquiryType = String(
          enquiry.JobForEnquiryType || enquiry.jobforenquirytype || ''
        ).toLowerCase().trim();
        const isDirectSalesOrder = jobForEnquiryType === DIRECT_SALES_TYPE;

        return {
          id           : enquiryID || `row_${index}`,
          enquiryNo    : enquiry.EnquiryNo    || '-',
          enquiryDate  : enquiry.EnquiryDate  || '-',
          customerName : enquiry.CustomerName || enquiry.LedgerName  || '-',
          titleName    : enquiry.TitleName    || enquiry.JobName     || '-',
          sizeWidth    : enquiry.SizeLength   || enquiry.SizeWidth   || '-',
          sizeHeight   : enquiry.SizeHeight   || enquiry.Height      || '-',
          pages        : enquiry.BookPages    || enquiry.Pages       || '-',
          qty          : enquiry.Quantity          || enquiry.Quantity    || '-',
          typeOfBinding: enquiry.TypeOfBinding || enquiry.BindingType || '-',
          isDirectSalesOrder,

          stages: {
            costEstimation: {
              plannedDate   : costing.PlanDate      || costing.PlannedDate  || '-',
              actualDate    : costing.ActualDate    || '-',
              daysDelay     : costing.Delay         || costing.DaysDelay   || '-',
              status        : costing.Status        || '-',
              delayReason   : costing.DelayReason   || costing.Remark      || '-',
              doerName      : costing.username      || costing.CreatedBy   || costing.DoerName || '-',
              departmentName: costing.DepartmentName || 'Cost Estimation',
            },
            quotationToCustomer: {
              plannedDate   : quotation.plandate    || quotation.PlannedDate || quotation.PlanDate || '-',
              actualDate    : quotation.actualdate  || quotation.ActualDate  || '-',
              daysDelay     : quotation.delay       || quotation.Delay       || quotation.DaysDelay || '-',
              status        : quotation.status      || quotation.Status      || '-',
              delayReason   : quotation.DelayReason || quotation.Remark      || '-',
              doerName      : quotation.username    || quotation.CreatedBy   || quotation.DoerName || '-',
              departmentName: quotation.departmentname || quotation.DepartmentName || 'Quotation',
            },
            sendForOrder: {
              plannedDate   : salesOrder.PlannedDate || salesOrder.PlanDate  || '-',
              actualDate    : salesOrder.ActualDate  || '-',
              daysDelay     : salesOrder.Delay       || salesOrder.DaysDelay || '-',
              status        : salesOrder.Status      || '-',
              delayReason   : salesOrder.DelayReason || salesOrder.Remark    || '-',
              doerName      : salesOrder.userName    || '-',
              departmentName: salesOrder.DepartmentName || 'Sales Order',
            }
          }
        };
      });

      const sortedData = [...transformedData].sort((a, b) =>
        new Date(b.enquiryDate) - new Date(a.enquiryDate)
      );

      setEntries(sortedData);
      setUniqueEnquiryNos(
        [...new Set(sortedData.map(i => i.enquiryNo).filter(n => n && n !== '-'))].sort()
      );
      const allStatuses = new Set();
      sortedData.forEach(entry =>
        Object.values(entry.stages).forEach(stage => {
          if (stage.status && stage.status !== '-') allStatuses.add(stage.status);
        })
      );
      setUniqueStatuses([...allStatuses].sort());
      setLoading(false);
      showSnackbar('Data loaded successfully', 'success');
    } catch (error) {
      setLoading(false);
      console.error('Error fetching data:', error);
      showSnackbar('Failed to load data', 'error');
    }
  };

  // ─── Filter logic ─────────────────────────────────────────────────────────
  useEffect(() => {
    const q = searchQuery.toLowerCase().trim();
    setFilteredEntries(entries.filter(entry => {
      const ms = !searchQuery ||
        entry.enquiryNo?.toLowerCase().includes(q) ||
        entry.customerName?.toLowerCase().includes(q) ||
        entry.titleName?.toLowerCase().includes(q);

      const me = !filters.enquiryNo ||
        entry.enquiryNo?.trim().toUpperCase() === filters.enquiryNo.trim().toUpperCase();

      const mc = !filters.currentStatus ||
        Object.values(entry.stages).some(stage =>
          stage.status?.trim().toUpperCase() === filters.currentStatus.trim().toUpperCase()
        );

      const mf = !filters.fromDate || new Date(entry.enquiryDate) >= new Date(filters.fromDate);
      const mt = !filters.toDate   || new Date(entry.enquiryDate) <= new Date(filters.toDate);

      return ms && me && mc && mf && mt;
    }));
  }, [entries, filters, searchQuery]);

  const handleFilterChange = (name, val) => setFilters(prev => ({ ...prev, [name]: val }));
  const clearFilters = () => { setFilters({ enquiryNo:'', currentStatus:'', fromDate:'', toDate:'' }); setSearchQuery(''); };
  const handleSelectAll   = (e) => setSelectedEntries(e.target.checked ? filteredEntries.map(e => e.id) : []);
  const handleSelectEntry = (id) => setSelectedEntries(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  const showSnackbar      = (message, severity = 'success') => setSnackbar({ open: true, message, severity });

  // ─── Export ───────────────────────────────────────────────────────────────
  const handleExport = async (exportType) => {
    try {
      const dataToExport = selectedEntries.length > 0
        ? filteredEntries.filter(e => selectedEntries.includes(e.id))
        : filteredEntries;
      if (!dataToExport.length) { showSnackbar('No data to export', 'warning'); return; }

      const flattenedData = dataToExport.map(entry => ({
        'Enquiry Date'            : formatDate(entry.enquiryDate),
        'Enquiry No'              : entry.enquiryNo,
        'Customer Name'           : entry.customerName,
        'Title Name'              : entry.titleName,
        'Size (Width)'            : entry.sizeWidth,
        'Size (Height)'           : entry.sizeHeight,
        'Pages'                   : entry.pages,
        'Qty'                     : entry.qty,
        'Type of Binding'         : entry.typeOfBinding,
        'Cost Est. Plan Date'     : formatDate(entry.stages.costEstimation.plannedDate),
        'Cost Est. Actual Date'   : formatDate(entry.stages.costEstimation.actualDate),
        'Cost Est. Days Delay'    : entry.stages.costEstimation.daysDelay,
        'Cost Est. Status'        : entry.stages.costEstimation.status,
        'Cost Est. Delay Reason'  : entry.stages.costEstimation.delayReason,
        'Cost Est. Doer Name'     : entry.stages.costEstimation.doerName,
        'Quotation Plan Date'     : formatDate(entry.stages.quotationToCustomer.plannedDate),
        'Quotation Actual Date'   : formatDate(entry.stages.quotationToCustomer.actualDate),
        'Quotation Days Delay'    : entry.stages.quotationToCustomer.daysDelay,
        'Quotation Status'        : entry.stages.quotationToCustomer.status,
        'Quotation Delay Reason'  : entry.stages.quotationToCustomer.delayReason,
        'Quotation Doer Name'     : entry.stages.quotationToCustomer.doerName,
        'SFO Plan Date'           : formatDate(entry.stages.sendForOrder.plannedDate),
        'SFO Actual Date'         : formatDate(entry.stages.sendForOrder.actualDate),
        'SFO Days Delay'          : entry.stages.sendForOrder.daysDelay,
        'SFO Status'              : entry.stages.sendForOrder.status,
        'SFO Delay Reason'        : entry.stages.sendForOrder.delayReason,
        'SFO Doer Name'           : entry.stages.sendForOrder.doerName,
      }));

      if (exportType === 'excel') {
        const ws = XLSX.utils.json_to_sheet(flattenedData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sales Enquiry');
        XLSX.writeFile(wb, `SalesEnquiry_${new Date().toISOString().split('T')[0]}.xlsx`);
        showSnackbar('Exported to Excel successfully', 'success');
      } else {
        const ws  = XLSX.utils.json_to_sheet(flattenedData);
        const a   = document.createElement('a');
        a.href     = URL.createObjectURL(new Blob([XLSX.utils.sheet_to_csv(ws)], { type: 'text/csv' }));
        a.download = `SalesEnquiry_${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        showSnackbar('Exported to CSV successfully', 'success');
      }
      setExportMenuAnchor(null);
    } catch (error) {
      console.error('Error exporting data:', error);
      showSnackbar('Error exporting data', 'error');
    }
  };

  // ─── Column resizer ───────────────────────────────────────────────────────
  const ColumnResizer = ({ columnKey }) => {
    const isActive = resizeStateRef.current.isResizing && resizeStateRef.current.columnKey === columnKey;
    return (
      <Box onMouseDown={(e) => handleMouseDown(e, columnKey)} sx={{
        position: 'absolute', right: -2, top: 0, width: '4px', height: '100%',
        cursor: 'col-resize', userSelect: 'none', zIndex: 100,
        backgroundColor: isActive ? '#3b82f6' : 'transparent',
        '&:hover': { backgroundColor: '#3b82f6' },
      }} />
    );
  };

  const headerLabels = {
    plannedDate : 'Plan Date',   actualDate  : 'Actual Date',
    daysDelay   : 'Days Delay',  status      : 'Current Status',
    delayReason : 'Delay Reason', doerName   : 'Doer Name'
  };

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <Box sx={{ p: 2, bgcolor: '#f8fafc', minHeight: '100vh', position: 'relative' }}>
      {loading && (
        <Box sx={{ position:'fixed', inset:0, bgcolor:'rgba(255,255,255,0.15)', backdropFilter:'blur(1px)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:9999 }}>
          <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center', gap:1.5 }}>
            <CircularProgress size={40} thickness={4} sx={{ color:'#0f766e' }} />
            <Typography variant="body2" sx={{ fontWeight:600, color:'#0f766e' }}>Loading...</Typography>
          </Box>
        </Box>
      )}

      <Typography variant="caption" sx={{ display:'block', textAlign:'center', letterSpacing:4, fontWeight:700, color:'text.secondary', mb:3 }}>
        SALES ENQUIRY TO ORDER BOOKING - FMS
      </Typography>

      <Paper elevation={2} sx={{ borderRadius:2, overflow:'hidden' }}>

        {/* ── Toolbar ── */}
        <Box sx={{ p:1.5, bgcolor:'#f1f5f9', borderBottom:'1px solid #e2e8f0' }}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Tooltip title="Toggle Filters">
              <IconButton size="small" onClick={() => setShowFilters(!showFilters)}
                sx={{ border:'1px solid #cbd5e1', borderRadius:1, bgcolor: showFilters ? '#0f766e' : 'white', color: showFilters ? 'white' : 'inherit' }}>
                <Filter size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Column Settings">
              <IconButton size="small" onClick={(e) => setColumnMenuAnchor(e.currentTarget)}
                sx={{ border:'1px solid #cbd5e1', borderRadius:1, bgcolor:'white' }}>
                <Settings size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Refresh Data">
              <IconButton size="small" onClick={fetchOrderFlowData} disabled={loading}
                sx={{ border:'1px solid #cbd5e1', borderRadius:1, bgcolor:'white' }}>
                <RefreshCw size={18} style={{ animation: loading ? 'spin 1s linear infinite' : 'none', transformOrigin:'center' }} />
              </IconButton>
            </Tooltip>
            <TextField size="small" placeholder="Search..." value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              sx={{ bgcolor:'white', width:220 }}
              InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} /></InputAdornment> }} />
            <Box sx={{ flexGrow:1 }} />
            <Tooltip title="Export Data">
              <Button size="small" variant="contained" startIcon={<FileDown size={16} />}
                onClick={(e) => setExportMenuAnchor(e.currentTarget)}
                sx={{ bgcolor:'#3b82f6', borderRadius:1 }}>
                EXPORT
              </Button>
            </Tooltip>
            <Chip
              label={`${filteredEntries.length} / ${entries.length} Records`}
              size="small"
              sx={{ bgcolor: filteredEntries.length === entries.length ? '#10b981' : '#3b82f6', color:'white', fontWeight:700, fontSize:'0.75rem', height:'28px' }}
            />
          </Stack>
        </Box>

        <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>

        <Menu anchorEl={exportMenuAnchor} open={Boolean(exportMenuAnchor)} onClose={() => setExportMenuAnchor(null)}>
          <MenuItem onClick={() => handleExport('excel')}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to Excel</ListItemText></MenuItem>
          <MenuItem onClick={() => handleExport('csv')}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to CSV</ListItemText></MenuItem>
        </Menu>

        <Menu anchorEl={columnMenuAnchor} open={Boolean(columnMenuAnchor)} onClose={() => setColumnMenuAnchor(null)}>
          <Typography variant="overline" sx={{ px:2, fontWeight:900 }}>Columns</Typography>
          {Object.keys(visibleColumns).map((key) => (
            <MenuItem key={key} onClick={() => toggleColumn(key)} sx={{ py:0.5 }}>
              <ListItemIcon>{visibleColumns[key] ? <Eye size={16} /> : <EyeOff size={16} />}</ListItemIcon>
              <ListItemText primary={key.replace(/([A-Z])/g,' $1').toUpperCase()} primaryTypographyProps={{ fontSize:'0.75rem' }} />
              <Checkbox size="small" checked={visibleColumns[key]} color="primary" />
            </MenuItem>
          ))}
        </Menu>

        {/* ── Filters ── */}
        {showFilters && (
          <Box sx={{ p:1.5, bgcolor:'#f8fafc', borderBottom:'1px solid #e2e8f0' }}>
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
              <Autocomplete freeSolo options={uniqueEnquiryNos} value={filters.enquiryNo || ''}
                onChange={(_, v) => handleFilterChange('enquiryNo', v || '')}
                onInputChange={(_, v) => handleFilterChange('enquiryNo', v || '')}
                renderInput={(p) => <TextField {...p} label="Enquiry No" size="small" />} sx={{ width:140 }} />
              <Autocomplete freeSolo options={uniqueStatuses} value={filters.currentStatus || ''}
                onChange={(_, v) => handleFilterChange('currentStatus', v || '')}
                onInputChange={(_, v) => handleFilterChange('currentStatus', v || '')}
                renderInput={(p) => <TextField {...p} label="Current Status" size="small" />} sx={{ width:140 }} />
              <TextField sx={{ width:140 }} label="From Date" type="date" size="small"
                InputLabelProps={{ shrink:true }} value={filters.fromDate || ''}
                onChange={(e) => handleFilterChange('fromDate', e.target.value)} />
              <TextField sx={{ width:140 }} label="To Date" type="date" size="small"
                InputLabelProps={{ shrink:true }} value={filters.toDate || ''}
                onChange={(e) => handleFilterChange('toDate', e.target.value)} />
              <Button size="small" color="error" onClick={clearFilters} sx={{ fontWeight:700 }}>
                <RotateCcw size={22} strokeWidth={3} />
              </Button>
            </Stack>
          </Box>
        )}

        {/* ── Table ── */}
        <TableContainer ref={tableRef} sx={{
          maxHeight:'75vh', overflow:'auto',
          '&::-webkit-scrollbar':{ display:'none' },
          scrollbarWidth:'none', msOverflowStyle:'none',
        }}>
          <Table size="small" stickyHeader sx={{ borderCollapse:'separate' }}>
            <TableHead>

              {/* ── Row 1: group headers — ref={row1Ref} measured by ResizeObserver ── */}
              <TableRow ref={row1Ref}>
                <TableCell colSpan={activeBaseColumnsCount} align="center" sx={{
                  ...stickyRow1, bgcolor:'#cbd5e1', fontWeight:700,
                  borderBottom:'2px solid #94a3b8', fontSize:'0.7rem', padding:'8px', whiteSpace:'nowrap',
                }}>
                  📋 SALES ENQUIRY DETAILS
                </TableCell>

                {workflowStages.map(stage => {
                  if (!visibleColumns[stage.id]) return null;
                  const deptName = getDepartmentNameForStage(stage.id);
                  return (
                    <TableCell key={stage.id} colSpan={stage.columns.length} align="center" sx={{
                      ...stickyRow1, bgcolor:stage.bgColor, fontWeight:700,
                      borderRight:'1px solid #cbd5e1', borderBottom:'2px solid #cbd5e1', padding:'8px 4px',
                    }}>
                      <Typography variant="caption" sx={{ fontWeight:900, color:'#0f766e', display:'block', fontSize:'0.65rem' }}>{stage.stepNumber}</Typography>
                      <Typography variant="caption" sx={{ fontWeight:800, display:'block', fontSize:'0.7rem', mb:0.5 }}>{stage.name}</Typography>
                      <Typography variant="caption" sx={{ fontWeight:600, color:'#059669', display:'block', fontSize:'0.65rem', mb:0.5 }}>TAT: {stage.tatHours}hrs</Typography>
                      <Typography variant="caption" sx={{ fontWeight:600, color:'#059669', display:'block', fontSize:'0.65rem', mb:0.5 }}>Department: {deptName || stage.tat}</Typography>
                    </TableCell>
                  );
                })}
              </TableRow>

              {/* ── Row 2: column-name headers — top = measured row1Height ── */}
              <TableRow>
                <TableCell padding="checkbox" sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.checkbox, maxWidth:columnWidths.checkbox, borderRight:'1px solid #e0e0e0', position:'sticky' }}>
                  <Checkbox size="small" color="primary" onChange={handleSelectAll}
                    checked={selectedEntries.length === filteredEntries.length && filteredEntries.length > 0} />
                  <ColumnResizer columnKey="checkbox" />
                </TableCell>

                {visibleColumns.enquiryDate   && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.enquiryDate,   maxWidth:columnWidths.enquiryDate,   fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Enquiry Date    <ColumnResizer columnKey="enquiryDate"   /></TableCell>}
                {visibleColumns.enquiryNo     && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.enquiryNo,     maxWidth:columnWidths.enquiryNo,     fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Enquiry No      <ColumnResizer columnKey="enquiryNo"     /></TableCell>}
                {visibleColumns.customerName  && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.customerName,  maxWidth:columnWidths.customerName,  fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Customer Name   <ColumnResizer columnKey="customerName"  /></TableCell>}
                {visibleColumns.titleName     && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.titleName,     maxWidth:columnWidths.titleName,     fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Title Name      <ColumnResizer columnKey="titleName"     /></TableCell>}
                {visibleColumns.sizeWidth     && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.sizeWidth,     maxWidth:columnWidths.sizeWidth,     fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Size (L)        <ColumnResizer columnKey="sizeWidth"     /></TableCell>}
                {visibleColumns.sizeHeight    && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.sizeHeight,    maxWidth:columnWidths.sizeHeight,    fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Size (H)        <ColumnResizer columnKey="sizeHeight"    /></TableCell>}
                {visibleColumns.pages         && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.pages,         maxWidth:columnWidths.pages,         fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Pages           <ColumnResizer columnKey="pages"         /></TableCell>}
                {visibleColumns.qty           && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.qty,           maxWidth:columnWidths.qty,           fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Qty             <ColumnResizer columnKey="qty"           /></TableCell>}
                {visibleColumns.typeOfBinding && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.typeOfBinding, maxWidth:columnWidths.typeOfBinding, fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Type of Binding <ColumnResizer columnKey="typeOfBinding" /></TableCell>}
                {visibleColumns.action        && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.action,        maxWidth:columnWidths.action,        fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Action          <ColumnResizer columnKey="action"        /></TableCell>}

                {workflowStages.map(stage => {
                  if (!visibleColumns[stage.id]) return null;
                  return (
                    <React.Fragment key={stage.id}>
                      {stage.columns.map(colName => {
                        const columnKey = `${colName}-${stage.id}`;
                        return (
                          <TableCell key={columnKey} sx={{
                            ...stickyRow2, bgcolor:stage.bgColor,
                            minWidth:columnWidths[columnKey], maxWidth:columnWidths[columnKey],
                            fontWeight:600, fontSize:'0.7rem',
                            textAlign: colName === 'daysDelay' || colName === 'status' ? 'center' : 'left',
                            position:'sticky',
                          }}>
                            {headerLabels[colName]}
                            <ColumnResizer columnKey={columnKey} />
                          </TableCell>
                        );
                      })}
                    </React.Fragment>
                  );
                })}
              </TableRow>
            </TableHead>

            <TableBody>
              {filteredEntries.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={50} align="center" sx={{ py:5 }}>
                    {loading ? '' : 'No data found'}
                  </TableCell>
                </TableRow>
              ) : (
                filteredEntries.map((entry, idx) => {
                  const rowBg = idx % 2 === 0 ? 'white' : '#f8fafc';
                  return (
                    <TableRow key={entry.id} hover>
                      <TableCell padding="checkbox" sx={{ bgcolor:rowBg, minWidth:columnWidths.checkbox, maxWidth:columnWidths.checkbox }}>
                        <Checkbox size="small" color="primary"
                          checked={selectedEntries.includes(entry.id)}
                          onChange={() => handleSelectEntry(entry.id)} />
                      </TableCell>

                      {visibleColumns.enquiryDate   && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.enquiryDate,   maxWidth:columnWidths.enquiryDate,   fontSize:'0.75rem' }}>{formatDate(entry.enquiryDate)}</TableCell>}
                      {visibleColumns.enquiryNo     && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.enquiryNo,     maxWidth:columnWidths.enquiryNo,     fontWeight:700, fontSize:'0.75rem' }}>{entry.enquiryNo}</TableCell>}
                      {visibleColumns.customerName  && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.customerName,  maxWidth:columnWidths.customerName,  fontWeight:600, fontSize:'0.75rem' }}>{entry.customerName}</TableCell>}
                      {visibleColumns.titleName     && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.titleName,     maxWidth:columnWidths.titleName,     fontWeight:600, fontSize:'0.75rem' }}>{entry.titleName}</TableCell>}
                      {visibleColumns.sizeWidth     && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.sizeWidth,     maxWidth:columnWidths.sizeWidth,     fontSize:'0.75rem', textAlign:'center' }}>{entry.sizeWidth}</TableCell>}
                      {visibleColumns.sizeHeight    && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.sizeHeight,    maxWidth:columnWidths.sizeHeight,    fontSize:'0.75rem', textAlign:'center' }}>{entry.sizeHeight}</TableCell>}
                      {visibleColumns.pages         && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.pages,         maxWidth:columnWidths.pages,         fontSize:'0.75rem', textAlign:'center' }}>{entry.pages}</TableCell>}
                      {visibleColumns.qty           && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.qty,           maxWidth:columnWidths.qty,           fontSize:'0.75rem', textAlign:'center' }}>{entry.qty}</TableCell>}
                      {visibleColumns.typeOfBinding && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.typeOfBinding, maxWidth:columnWidths.typeOfBinding, fontSize:'0.75rem' }}>{entry.typeOfBinding}</TableCell>}

                      {visibleColumns.action && (
                        <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.action, maxWidth:columnWidths.action }}>
                          <Stack direction="row" spacing={0.5}>
                            <Tooltip title="View Details">
                              <IconButton size="small" color="primary"><Info size={14} /></IconButton>
                            </Tooltip>
                          </Stack>
                        </TableCell>
                      )}

                      {workflowStages.map(stage => {
                        if (!visibleColumns[stage.id]) return null;
                        return (
                          <React.Fragment key={stage.id}>
                            {stage.columns.map(colName => {
                              const columnKey = `${colName}-${stage.id}`;
                              const stageData = entry.stages[stage.id];

                              if (colName === 'plannedDate' || colName === 'actualDate') return (
                                <TableCell key={columnKey} sx={{ bgcolor:stage.bgColor, fontSize:'0.75rem', minWidth:columnWidths[columnKey], maxWidth:columnWidths[columnKey] }}>
                                  {formatDate(stageData[colName])}
                                </TableCell>
                              );

                              if (colName === 'daysDelay') return (
                                <TableCell key={columnKey} align="center" sx={{ bgcolor:stage.bgColor, minWidth:columnWidths[columnKey], padding:'6px 8px' }}>
                                  <DaysDelayCell
                                    delayText={stageData.daysDelay}
                                    isDirectSalesOrder={entry.isDirectSalesOrder}
                                    status={stageData.status}
                                  />
                                </TableCell>
                              );

                              if (colName === 'status') return (
                                <TableCell key={columnKey} align="center" sx={{ bgcolor:stage.bgColor, minWidth:columnWidths[columnKey], padding:'6px 8px' }}>
                                  <StatusCell
                                    status={stageData.status}
                                    stageId={stage.id}
                                    daysDelay={stageData.daysDelay}
                                    plannedDate={stageData.plannedDate}
                                  />
                                </TableCell>
                              );

                              if (colName === 'delayReason') return (
                                <TableCell key={columnKey} sx={{
                                  bgcolor:stage.bgColor,
                                  color: stageData.delayReason === '-' ? '#6b7280' : '#ea580c',
                                  fontWeight:600, fontSize:'0.7rem',
                                  minWidth:columnWidths[columnKey], maxWidth:columnWidths[columnKey],
                                  overflow:'hidden', textOverflow:'ellipsis'
                                }}>
                                  {stageData.delayReason}
                                </TableCell>
                              );

                              if (colName === 'doerName') return (
                                <TableCell key={columnKey} sx={{
                                  bgcolor:stage.bgColor, fontSize:'0.75rem',
                                  minWidth:columnWidths[columnKey], maxWidth:columnWidths[columnKey],
                                  fontWeight:600,
                                  color: stageData.doerName === '-' ? '#6b7280' : '#0f766e'
                                }}>
                                  {stageData.doerName}
                                </TableCell>
                              );

                              return null;
                            })}
                          </React.Fragment>
                        );
                      })}
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Snackbar open={snackbar.open} autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical:'bottom', horizontal:'right' }}>
        <Alert severity={snackbar.severity} variant="filled">{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default OrderFlow;