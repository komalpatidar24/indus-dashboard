import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  Filter, Search, Trash2, Info,
  FileDown, RefreshCw, Settings, Eye, EyeOff, Edit, Save, X, RotateCcw
} from "lucide-react";
import { postRequest } from '../api/api';
import {
  IconButton, Tooltip, Snackbar, Alert, Button, Menu, MenuItem,
  Box, Typography, Paper, TextField, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Checkbox, FormControl,
  InputLabel, Select, Stack, CircularProgress, Chip,
  InputAdornment, ListItemIcon, ListItemText,
  Dialog, DialogTitle, DialogContent, DialogActions, Grid,
  Autocomplete
} from '@mui/material';
import * as XLSX from 'xlsx';

const OrderBookingtoInvoice = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [entries,         setEntries]         = useState([]);
  const [filteredEntries, setFilteredEntries] = useState([]);
  const [selectedEntries, setSelectedEntries] = useState([]);
  const [showFilters,     setShowFilters]     = useState(false);
  const [searchQuery,     setSearchQuery]     = useState('');
  const [loading,         setLoading]         = useState(false);
  const [snackbar,        setSnackbar]        = useState({ open: false, message: '', severity: 'success' });
  const [exportMenuAnchor,  setExportMenuAnchor]  = useState(null);
  const [columnMenuAnchor,  setColumnMenuAnchor]  = useState(null);
  const [editDialogOpen,    setEditDialogOpen]    = useState(false);
  const [currentEditEntry,  setCurrentEditEntry]  = useState(null);
  const [currentEditStage,  setCurrentEditStage]  = useState(null);
  const [editFormData,      setEditFormData]      = useState({});
  const [uniqueEnquiryNos,  setUniqueEnquiryNos]  = useState([]);
  const [uniqueJobCardNos,  setUniqueJobCardNos]  = useState([]);
  const [uniqueStatuses,    setUniqueStatuses]    = useState([]);
  const [allUsers,          setAllUsers]          = useState([]);

  const resizeStateRef = useRef({ isResizing: false, columnKey: null, startX: 0, startWidth: 0 });
  const [, forceUpdate] = useState({});
  const tableRef  = useRef(null);
  const row1Ref   = useRef(null);
  const [row1Height, setRow1Height] = useState(72);

  // ─── Workflow stages — 11 steps ─────────────────────────────────────────
  const workflowStages = [
    {
      id: 'jobCard',
      name: 'JOB CARD',
      stepNumber: 'Step 1',
      tat: 'Production',
      tatHours: 24,
      bgColor: '#f3e5f5',
      apiName: 'GetJobCard',
      columns: ['jobBookingNo', 'plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'contractorPO',
      name: 'CONTRACTOR PO',
      stepNumber: 'Step 2',
      tat: 'Purchase',
      tatHours: 24,
      bgColor: '#e3f2fd',
      apiName: 'GetContractorPO',
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'rmRequisition',
      name: 'RM REQUISITION',
      stepNumber: 'Step 3',
      tat: 'Store',
      tatHours: 8,
      bgColor: '#e8f5e9',
      apiName: 'GetRMRequisition',
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'prepressApproval',
      name: 'APPROVED BY PREPRESS',
      stepNumber: 'Step 4',
      tat: 'Prepress',
      tatHours: 12,
      bgColor: '#fff3e0',
      apiName: 'GetPrepressApproval',
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'schedulingRelease',
      name: 'SCHEDULING & RELEASE FOR PRODUCTION',
      stepNumber: 'Step 5',
      tat: 'Planning',
      tatHours: 8,
      bgColor: '#fce4ec',
      apiName: 'GetScheduling',
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'printingStatus',
      name: 'PRINTING STATUS',
      stepNumber: 'Step 6',
      tat: 'Printing',
      tatHours: 48,
      bgColor: '#fef3c7',
      apiName: 'GetPrintingProduction',
      statusOptions: ['Running', 'Done'],
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'bindingStatus',
      name: 'BINDING STATUS',
      stepNumber: 'Step 7',
      tat: 'Binding',
      tatHours: 24,
      bgColor: '#ddd6fe',
      apiName: 'GetBindingProduction',
      statusOptions: ['Running', 'Done'],
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'qcStatus',
      name: 'QC & REPORT ',
      stepNumber: 'Step 8',
      tat: 'Quality',
      tatHours: 8,
      bgColor: '#dcfce7',
      apiName: 'GetQCStatus',
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'packingStatus',
      name: 'PACKING STATUS',
      stepNumber: 'Step 9',
      tat: 'Packing',
      tatHours: 12,
      bgColor: '#ffedd5',
      apiName: 'GetPackingStatus',
      statusOptions: ['Running', 'Done'],
      columns: ['plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'deliveryStatus',
      name: 'DELIVERY STATUS',
      stepNumber: 'Step 10',
      tat: 'Logistics',
      tatHours: 12,
      bgColor: '#e0f2fe',
      apiName: 'GetDeliveryStatus',
      statusOptions: ['Part Delivery', 'Full Delivery', 'Shortage'],
      columns: ['dcNo', 'plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
    {
      id: 'invoiceStatus',
      name: 'INVOICE ',
      stepNumber: 'Step 11',
      tat: 'Accounts',
      tatHours: 8,
      bgColor: '#fef9c3',
      apiName: 'GetInvoice',
      columns: ['invoiceNo', 'plannedDate', 'actualDate', 'daysDelay', 'status', 'delayReason', 'doerName']
    },
  ];

  const [visibleColumns, setVisibleColumns] = useState(() => {
    const base = { enquiryDate: true, enquiryNo: true, customerName: true, titleName: true, sizeWidth: true, sizeHeight: true, pages: true, qty: true, typeOfBinding: true, action: true };
    workflowStages.forEach(s => { base[s.id] = true; });
    return base;
  });

  // Build columnWidths from stages dynamically
  const [columnWidths, setColumnWidths] = useState(() => {
    const widths = {
      checkbox: 50, enquiryDate: 110, enquiryNo: 110, customerName: 150,
      titleName: 160, sizeWidth: 85, sizeHeight: 85, pages: 70, qty: 70,
      typeOfBinding: 120, action: 90,
    };
    workflowStages.forEach(stage => {
      stage.columns.forEach(col => {
        const key = `${col}-${stage.id}`;
        if (col === 'jobBookingNo' || col === 'dcNo' || col === 'invoiceNo') widths[key] = 130;
        else if (col === 'plannedDate' || col === 'actualDate') widths[key] = 110;
        else if (col === 'daysDelay' || col === 'status') widths[key] = 120;
        else if (col === 'delayReason') widths[key] = 150;
        else widths[key] = 130;
      });
    });
    return widths;
  });

  const [filters, setFilters] = useState({
    enquiryNo: '', jobCardNo: '', currentStatus: '', fromDate: '', toDate: ''
  });

  // ─── Helpers ──────────────────────────────────────────────────────────────
  const addHours = (dateStr, hours) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    d.setHours(d.getHours() + hours);
    return d.toISOString();
  };

  const formatDate = (dateString) => {
    if (dateString === null || dateString === undefined) return '-';
    const str = String(dateString).trim();
    if (str === '' || str === '-' || /^0+$/.test(str) ||
        str === 'null' || str === 'undefined' || str === 'Invalid Date') return '-';
    try {
      if (/^\d{2}-\d{2}-\d{4}$/.test(str)) return str;
      const date = new Date(str);
      if (isNaN(date.getTime())) return '-';
      if (date.getUTCFullYear() === 1970 && date.getUTCMonth() === 0 &&
          date.getUTCDate() === 1 && date.getUTCHours() === 0) return '-';
      return [
        String(date.getDate()).padStart(2, '0'),
        String(date.getMonth() + 1).padStart(2, '0'),
        date.getFullYear()
      ].join('-');
    } catch { return '-'; }
  };

  const formatDateForInput = (dateString) => {
    if (!dateString) return '';
    try {
      if (dateString.includes('-')) {
        const parts = dateString.split('-');
        if (parts.length === 3 && parts[2].length === 4)
          return `${parts[2]}-${parts[1]}-${parts[0]}`;
      }
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return '';
      return date.toISOString().split('T')[0];
    } catch { return ''; }
  };

  // ─── Delay text ───────────────────────────────────────────────────────────
  const formatDelayText = (delay, plannedDate = null, actualDate = null) => {
    const hasActual = actualDate && String(actualDate).trim() !== '';
    if (hasActual) {
      if (delay === null || delay === undefined || delay === '') return '';
      const n = parseInt(delay);
      if (isNaN(n)) return '';
      if (n < 0)   return '-';
      if (n === 0) return 'On Time';
      return n === 1 ? '+1 day' : `+${n} days`;
    }
    if (plannedDate && String(plannedDate).trim() !== '') {
      const plan  = new Date(plannedDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      plan.setHours(0, 0, 0, 0);
      if (!isNaN(plan.getTime())) {
        if (plan < today) {
          const diff = Math.floor((today - plan) / 86400000);
          if (diff === 0) return 'On Time';
          return diff === 1 ? '+1 day' : `+${diff} days`;
        }
        return '';
      }
    }
    if (delay === null || delay === undefined || delay === '') return '';
    const n = parseInt(delay);
    if (isNaN(n)) return '';
    if (n < 0)   return '-';
    if (n === 0) return 'On Time';
    return n === 1 ? '+1 day' : `+${n} days`;
  };

  // ─── Status logic — Pending + overdue → "Delay" red ──────────────────────
  const getStatusText = (status, stageId = null, daysDelay = '') => {
    if (!status || status === '-') return { text: '-', color: '#6b7280' };
    const s = status.toLowerCase();
    const isOverdue = String(daysDelay || '').toLowerCase().includes('day');

    if (s === 'pending' && isOverdue) return { text: 'Delay', color: '#ef4444' };
    if (s === 'pending')              return { text: status,  color: '#f59e0b' };

    const runningStages = ['printingStatus', 'bindingStatus', 'packingStatus'];
    if (runningStages.includes(stageId)) {
      if (s === 'running')  return { text: status, color: '#f59e0b' };
      if (s === 'done')     return { text: status, color: '#10b981' };
      if (s === 'delay' || s === 'delayed') return { text: status, color: '#ef4444' };
      return { text: status, color: '#6b7280' };
    }

    if (stageId === 'deliveryStatus') {
      if (s === 'full delivery')  return { text: status, color: '#10b981' };
      if (s === 'part delivery')  return { text: status, color: '#f59e0b' };
      if (s === 'shortage')       return { text: status, color: '#ef4444' };
      return { text: status, color: '#6b7280' };
    }

    if (['done', 'completed', 'verified', 'approved', 'invoiced', 'dispatched',
         'released', 'scheduled', 'printed', 'bound', 'packed', 'delivered',
         'qc done', 'report shared', 'confirmed'].includes(s))
      return { text: status, color: '#10b981' };

    if (['in progress', 'in process', 'running', 'approval in progress'].includes(s))
      return { text: status, color: '#f59e0b' };

    if (['rejected', 'no', 'cancelled', 'failed', 'delay', 'delayed'].includes(s))
      return { text: status, color: '#ef4444' };

    return { text: status, color: '#6b7280' };
  };

  const StatusCell = ({ status, stageId, daysDelay = '' }) => {
    const { text, color } = getStatusText(status, stageId, daysDelay);
    return (
      <Typography sx={{ color, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
        {text}
      </Typography>
    );
  };

  const DaysDelayCell = ({ delayText }) => {
    const textStr = String(delayText || '-');
    let color = '#6b7280';
    let display = textStr;
    if (!textStr || textStr === '-' || textStr === 'null' || textStr === 'undefined') {
      display = '-'; color = '#6b7280';
    } else if (textStr.toLowerCase() === 'on time') {
      color = '#10b981';
    } else if (textStr.includes('min') || textStr.includes('hr')) {
      color = '#f59e0b';
    } else if (textStr.includes('day')) {
      color = '#ef4444';
    }
    return (
      <Typography sx={{ color, fontWeight: 700, fontSize: '0.75rem', textAlign: 'center', whiteSpace: 'nowrap' }}>
        {display}
      </Typography>
    );
  };

  // ─── Column resize ────────────────────────────────────────────────────────
  const handleMouseDown = useCallback((e, columnKey) => {
    e.preventDefault(); e.stopPropagation();
    resizeStateRef.current = { isResizing: true, columnKey, startX: e.clientX, startWidth: columnWidths[columnKey] };
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    forceUpdate({});
  }, [columnWidths]);

  const handleMouseMove = useCallback((e) => {
    if (!resizeStateRef.current.isResizing) return;
    const { columnKey, startX, startWidth } = resizeStateRef.current;
    setColumnWidths(prev => ({ ...prev, [columnKey]: Math.max(50, startWidth + (e.clientX - startX)) }));
  }, []);

  const handleMouseUp = useCallback(() => {
    if (resizeStateRef.current.isResizing) {
      resizeStateRef.current.isResizing = false;
      resizeStateRef.current.columnKey = null;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      forceUpdate({});
    }
  }, []);

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup',   handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup',   handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  // ─── Sticky Row-1 measurement ─────────────────────────────────────────────
  useEffect(() => {
    const el = row1Ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => {
      const h = entry.borderBoxSize?.[0]?.blockSize ?? entry.contentRect.height;
      if (h > 0) setRow1Height(Math.ceil(h));
    });
    ro.observe(el);
    setRow1Height(Math.ceil(el.getBoundingClientRect().height) || 72);
    return () => ro.disconnect();
  }, []);

  const stickyRow1 = { position: 'sticky', top: 0,          zIndex: 4 };
  const stickyRow2 = { position: 'sticky', top: row1Height, zIndex: 3 };

  const toggleColumn = (key) => setVisibleColumns(prev => ({ ...prev, [key]: !prev[key] }));

  const activeBaseColumnsCount = useMemo(() =>
    ['enquiryDate','enquiryNo','customerName','titleName','sizeWidth','sizeHeight','pages','qty','typeOfBinding','action']
      .filter(key => visibleColumns[key]).length + 1,
  [visibleColumns]);

  const getDepartmentNameForStage = (stageId) => {
    if (!filteredEntries || filteredEntries.length === 0) return '';
    const deptNames = filteredEntries
      .map(e => e[`${stageId}_departmentName`])
      .filter(n => typeof n === 'string' && n.trim() !== '');
    if (deptNames.length === 0) return '';
    const freq = {};
    deptNames.forEach(n => { freq[n] = (freq[n] || 0) + 1; });
    return Object.keys(freq).reduce((a, b) => freq[a] > freq[b] ? a : b);
  };

  // ─── Data fetch ───────────────────────────────────────────────────────────
  useEffect(() => { fetchUsers(); fetchOrderFlowData(); }, []);

  const fetchUsers = async () => {
    try {
      const res = await postRequest('GetUsers');
      if (!Array.isArray(res)) return;
      setAllUsers(res.map(u => u.username || u.UserName || '').filter(Boolean).sort());
    } catch (e) { console.error('Error fetching users:', e); }
  };

  const showSnackbar = (message, severity = 'success') => setSnackbar({ open: true, message, severity });

  const fetchOrderFlowData = async () => {
    setLoading(true);
    try {
      const toArr = (r) => {
        let d = r?.data ?? r;
        if (!Array.isArray(d)) d = d?.data ?? [];
        return Array.isArray(d) ? d : [];
      };

      const [
        salesEnquiryRes, jobCardRes, contractorPORes, rmRequisitionRes,
        prepressApprovalRes, schedulingRes, printingRes, bindingRes,
        qcRes, packingRes, deliveryRes, invoiceRes
      ] = await Promise.all([
        postRequest('GetSalesEnquiry'),
        postRequest('GetJobCard'),
        postRequest('GetContractorPO'),
        postRequest('GetRMRequisition'),
        postRequest('GetPrepressApproval'),
        postRequest('GetScheduling'),
        postRequest('GetPrintingProduction'),
        postRequest('GetBindingProduction'),
        postRequest('GetQCStatus'),
        postRequest('GetPackingStatus'),
        postRequest('GetDeliveryStatus'),
        postRequest('GetInvoice'),
      ]);

      const salesEnquiryData    = toArr(salesEnquiryRes);
      const jobCardData         = toArr(jobCardRes);
      const contractorPOData    = toArr(contractorPORes);
      const rmRequisitionData   = toArr(rmRequisitionRes);
      const prepressData        = toArr(prepressApprovalRes);
      const schedulingData      = toArr(schedulingRes);
      const printingData        = toArr(printingRes);
      const bindingData         = toArr(bindingRes);
      const qcData              = toArr(qcRes);
      const packingData         = toArr(packingRes);
      const deliveryData        = toArr(deliveryRes);
      const invoiceData         = toArr(invoiceRes);

      // Build lookup maps — keyed by EnquiryID where possible, JobBookingID for production stages
      const byEnquiry = (arr, key = 'EnquiryID') => {
        const m = {};
        arr.forEach(item => { const id = item[key] || item[key.toLowerCase()]; if (id && !m[id]) m[id] = item; });
        return m;
      };
      const byJobBooking = (arr) => {
        const m = {};
        arr.forEach(item => { const id = item.JobBookingID; if (id && !m[id]) m[id] = item; });
        return m;
      };

      const jobCardMap        = byEnquiry(jobCardData);
      const contractorPOMap   = byEnquiry(contractorPOData);
      const rmRequisitionMap  = byEnquiry(rmRequisitionData);
      const prepressMap       = byEnquiry(prepressData);
      const schedulingMap     = byEnquiry(schedulingData);
      const printingMap       = byJobBooking(printingData);
      const bindingMap        = byJobBooking(bindingData);
      const qcMap             = byJobBooking(qcData);
      const packingMap        = byJobBooking(packingData);
      const deliveryMap       = byJobBooking(deliveryData);
      const invoiceMap        = byJobBooking(invoiceData);

      const transformed = salesEnquiryData.map((enquiry, index) => {
        const enquiryID  = enquiry.EnquiryID  || enquiry.enquiryid;
        const bookingID  = enquiry.BookingID  || enquiryID;

        const jc   = jobCardMap[bookingID]       || {};
        const cpo  = contractorPOMap[bookingID]  || {};
        const rmr  = rmRequisitionMap[bookingID] || {};
        const pp   = prepressMap[bookingID]      || {};
        const sch  = schedulingMap[bookingID]    || {};
        const prt  = printingMap[jc.JobBookingID]  || {};
        const bnd  = bindingMap[jc.JobBookingID]   || {};
        const qc   = qcMap[jc.JobBookingID]        || {};
        const pak  = packingMap[jc.JobBookingID]   || {};
        const del  = deliveryMap[jc.JobBookingID]  || {};
        const inv  = invoiceMap[jc.JobBookingID]   || {};

        const enquiryDate   = enquiry.EnquiryDate || enquiry.Date || '';

        // Actual dates for chain planning
        const jcActual   = jc.ActualDate  || jc.CompletionDate || '';
        const cpoActual  = cpo.ActualDate || '';
        const rmrActual  = rmr.ActualDate || '';
        const ppActual   = pp.ActualDate  || '';
        const schActual  = sch.ActualDate || '';
        const prtActual  = prt.ToTime     || prt.ActualDate || '';
        const bndActual  = bnd.ToTime     || bnd.ActualDate || '';
        const qcActual   = qc.ActualDate  || '';
        const pakActual  = pak.ActualDate || '';
        const delActual  = del.ActualDate || '';
        const invActual  = inv.ActualDate || '';

        // Planned dates — chain from previous stage actual
        const jcPlan   = addHours(enquiryDate, 24);
        const cpoPlan  = cpo.PlanDate  || addHours(jcActual,  24);
        const rmrPlan  = rmr.PlanDate  || addHours(cpoActual,  8);
        const ppPlan   = pp.PlanDate   || addHours(rmrActual, 12);
        const schPlan  = sch.PlanDate  || addHours(ppActual,   8);
        const prtPlan  = prt.PlanDate  || addHours(schActual, 48);
        const bndPlan  = bnd.PlanDate  || addHours(prtActual, 24);
        const qcPlan   = qc.PlanDate   || addHours(bndActual,  8);
        const pakPlan  = pak.PlanDate  || addHours(qcActual,  12);
        const delPlan  = del.PlanDate  || addHours(pakActual, 12);
        const invPlan  = inv.PlanDate  || addHours(delActual,  8);

        return {
          id: bookingID || `row_${index}`,
          enquiryNo    : enquiry.EnquiryNo     || enquiry.EnquiryNumber || '',
          enquiryDate,
          customerName : enquiry.CustomerName  || enquiry.LedgerName   || '',
          titleName    : enquiry.TitleName     || enquiry.JobName       || enquiry.Title || '',
          sizeWidth    : enquiry.SizeLength    || enquiry.SizeWidth     || enquiry.Width || '',
          sizeHeight   : enquiry.SizeHeight    || enquiry.Height        || '',
          pages        : enquiry.BookPages     || enquiry.Pages         || enquiry.NoOfPages || '',
          qty          : enquiry.Qty           || enquiry.Quantity      || '',
          typeOfBinding: enquiry.TypeOfBinding || enquiry.BindingType   || '',
          bookingID,

          // Step 1 — Job Card
          jobCard_jobBookingNo  : jc.JobBookingNo || jc.JobCardNo || '',
          jobCard_plannedDate   : jcPlan,
          jobCard_actualDate    : jcActual,
          jobCard_daysDelay     : formatDelayText(jc.Delay || jc.DaysDelay, jcPlan, jcActual),
          jobCard_status        : jc.Status || jc.CurrentStatus || '',
          jobCard_delayReason   : jc.DelayReason || jc.Reason || '',
          jobCard_doerName      : jc.UserName || jc.DoerName || jc.AssignedTo || '',
          jobCard_departmentName: 'Job Card',

          // Step 2 — Contractor PO
          contractorPO_plannedDate   : cpoPlan,
          contractorPO_actualDate    : cpoActual,
          contractorPO_daysDelay     : formatDelayText(cpo.Delay || cpo.DaysDelay, cpoPlan, cpoActual),
          contractorPO_status        : cpo.Status || '',
          contractorPO_delayReason   : cpo.DelayReason || cpo.Reason || '',
          contractorPO_doerName      : cpo.UserName || cpo.DoerName || '',
          contractorPO_departmentName: 'Purchase',

          // Step 3 — RM Requisition
          rmRequisition_plannedDate   : rmrPlan,
          rmRequisition_actualDate    : rmrActual,
          rmRequisition_daysDelay     : formatDelayText(rmr.Delay || rmr.DaysDelay, rmrPlan, rmrActual),
          rmRequisition_status        : rmr.Status || '',
          rmRequisition_delayReason   : rmr.DelayReason || rmr.Reason || '',
          rmRequisition_doerName      : rmr.UserName || rmr.DoerName || '',
          rmRequisition_departmentName: 'Store',

          // Step 4 — Approved by Prepress
          prepressApproval_plannedDate   : ppPlan,
          prepressApproval_actualDate    : ppActual,
          prepressApproval_daysDelay     : formatDelayText(pp.Delay || pp.DaysDelay, ppPlan, ppActual),
          prepressApproval_status        : pp.Status || '',
          prepressApproval_delayReason   : pp.DelayReason || pp.Reason || '',
          prepressApproval_doerName      : pp.UserName || pp.DoerName || '',
          prepressApproval_departmentName: 'Prepress',

          // Step 5 — Scheduling & Release
          schedulingRelease_plannedDate   : schPlan,
          schedulingRelease_actualDate    : schActual,
          schedulingRelease_daysDelay     : formatDelayText(sch.Delay || sch.DaysDelay, schPlan, schActual),
          schedulingRelease_status        : sch.Status || sch.SchedulingStatus || '',
          schedulingRelease_delayReason   : sch.DelayReason || sch.Reason || '',
          schedulingRelease_doerName      : sch.UserName || sch.DoerName || sch.AssignedTo || '',
          schedulingRelease_departmentName: 'Planning',

          // Step 6 — Printing Status
          printingStatus_plannedDate   : prtPlan,
          printingStatus_actualDate    : prtActual,
          printingStatus_daysDelay     : formatDelayText(prt.Delay, prtPlan, prtActual),
          printingStatus_status        : prt.Status || '',
          printingStatus_delayReason   : prt.DelayReason || '',
          printingStatus_doerName      : prt.UserName || prt.DoerName || '',
          printingStatus_departmentName: 'Printing',

          // Step 7 — Binding Status
          bindingStatus_plannedDate   : bndPlan,
          bindingStatus_actualDate    : bndActual,
          bindingStatus_daysDelay     : formatDelayText(bnd.Delay, bndPlan, bndActual),
          bindingStatus_status        : bnd.Status || '',
          bindingStatus_delayReason   : bnd.DelayReason || '',
          bindingStatus_doerName      : bnd.UserName || bnd.DoerName || '',
          bindingStatus_departmentName: 'Binding',

          // Step 8 — QC
          qcStatus_plannedDate   : qcPlan,
          qcStatus_actualDate    : qcActual,
          qcStatus_daysDelay     : formatDelayText(qc.Delay || qc.DaysDelay, qcPlan, qcActual),
          qcStatus_status        : qc.Status || '',
          qcStatus_delayReason   : qc.DelayReason || qc.Reason || '',
          qcStatus_doerName      : qc.UserName || qc.DoerName || '',
          qcStatus_departmentName: 'Quality',

          // Step 9 — Packing
          packingStatus_plannedDate   : pakPlan,
          packingStatus_actualDate    : pakActual,
          packingStatus_daysDelay     : formatDelayText(pak.Delay || pak.DaysDelay, pakPlan, pakActual),
          packingStatus_status        : pak.Status || '',
          packingStatus_delayReason   : pak.DelayReason || pak.Reason || '',
          packingStatus_doerName      : pak.UserName || pak.DoerName || '',
          packingStatus_departmentName: 'Packing',

          // Step 10 — Delivery
          deliveryStatus_dcNo         : del.DCNo || del.DcNo || del.DeliveryChallanNo || '',
          deliveryStatus_plannedDate  : delPlan,
          deliveryStatus_actualDate   : delActual,
          deliveryStatus_daysDelay    : formatDelayText(del.Delay || del.DaysDelay, delPlan, delActual),
          deliveryStatus_status       : del.Status || del.DeliveryStatus || '',
          deliveryStatus_delayReason  : del.DelayReason || del.Reason || '',
          deliveryStatus_doerName     : del.UserName || del.DoerName || del.DriverName || '',
          deliveryStatus_departmentName: 'Logistics',

          // Step 11 — Invoice
          invoiceStatus_invoiceNo     : inv.InvoiceNo || inv.InvoiceNumber || '',
          invoiceStatus_plannedDate   : invPlan,
          invoiceStatus_actualDate    : invActual,
          invoiceStatus_daysDelay     : formatDelayText(inv.Delay || inv.DaysDelay, invPlan, invActual),
          invoiceStatus_status        : inv.Status || '',
          invoiceStatus_delayReason   : inv.DelayReason || inv.Reason || '',
          invoiceStatus_doerName      : inv.UserName || inv.DoerName || '',
          invoiceStatus_departmentName: 'Accounts',
        };
      });

      const sorted = [...transformed].sort((a, b) => new Date(b.enquiryDate) - new Date(a.enquiryDate));
      setEntries(sorted);

      setUniqueEnquiryNos([...new Set(sorted.map(i => i.enquiryNo?.trim()).filter(Boolean))].sort());
      setUniqueJobCardNos([...new Set(sorted.map(i => i.jobCard_jobBookingNo?.trim()).filter(Boolean))].sort());

      const allStatuses = new Set();
      sorted.forEach(entry => workflowStages.forEach(stage => {
        const s = entry[`${stage.id}_status`];
        if (s && s !== '-' && s.trim()) allStatuses.add(s);
      }));
      setUniqueStatuses([...allStatuses].sort());

      setLoading(false);
      showSnackbar('Data loaded successfully', 'success');
    } catch (error) {
      setLoading(false);
      console.error('❌ Error:', error);
      showSnackbar('Failed to load data', 'error');
    }
  };

  // ─── Filters ──────────────────────────────────────────────────────────────
  useEffect(() => {
    const q = searchQuery.toLowerCase().trim();
    setFilteredEntries(entries.filter(entry => {
      const ms = !searchQuery ||
        entry.enquiryNo?.toLowerCase().includes(q) ||
        entry.customerName?.toLowerCase().includes(q) ||
        entry.titleName?.toLowerCase().includes(q) ||
        entry.jobCard_jobBookingNo?.toLowerCase().includes(q);

      const me = !filters.enquiryNo ||
        entry.enquiryNo?.trim().toUpperCase() === filters.enquiryNo.trim().toUpperCase();
      const mj = !filters.jobCardNo ||
        entry.jobCard_jobBookingNo?.trim().toUpperCase() === filters.jobCardNo.trim().toUpperCase();
      const mc = !filters.currentStatus ||
        workflowStages.some(stage => {
          const s = entry[`${stage.id}_status`];
          return s && s.trim().toUpperCase() === filters.currentStatus.trim().toUpperCase();
        });
      const mf = !filters.fromDate || new Date(entry.enquiryDate) >= new Date(filters.fromDate);
      const mt = !filters.toDate   || new Date(entry.enquiryDate) <= new Date(filters.toDate);
      return ms && me && mj && mc && mf && mt;
    }));
  }, [entries, filters, searchQuery]);

  const handleFilterChange = (name, val) => setFilters(prev => ({ ...prev, [name]: val }));
  const clearFilters = () => { setFilters({ enquiryNo:'', jobCardNo:'', currentStatus:'', fromDate:'', toDate:'' }); setSearchQuery(''); };
  const handleSelectAll   = (e) => setSelectedEntries(e.target.checked ? filteredEntries.map(e => e.id) : []);
  const handleSelectEntry = (id) => setSelectedEntries(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);

  // ─── Edit dialog ──────────────────────────────────────────────────────────
  const handleEditStage = (entry, stageId) => {
    setCurrentEditEntry(entry);
    setCurrentEditStage(stageId);
    setEditFormData({
      doerName   : entry[`${stageId}_doerName`]    || '',
      actualDate : formatDateForInput(entry[`${stageId}_actualDate`]),
      plannedDate: formatDateForInput(entry[`${stageId}_plannedDate`]),
      status     : entry[`${stageId}_status`]      || '',
      delayReason: entry[`${stageId}_delayReason`] || '',
      docNo      : entry[`${stageId}_dcNo`] || entry[`${stageId}_invoiceNo`] || '',
    });
    setEditDialogOpen(true);
  };

  const handleSaveStage = async () => {
    try {
      const payload = {
        EnquiryID  : parseInt(currentEditEntry.id),
        StageType  : currentEditStage,
        DoerName   : editFormData.doerName,
        ActualDate : editFormData.actualDate  ? new Date(editFormData.actualDate).toISOString()  : null,
        PlannedDate: editFormData.plannedDate ? new Date(editFormData.plannedDate).toISOString() : null,
        Status     : editFormData.status,
        DelayReason: editFormData.delayReason,
        DocNo      : editFormData.docNo,
        ModifiedBy : 1
      };
      const response = await postRequest('UpdateStageInfo', payload);
      if (response?.success) {
        showSnackbar('Stage updated successfully', 'success');
        setEditDialogOpen(false);
        fetchOrderFlowData();
      } else {
        showSnackbar('Failed to update stage', 'error');
      }
    } catch (error) {
      console.error('Error updating stage:', error);
      showSnackbar('Error updating stage', 'error');
    }
  };

  const handleDeleteSelected = async () => {
    if (selectedEntries.length === 0) return;
    if (!window.confirm(`Delete ${selectedEntries.length} enquirie(s)?`)) return;
    try {
      const response = await postRequest('DeleteEnquiries', {
        EnquiryIDs: selectedEntries.map(id => parseInt(id)), ModifiedBy: 1
      });
      if (response?.success) {
        showSnackbar(response.message || 'Deleted successfully', 'success');
        setSelectedEntries([]);
        fetchOrderFlowData();
      } else { showSnackbar('Failed to delete', 'error'); }
    } catch (e) { console.error(e); showSnackbar('Error deleting', 'error'); }
  };

  const handleExport = (exportType) => {
    try {
      const data = selectedEntries.length > 0
        ? filteredEntries.filter(e => selectedEntries.includes(e.id))
        : filteredEntries;
      if (!data.length) { showSnackbar('No data to export', 'warning'); return; }

      const flat = data.map(e => {
        const row = {
          'Enquiry Date': formatDate(e.enquiryDate), 'Enquiry No': e.enquiryNo,
          'Customer Name': e.customerName, 'Title Name': e.titleName,
          'Pages': e.pages, 'Qty': e.qty, 'Type of Binding': e.typeOfBinding,
        };
        workflowStages.forEach(stage => {
          stage.columns.forEach(col => {
            row[`${stage.stepNumber} ${stage.name} - ${col}`] = col.includes('Date')
              ? formatDate(e[`${stage.id}_${col}`])
              : e[`${stage.id}_${col}`] || '';
          });
        });
        return row;
      });

      const ws = XLSX.utils.json_to_sheet(flat);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Production Flow');
      if (exportType === 'excel') {
        XLSX.writeFile(wb, `ProductionFlow_${new Date().toISOString().split('T')[0]}.xlsx`);
        showSnackbar('Exported to Excel', 'success');
      } else {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([XLSX.utils.sheet_to_csv(ws)], { type: 'text/csv' }));
        a.download = `ProductionFlow_${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        showSnackbar('Exported to CSV', 'success');
      }
      setExportMenuAnchor(null);
    } catch (e) { console.error(e); showSnackbar('Export error', 'error'); }
  };

  // ─── Column resizer ────────────────────────────────────────────────────────
  const ColumnResizer = ({ columnKey }) => {
    const isActive = resizeStateRef.current.isResizing && resizeStateRef.current.columnKey === columnKey;
    return (
      <Box onMouseDown={(e) => handleMouseDown(e, columnKey)} sx={{
        position: 'absolute', right: -2, top: 0, width: '4px', height: '100%',
        cursor: 'col-resize', userSelect: 'none', zIndex: 100,
        backgroundColor: isActive ? '#3b82f6' : 'transparent',
        '&:hover': { backgroundColor: '#3b82f6' },
      }} />
    );
  };

  const headerLabels = {
    jobBookingNo: 'Job Booking No', dcNo: 'DC No', invoiceNo: 'Invoice No',
    plannedDate: 'Plan Date', actualDate: 'Actual Date',
    daysDelay: 'Days Delay', status: 'Current Status',
    delayReason: 'Delay Reason', doerName: 'Doer Name'
  };

  const getStatusOptions = (stageId) => {
    const stage = workflowStages.find(s => s.id === stageId);
    if (stage?.statusOptions) return stage.statusOptions;
    return ['Pending', 'In Process', 'Done', 'Completed'];
  };

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <Box sx={{ p: 2, bgcolor: '#f8fafc', minHeight: '100vh' }}>
      {loading && (
        <Box sx={{ position:'fixed', inset:0, bgcolor:'rgba(255,255,255,0.15)', backdropFilter:'blur(1px)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:9999 }}>
          <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center', gap:1 }}>
            <CircularProgress size={40} thickness={4} sx={{ color:'#0f766e' }} />
            <Typography variant="body2" sx={{ fontWeight:600, color:'#0f766e' }}>Loading...</Typography>
          </Box>
        </Box>
      )}

      <Typography variant="caption" sx={{ display:'block', textAlign:'center', letterSpacing:4, fontWeight:700, color:'text.secondary', mb:3 }}>
        ORDER BOOKING TO INVOICE - FMS
      </Typography>

      <Paper elevation={2} sx={{ borderRadius:2, overflow:'hidden' }}>

        {/* ── Toolbar ── */}
        <Box sx={{ p:1.5, bgcolor:'#f1f5f9', borderBottom:'1px solid #e2e8f0' }}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Tooltip title="Toggle Filters">
              <IconButton size="small" onClick={() => setShowFilters(!showFilters)}
                sx={{ border:'1px solid #cbd5e1', borderRadius:1, bgcolor: showFilters ? '#0f766e' : 'white', color: showFilters ? 'white' : 'inherit' }}>
                <Filter size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Column Settings">
              <IconButton size="small" onClick={(e) => setColumnMenuAnchor(e.currentTarget)}
                sx={{ border:'1px solid #cbd5e1', borderRadius:1, bgcolor:'white' }}>
                <Settings size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Refresh">
              <IconButton size="small" onClick={fetchOrderFlowData} disabled={loading}
                sx={{ border:'1px solid #cbd5e1', borderRadius:1, bgcolor:'white' }}>
                <RefreshCw size={18} />
              </IconButton>
            </Tooltip>
            <TextField size="small" placeholder="Search..." value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              sx={{ bgcolor:'white', width:220 }}
              InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} /></InputAdornment> }} />
            <Box sx={{ flexGrow:1 }} />
            <Button size="small" variant="contained" startIcon={<FileDown size={16} />}
              onClick={(e) => setExportMenuAnchor(e.currentTarget)}
              sx={{ bgcolor:'#3b82f6', borderRadius:1 }}>
              EXPORT
            </Button>
            <Button size="small" variant="contained" color="error"
              disabled={selectedEntries.length === 0}
              startIcon={<Trash2 size={16} />}
              onClick={handleDeleteSelected}
              sx={{ borderRadius:1 }}>
              DELETE ({selectedEntries.length})
            </Button>
            <Chip
              label={`${filteredEntries.length} / ${entries.length} Records`}
              size="small"
              sx={{ bgcolor: filteredEntries.length === entries.length ? '#10b981' : '#3b82f6', color:'white', fontWeight:700, fontSize:'0.75rem', height:'28px' }}
            />
          </Stack>
        </Box>

        <Menu anchorEl={exportMenuAnchor} open={Boolean(exportMenuAnchor)} onClose={() => setExportMenuAnchor(null)}>
          <MenuItem onClick={() => handleExport('excel')}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to Excel</ListItemText></MenuItem>
          <MenuItem onClick={() => handleExport('csv')}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to CSV</ListItemText></MenuItem>
        </Menu>

        <Menu anchorEl={columnMenuAnchor} open={Boolean(columnMenuAnchor)} onClose={() => setColumnMenuAnchor(null)}>
          <Typography variant="overline" sx={{ px:2, fontWeight:900 }}>Columns</Typography>
          {Object.keys(visibleColumns).map((key) => (
            <MenuItem key={key} onClick={() => toggleColumn(key)} sx={{ py:0.5 }}>
              <ListItemIcon>{visibleColumns[key] ? <Eye size={16} /> : <EyeOff size={16} />}</ListItemIcon>
              <ListItemText primary={key.replace(/([A-Z])/g,' $1').toUpperCase()} primaryTypographyProps={{ fontSize:'0.75rem' }} />
              <Checkbox size="small" checked={visibleColumns[key]} color="primary" />
            </MenuItem>
          ))}
        </Menu>

        {showFilters && (
          <Box sx={{ p:1.5, bgcolor:'#f8fafc', borderBottom:'1px solid #e2e8f0' }}>
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
              <Autocomplete freeSolo options={uniqueEnquiryNos} value={filters.enquiryNo||''}
                onChange={(_,v) => handleFilterChange('enquiryNo', v||'')}
                onInputChange={(_,v) => handleFilterChange('enquiryNo', v||'')}
                renderInput={(p) => <TextField {...p} label="Enquiry No" size="small" />} sx={{ width:160 }} />
              <Autocomplete freeSolo options={uniqueJobCardNos} value={filters.jobCardNo||''}
                onChange={(_,v) => handleFilterChange('jobCardNo', v||'')}
                onInputChange={(_,v) => handleFilterChange('jobCardNo', v||'')}
                renderInput={(p) => <TextField {...p} label="Job Card No" size="small" />} sx={{ width:160 }} />
              <Autocomplete freeSolo options={uniqueStatuses} value={filters.currentStatus||''}
                onChange={(_,v) => handleFilterChange('currentStatus', v||'')}
                onInputChange={(_,v) => handleFilterChange('currentStatus', v||'')}
                renderInput={(p) => <TextField {...p} label="Status" size="small" />} sx={{ width:160 }} />
              <TextField sx={{ width:160 }} label="From Date" type="date" size="small"
                InputLabelProps={{ shrink:true }} value={filters.fromDate||''}
                onChange={(e) => handleFilterChange('fromDate', e.target.value)} />
              <TextField sx={{ width:160 }} label="To Date" type="date" size="small"
                InputLabelProps={{ shrink:true }} value={filters.toDate||''}
                onChange={(e) => handleFilterChange('toDate', e.target.value)} />
              <Button size="small" color="error" onClick={clearFilters}><RotateCcw size={22} strokeWidth={3} /></Button>
            </Stack>
          </Box>
        )}

        {/* ── Table ── */}
        <TableContainer ref={tableRef} sx={{
          maxHeight:'75vh', overflow:'auto',
          '&::-webkit-scrollbar':{ display:'none' },
          scrollbarWidth:'none', msOverflowStyle:'none'
        }}>
          <Table size="small" stickyHeader sx={{ borderCollapse:'separate' }}>
            <TableHead>

              {/* ── Row 1: Step group headers ── */}
              <TableRow ref={row1Ref}>
                <TableCell colSpan={activeBaseColumnsCount} align="center"
                  sx={{ ...stickyRow1, bgcolor:'#cbd5e1', fontWeight:700, borderBottom:'2px solid #94a3b8', fontSize:'0.7rem', padding:'8px', whiteSpace:'nowrap' }}>
                  📋 SALES ENQUIRY DETAILS
                </TableCell>
                {workflowStages.map(stage => {
                  if (!visibleColumns[stage.id]) return null;
                  const deptName = getDepartmentNameForStage(stage.id);
                  return (
                    <TableCell key={stage.id} colSpan={stage.columns.length} align="center"
                      sx={{ ...stickyRow1, bgcolor:stage.bgColor, fontWeight:700, borderRight:'1px solid #cbd5e1', borderBottom:'2px solid #cbd5e1', padding:'8px 4px' }}>
                      <Typography variant="caption" sx={{ fontWeight:900, color:'#0f766e', display:'block', fontSize:'0.65rem' }}>{stage.stepNumber}</Typography>
                      <Typography variant="caption" sx={{ fontWeight:800, display:'block', fontSize:'0.7rem', mb:0.5 }}>{stage.name}</Typography>
                      <Typography variant="caption" sx={{ fontWeight:600, color:'#059669', display:'block', fontSize:'0.65rem', mb:0.5 }}>TAT: {stage.tatHours}hrs</Typography>
                      <Typography variant="caption" sx={{ fontWeight:600, color:'#059669', display:'block', fontSize:'0.65rem', mb:0.5 }}>Dept: {deptName || stage.tat}</Typography>
                    </TableCell>
                  );
                })}
              </TableRow>

              {/* ── Row 2: Column name headers ── */}
              <TableRow>
                <TableCell padding="checkbox" sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.checkbox, maxWidth:columnWidths.checkbox, borderRight:'1px solid #e0e0e0', position:'sticky' }}>
                  <Checkbox size="small" color="primary" onChange={handleSelectAll}
                    checked={selectedEntries.length === filteredEntries.length && filteredEntries.length > 0} />
                  <ColumnResizer columnKey="checkbox" />
                </TableCell>
                {visibleColumns.enquiryDate   && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.enquiryDate,   maxWidth:columnWidths.enquiryDate,   fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Enquiry Date    <ColumnResizer columnKey="enquiryDate"   /></TableCell>}
                {visibleColumns.enquiryNo     && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.enquiryNo,     maxWidth:columnWidths.enquiryNo,     fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Enquiry No      <ColumnResizer columnKey="enquiryNo"     /></TableCell>}
                {visibleColumns.customerName  && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.customerName,  maxWidth:columnWidths.customerName,  fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Customer Name   <ColumnResizer columnKey="customerName"  /></TableCell>}
                {visibleColumns.titleName     && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.titleName,     maxWidth:columnWidths.titleName,     fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Title Name      <ColumnResizer columnKey="titleName"     /></TableCell>}
                {visibleColumns.sizeWidth     && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.sizeWidth,     maxWidth:columnWidths.sizeWidth,     fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Size (L)        <ColumnResizer columnKey="sizeWidth"     /></TableCell>}
                {visibleColumns.sizeHeight    && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.sizeHeight,    maxWidth:columnWidths.sizeHeight,    fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Size (H)        <ColumnResizer columnKey="sizeHeight"    /></TableCell>}
                {visibleColumns.pages         && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.pages,         maxWidth:columnWidths.pages,         fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Pages           <ColumnResizer columnKey="pages"         /></TableCell>}
                {visibleColumns.qty           && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.qty,           maxWidth:columnWidths.qty,           fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Qty             <ColumnResizer columnKey="qty"           /></TableCell>}
                {visibleColumns.typeOfBinding && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.typeOfBinding, maxWidth:columnWidths.typeOfBinding, fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Type of Binding <ColumnResizer columnKey="typeOfBinding" /></TableCell>}
                {visibleColumns.action        && <TableCell sx={{ ...stickyRow2, bgcolor:'#f1f5f9', minWidth:columnWidths.action,        maxWidth:columnWidths.action,        fontWeight:700, color:'#0f766e', fontSize:'0.7rem', borderRight:'1px solid #e0e0e0', position:'sticky' }}>Action          <ColumnResizer columnKey="action"        /></TableCell>}

                {workflowStages.map(stage => {
                  if (!visibleColumns[stage.id]) return null;
                  return (
                    <React.Fragment key={stage.id}>
                      {stage.columns.map(colName => {
                        const columnKey = `${colName}-${stage.id}`;
                        return (
                          <TableCell key={columnKey} sx={{
                            ...stickyRow2, bgcolor:stage.bgColor,
                            minWidth:columnWidths[columnKey], maxWidth:columnWidths[columnKey],
                            fontWeight:600, fontSize:'0.7rem', position:'sticky',
                            textAlign: colName === 'daysDelay' || colName === 'status' ? 'center' : 'left',
                          }}>
                            {headerLabels[colName] || colName}
                            <ColumnResizer columnKey={columnKey} />
                          </TableCell>
                        );
                      })}
                    </React.Fragment>
                  );
                })}
              </TableRow>
            </TableHead>

            <TableBody>
              {filteredEntries.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={100} align="center" sx={{ py:5 }}>
                    {loading ? '' : 'No data found'}
                  </TableCell>
                </TableRow>
              ) : (
                filteredEntries.map((entry, idx) => {
                  const rowBg = idx % 2 === 0 ? 'white' : '#f8fafc';
                  return (
                    <TableRow key={entry.id} hover>
                      <TableCell padding="checkbox" sx={{ bgcolor:rowBg, minWidth:columnWidths.checkbox, maxWidth:columnWidths.checkbox }}>
                        <Checkbox size="small" color="primary"
                          checked={selectedEntries.includes(entry.id)}
                          onChange={() => handleSelectEntry(entry.id)} />
                      </TableCell>
                      {visibleColumns.enquiryDate   && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.enquiryDate,   maxWidth:columnWidths.enquiryDate,   fontSize:'0.75rem' }}>{formatDate(entry.enquiryDate)}</TableCell>}
                      {visibleColumns.enquiryNo     && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.enquiryNo,     maxWidth:columnWidths.enquiryNo,     fontWeight:700, fontSize:'0.75rem' }}>{entry.enquiryNo}</TableCell>}
                      {visibleColumns.customerName  && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.customerName,  maxWidth:columnWidths.customerName,  fontWeight:600, fontSize:'0.75rem' }}>{entry.customerName}</TableCell>}
                      {visibleColumns.titleName     && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.titleName,     maxWidth:columnWidths.titleName,     fontWeight:600, fontSize:'0.75rem' }}>{entry.titleName}</TableCell>}
                      {visibleColumns.sizeWidth     && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.sizeWidth,     maxWidth:columnWidths.sizeWidth,     fontSize:'0.75rem', textAlign:'center' }}>{entry.sizeWidth  || '-'}</TableCell>}
                      {visibleColumns.sizeHeight    && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.sizeHeight,    maxWidth:columnWidths.sizeHeight,    fontSize:'0.75rem', textAlign:'center' }}>{entry.sizeHeight || '-'}</TableCell>}
                      {visibleColumns.pages         && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.pages,         maxWidth:columnWidths.pages,         fontSize:'0.75rem', textAlign:'center' }}>{entry.pages      || '-'}</TableCell>}
                      {visibleColumns.qty           && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.qty,           maxWidth:columnWidths.qty,           fontSize:'0.75rem', textAlign:'center' }}>{entry.qty        || '-'}</TableCell>}
                      {visibleColumns.typeOfBinding && <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.typeOfBinding, maxWidth:columnWidths.typeOfBinding, fontSize:'0.75rem' }}>{entry.typeOfBinding || '-'}</TableCell>}
                      {visibleColumns.action && (
                        <TableCell sx={{ bgcolor:rowBg, minWidth:columnWidths.action, maxWidth:columnWidths.action }}>
                          <Stack direction="row" spacing={0.5}>
                            <Tooltip title="View Details"><IconButton size="small" color="primary"><Info size={14} /></IconButton></Tooltip>
                            <Tooltip title="Edit Stage"><IconButton size="small" color="secondary" onClick={() => handleEditStage(entry, 'jobCard')}><Edit size={14} /></IconButton></Tooltip>
                          </Stack>
                        </TableCell>
                      )}

                      {workflowStages.map(stage => {
                        if (!visibleColumns[stage.id]) return null;
                        return (
                          <React.Fragment key={stage.id}>
                            {stage.columns.map(colName => {
                              const columnKey = `${colName}-${stage.id}`;
                              const fieldKey  = `${stage.id}_${colName}`;

                              // Special doc number columns
                              if (['jobBookingNo', 'dcNo', 'invoiceNo'].includes(colName)) return (
                                <TableCell key={columnKey} sx={{ bgcolor:stage.bgColor, fontSize:'0.75rem', fontWeight:700, color:'#0f766e', minWidth:columnWidths[columnKey], maxWidth:columnWidths[columnKey] }}>
                                  {entry[fieldKey] || '-'}
                                </TableCell>
                              );

                              if (colName === 'plannedDate' || colName === 'actualDate') return (
                                <TableCell key={columnKey} sx={{ bgcolor:stage.bgColor, fontSize:'0.75rem', minWidth:columnWidths[columnKey], maxWidth:columnWidths[columnKey] }}>
                                  {formatDate(entry[fieldKey]) || '-'}
                                </TableCell>
                              );

                              if (colName === 'daysDelay') return (
                                <TableCell key={columnKey} align="center" sx={{ bgcolor:stage.bgColor, minWidth:columnWidths[columnKey], padding:'6px 8px' }}>
                                  <DaysDelayCell delayText={entry[fieldKey]} />
                                </TableCell>
                              );

                              if (colName === 'status') return (
                                <TableCell key={columnKey} align="center" sx={{ bgcolor:stage.bgColor, minWidth:columnWidths[columnKey], padding:'6px 8px' }}>
                                  <StatusCell
                                    status={entry[fieldKey]}
                                    stageId={stage.id}
                                    daysDelay={entry[`${stage.id}_daysDelay`]}
                                  />
                                </TableCell>
                              );

                              if (colName === 'delayReason') return (
                                <TableCell key={columnKey} sx={{ bgcolor:stage.bgColor, color: entry[fieldKey] ? '#ea580c' : '#6b7280', fontWeight:600, fontSize:'0.7rem', minWidth:columnWidths[columnKey], maxWidth:columnWidths[columnKey], overflow:'hidden', textOverflow:'ellipsis' }}>
                                  {entry[fieldKey] || '-'}
                                </TableCell>
                              );

                              if (colName === 'doerName') return (
                                <TableCell key={columnKey} sx={{ bgcolor:stage.bgColor, fontSize:'0.75rem', minWidth:columnWidths[columnKey], maxWidth:columnWidths[columnKey], fontWeight:600, color: entry[fieldKey] ? '#0f766e' : '#6b7280' }}>
                                  {entry[fieldKey] || '-'}
                                </TableCell>
                              );

                              return null;
                            })}
                          </React.Fragment>
                        );
                      })}
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* ── Edit Dialog ── */}
      <Dialog open={editDialogOpen} onClose={() => setEditDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Stack direction="row" alignItems="center" justifyContent="space-between">
            <Typography variant="h6">
              Edit — {workflowStages.find(s => s.id === currentEditStage)?.name || currentEditStage}
            </Typography>
            <IconButton size="small" onClick={() => setEditDialogOpen(false)}><X size={18} /></IconButton>
          </Stack>
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt:1 }}>
            {/* DC No for delivery, Invoice No for invoice */}
            {(currentEditStage === 'deliveryStatus' || currentEditStage === 'invoiceStatus') && (
              <Grid item xs={12}>
                <TextField fullWidth size="small"
                  label={currentEditStage === 'deliveryStatus' ? 'DC No' : 'Invoice No'}
                  value={editFormData.docNo || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, docNo: e.target.value })} />
              </Grid>
            )}
            <Grid item xs={12}>
              <FormControl fullWidth size="small">
                <InputLabel>Doer Name</InputLabel>
                <Select value={editFormData.doerName || ''} label="Doer Name"
                  onChange={(e) => setEditFormData({ ...editFormData, doerName: e.target.value })}>
                  <MenuItem value="">None</MenuItem>
                  {allUsers.map(user => (<MenuItem key={user} value={user}>{user}</MenuItem>))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={6}>
              <TextField fullWidth size="small" label="Planned Date" type="date"
                InputLabelProps={{ shrink:true }} value={editFormData.plannedDate || ''}
                onChange={(e) => setEditFormData({ ...editFormData, plannedDate: e.target.value })} />
            </Grid>
            <Grid item xs={6}>
              <TextField fullWidth size="small" label="Actual Date" type="date"
                InputLabelProps={{ shrink:true }} value={editFormData.actualDate || ''}
                onChange={(e) => setEditFormData({ ...editFormData, actualDate: e.target.value })} />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth size="small">
                <InputLabel>Status</InputLabel>
                <Select value={editFormData.status || ''} label="Status"
                  onChange={(e) => setEditFormData({ ...editFormData, status: e.target.value })}>
                  <MenuItem value="">None</MenuItem>
                  {getStatusOptions(currentEditStage).map(opt => (
                    <MenuItem key={opt} value={opt}>{opt}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField fullWidth size="small" label="Delay Reason" multiline rows={3}
                value={editFormData.delayReason || ''}
                onChange={(e) => setEditFormData({ ...editFormData, delayReason: e.target.value })} />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDialogOpen(false)} color="inherit">Cancel</Button>
          <Button onClick={handleSaveStage} variant="contained" startIcon={<Save size={16} />}>Save</Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={snackbar.open} autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical:'bottom', horizontal:'right' }}>
        <Alert severity={snackbar.severity} variant="filled">{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default OrderBookingtoInvoice;