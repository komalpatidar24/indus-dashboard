import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  Filter, Search, Info,
  FileDown, RefreshCw, Settings, Eye, EyeOff, RotateCcw
} from "lucide-react";
import { postRequest } from '../api/api';
import {
  IconButton, Tooltip, Snackbar, Alert, Button, Menu, MenuItem,
  Box, Typography, Paper, TextField, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Checkbox, FormControl,
  InputLabel, Select, Stack, CircularProgress, Chip,
  InputAdornment, ListItemIcon, ListItemText, Autocomplete
} from '@mui/material';
import * as XLSX from 'xlsx';

// ─── strip helper ─────────────────────────────────────────────────────────────
// Removes all non-alpha chars and lowercases → used for fuzzy column matching
const stripKey = (str) => String(str || '').toLowerCase().replace(/[^a-z]/g, '');

// ─── Kitting-1 display columns ────────────────────────────────────────────────
const KITTING1_COLUMNS = [
  "Book Cover",
  "Book Pages",
  "Contractor PO",
  "Material requisition",
  "Text Paper",
  "Cover Paper/PLC",
  "End Paper",
  "Board",
  "Jacket",
  "Text Plates",
  "Cover/PLC Plates ",
  "End Paper Plates ",
  "Jacket Plates ",
  "Dummy",
  "Customer Sample /Digital ",
  "Ferro "
];

// Build reverse map: stripped → display name
// e.g. "bookcover" → "Book Cover", "textpaper" → "Text Paper"
const COL_MAP = {};
KITTING1_COLUMNS.forEach(col => { COL_MAP[stripKey(col)] = col; });

// Given API PlanContentType → returns matching display column name or null
const resolveCol = (planContentType) => {
  const key = stripKey(planContentType || '');
  return COL_MAP[key] || null;
};

// ─── Kitting-2 display columns ────────────────────────────────────────────────
const KITTING2_COLUMNS = ["Die", "Block", "Die Positive", "Lamination", "Foil", "Others"];

// ─── Progressive stage display ────────────────────────────────────────────────
// Shows the most advanced workflow stage value reached for a content item
const getContentStageDisplay = (d) => {
  if (!d) return '-';
  const v = (x) => x && String(x).trim() !== '' && String(x).trim() !== 'null' ? String(x).trim() : null;
  if (v(d.IssueNo))  return v(d.status) || v(d.IssueNo);
  if (v(d.RECNo))    return v(d.RECNo);
  if (v(d.PONo))     return v(d.PONo);
  if (v(d.REQNo))    return v(d.REQNo);
  if (v(d.IndentNo)) return v(d.IndentNo);
  return '-';
};

const JobKitting = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [entries,          setEntries]          = useState([]);
  const [filteredEntries,  setFilteredEntries]  = useState([]);
  const [selectedEntries,  setSelectedEntries]  = useState([]);
  const [showFilters,      setShowFilters]      = useState(false);
  const [searchQuery,      setSearchQuery]      = useState('');
  const [loading,          setLoading]          = useState(false);
  const [snackbar,         setSnackbar]         = useState({ open: false, message: '', severity: 'success' });
  const [exportMenuAnchor, setExportMenuAnchor] = useState(null);
  const [columnMenuAnchor, setColumnMenuAnchor] = useState(null);

  const resizeStateRef = useRef({ isResizing: false, columnKey: null, startX: 0, startWidth: 0 });
  const [, forceUpdate] = useState({});
  const tableRef = useRef(null);

  const [visibleColumns, setVisibleColumns] = useState({
    jobCardNo: true, jobName: true, quantity: true,
    typeOfBook: true, action: true, jobKitting1: true, jobKitting2: true,
  });

  const [uniqueJobCardNos, setUniqueJobCardNos] = useState([]);
  const [uniqueStatuses,   setUniqueStatuses]   = useState([]);

  const [filters, setFilters] = useState({
    jobCardNo: '', currentStatus: '', fromDate: '', toDate: '',
  });

  const [jobKittingOneColumns, setJobKittingOneColumns] = useState([]);
  const [jobKittingTwoColumns, setJobKittingTwoColumns] = useState([]);

  const workflowStages = useMemo(() => [
    { id: 'jobKitting1', name: 'JOB KITTING - 1', stepNumber: 'Step 1', tat: 'Production', tatHours: 24, bgColor: '#f3e5f5', editable: true, showDeptName: true, columns: jobKittingOneColumns },
    { id: 'jobKitting2', name: 'JOB KITTING - 2', stepNumber: 'Step 2', tat: 'Production', tatHours: 24, bgColor: '#e3f2fd', editable: true, showDeptName: true, columns: jobKittingTwoColumns },
  ], [jobKittingOneColumns, jobKittingTwoColumns]);

  const [columnWidths, setColumnWidths] = useState({
    checkbox: 50, jobCardNo: 130, jobName: 180, quantity: 90, typeOfBook: 140, action: 90,
  });

  useEffect(() => {
    const w = { ...columnWidths };
    KITTING1_COLUMNS.forEach(col => { const k = `${col}-jobKitting1`; if (!w[k]) w[k] = 130; });
    KITTING2_COLUMNS.forEach(col => { const k = `${col}-jobKitting2`; if (!w[k]) w[k] = 130; });
    setColumnWidths(w);
  }, []); // eslint-disable-line

  const getDepartmentNameForStage = (stageId) => {
    if (!filteredEntries || filteredEntries.length === 0) return '';
    const deptNames = filteredEntries
      .map(entry => entry.stages[stageId]?.departmentName)
      .filter(name => typeof name === 'string' && name.trim() !== '');
    if (deptNames.length === 0) return '';
    const frequency = {};
    deptNames.forEach(name => { frequency[name] = (frequency[name] || 0) + 1; });
    return Object.keys(frequency).reduce((a, b) => frequency[a] > frequency[b] ? a : b);
  };

  const getStatusText = (status, daysDelay = null) => {
    if (!status || status === '-') return { text: '-', color: '#6b7280' };
    const s = status.toLowerCase();
    let textColor = '#6b7280';
    let displayText = status;
    const hasDelay = daysDelay && daysDelay !== '-' && (daysDelay.includes('day') || daysDelay.includes('+'));
    if      (s === 'pending' && hasDelay)                          { displayText = 'Delay'; textColor = '#ef4444'; }
    else if (s === 'pending')                                      { textColor = '#f59e0b'; }
    else if (s === 'done' || s === 'completed')                    { textColor = '#10b981'; }
    else if (['in progress', 'in process', 'running'].includes(s)) { textColor = '#f59e0b'; }
    else if (['approved', 'yes', 'confirmed'].includes(s))         { textColor = '#10b981'; }
    else if (['rejected', 'no', 'cancelled'].includes(s))          { textColor = '#ef4444'; }
    return { text: displayText, color: textColor };
  };

  const StatusCell = ({ status, daysDelay }) => {
    const { text, color } = getStatusText(status, daysDelay);
    return (
      <Typography sx={{ color, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
        {text}
      </Typography>
    );
  };

  const DaysDelayCell = ({ delayText }) => {
    const textStr = String(delayText || '-');
    let color = '#6b7280';
    if (!textStr || textStr === '-' || textStr === 'null' || textStr === 'undefined') color = '#6b7280';
    else if (textStr.toLowerCase().includes('on time')) color = '#10b981';
    else if (textStr.includes('min') || textStr.includes('hr'))  color = '#f59e0b';
    else if (textStr.includes('day')) color = '#ef4444';
    return (
      <Typography sx={{ color, fontWeight: 700, fontSize: '0.75rem', textAlign: 'center', whiteSpace: 'nowrap' }}>
        {textStr}
      </Typography>
    );
  };

  const toggleColumn = (key) => setVisibleColumns(prev => ({ ...prev, [key]: !prev[key] }));

  const activeBaseColumnsCount = useMemo(() =>
    ['jobCardNo','jobName','quantity','typeOfBook','action'].filter(k => visibleColumns[k]).length + 1,
  [visibleColumns]);

  const formatDate = (dateString) => {
    if (!dateString) return '';
    try {
      if (dateString.includes('-') && dateString.split('-')[2]?.length === 4) return dateString;
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return dateString;
      return `${String(date.getDate()).padStart(2,'0')}-${String(date.getMonth()+1).padStart(2,'0')}-${date.getFullYear()}`;
    } catch { return dateString; }
  };

  // ── Column resize ────────────────────────────────────────────────────────
  const handleMouseDown = useCallback((e, columnKey) => {
    e.preventDefault(); e.stopPropagation();
    resizeStateRef.current = { isResizing: true, columnKey, startX: e.clientX, startWidth: columnWidths[columnKey] || 130 };
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    forceUpdate({});
  }, [columnWidths]);

  const handleMouseMove = useCallback((e) => {
    if (!resizeStateRef.current.isResizing) return;
    const { columnKey, startX, startWidth } = resizeStateRef.current;
    setColumnWidths(prev => ({ ...prev, [columnKey]: Math.max(50, startWidth + (e.clientX - startX)) }));
  }, []);

  const handleMouseUp = useCallback(() => {
    if (resizeStateRef.current.isResizing) {
      resizeStateRef.current.isResizing = false;
      resizeStateRef.current.columnKey  = null;
      document.body.style.cursor     = '';
      document.body.style.userSelect = '';
      forceUpdate({});
    }
  }, []);

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup',   handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup',   handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  useEffect(() => { fetchJobKittingData(); }, []); // eslint-disable-line

  // ── Fetch & Transform ────────────────────────────────────────────────────
  const fetchJobKittingData = async () => {
    setLoading(true);
    try {
      const [jobDetailsRes, jobKitting1Res, jobKitting2Res, toolsRes] = await Promise.all([
        postRequest('GetJobDetail'),
        postRequest('GetJobKitting1'),
        postRequest('GetJobKitting2'),
        postRequest('GetTool'),
      ]);

      const toArr = (r) => {
        let d = Array.isArray(r) ? r : (r?.data ?? r);
        if (!Array.isArray(d)) d = d?.data ?? [];
        return Array.isArray(d) ? d : [];
      };

      const jobDetailsData = toArr(jobDetailsRes);
      const kitting1Raw    = toArr(jobKitting1Res);
      const kitting2Raw    = toArr(jobKitting2Res);
      // toolsRes available if needed later
      // const toolsData   = toArr(toolsRes);

      setJobKittingOneColumns(KITTING1_COLUMNS);
      setJobKittingTwoColumns(KITTING2_COLUMNS);

      // ── Build Kitting-1 map ───────────────────────────────────────────────
      // KEY  = String(JobBookingJobCardContentsID) — the foreign key present in EVERY kitting1 row
      //        and also present in jobDetails rows.
      // VALUE = { "Book Cover": { IndentNo, REQNo, PONo, RECNo, IssueNo, status }, ... }
      //
      // Each kitting1 row has a PlanContentType that maps to ONE display column.
      // We store the data ONLY under that resolved column — so "Book Cover" data
      // can NEVER bleed into the "Book Pages" column.
      //
      // We also keep fallback maps keyed by JobBookingID and JobCardNo so we can
      // still match even if ContentsID is missing.

      const mapByContentsID = {}; // primary   key: JobBookingJobCardContentsID
      const mapByBookingID  = {}; // secondary key: JobBookingID
      const mapByCardNo     = {}; // tertiary  key: JobCardNo

      const scoreEntry = (o) => o
        ? [o.IssueNo, o.RECNo, o.PONo, o.REQNo, o.IndentNo]
            .filter(v => v && String(v).trim() !== '').length
        : -1;

      const upsert = (map, rawKey, colName, dataObj) => {
        if (rawKey == null || String(rawKey).trim() === '' || !colName) return;
        const k = String(rawKey).trim().toUpperCase();
        if (!map[k]) map[k] = {};
        if (scoreEntry(dataObj) >= scoreEntry(map[k][colName])) {
          map[k][colName] = dataObj;
        }
      };

      kitting1Raw.forEach((item) => {
        // Resolve which display column this content type maps to
        const colName = resolveCol(item.PlanContentType ?? item.ContentType ?? '');
        if (!colName) {
          console.warn('⚠️ Unmapped PlanContentType:', item.PlanContentType);
          return;
        }

        const dataObj = {
          IndentNo: item.IndentNo ?? null,
          REQNo   : item.REQNo    ?? null,
          PONo    : item.PONo     ?? null,
          RECNo   : item.RECNo    ?? null,
          IssueNo : item.IssueNo  ?? null,
          status  : item.status   ?? item.Status ?? null,
        };

        // Store under all possible join keys
        upsert(mapByContentsID, item.JobBookingJobCardContentsID ?? item.JobBookingJobCardContentID, colName, dataObj);
        upsert(mapByBookingID,  item.JobBookingID ?? item.JobBookingId,                              colName, dataObj);
        upsert(mapByCardNo,     item.JobCardNo    ?? item.JobCardNumber,                             colName, dataObj);
      });

      // ── Build Kitting-2 map ───────────────────────────────────────────────
      // KEY = String(JobBookingID)
      const kitting2Map = {};
      kitting2Raw.forEach(item => {
        const id = String(item.JobBookingID ?? item.JobBookingId ?? '').trim().toUpperCase();
        if (!id) return;
        if (!kitting2Map[id]) kitting2Map[id] = {};
        const done = v => v && String(v).toLowerCase().trim() === 'done';
        if (done(item.Die))              kitting2Map[id]['Die']           = '✓';
        if (done(item.Block))            kitting2Map[id]['Block']         = '✓';
        if (done(item['Die Positive']))  kitting2Map[id]['Die Positive']  = '✓';
        if (done(item.Lamination))       kitting2Map[id]['Lamination']    = '✓';
        if (done(item.Foil))             kitting2Map[id]['Foil']          = '✓';
        if (item.Others && item.Others !== '-' && String(item.Others).trim())
          kitting2Map[id]['Others'] = '✓';
      });

      // ── De-duplicate jobDetails by JobCardNo ─────────────────────────────
      // The API returns one row PER CONTENT TYPE for the same job (same JobCardNo).
      // We need ONE table row per unique job — so we group them first.
      const jobMap = new Map(); // JobCardNo (string) → job metadata

      jobDetailsData.forEach((job) => {
        const jobCardNo    = String(job.JobCardNo ?? job.JobCardNumber ?? '').trim();
        const bookingIdKey = String(job.JobBookingID ?? job.JobBookingId ?? '').trim().toUpperCase();
        if (!jobCardNo) return;
        if (!jobMap.has(jobCardNo)) {
          jobMap.set(jobCardNo, {
            id          : jobCardNo,
            jobCardNo,
            jobName     : job.JobName     ?? job.TitleName ?? '',
            quantity    : job.Quantity    ?? job.Qty       ?? '',
            typeOfBook  : job.TypeOfBook  ?? job.BookType  ?? '',
            createdDate : job.CreatedDate ?? job.Date      ?? '',
            bookingIdKey,
            cardNoKey   : jobCardNo.toUpperCase(),
          });
        }
      });

      // ── Build transformed rows ────────────────────────────────────────────
      const transformed = Array.from(jobMap.values()).map((job) => {
        const { bookingIdKey, cardNoKey } = job;

        // Look up kitting-1 data using best available key
        // Priority: ContentsID (= bookingIdKey from jobDetails matches ContentsID) > CardNo > BookingID
        const k1ContentsId = mapByContentsID[bookingIdKey] ?? {};
        const k1BookingId  = mapByBookingID[bookingIdKey]  ?? {};
        const k1CardNo     = mapByCardNo[cardNoKey]        ?? {};

        // Merge: for each column pick the entry with most complete data
        const k1Stage = { departmentName: 'Job Kitting 1' };
        KITTING1_COLUMNS.forEach(col => {
          const a = k1ContentsId[col] ?? null;
          const b = k1BookingId[col]  ?? null;
          const c = k1CardNo[col]     ?? null;
          const candidates = [a, b, c].filter(Boolean);
          if (candidates.length === 0) { k1Stage[col] = null; return; }
          k1Stage[col] = candidates.reduce((best, cur) =>
            scoreEntry(cur) >= scoreEntry(best) ? cur : best
          );
        });

        // Kitting-2: keyed by JobBookingID
        const k2Data  = kitting2Map[bookingIdKey] ?? {};
        const k2Stage = { departmentName: 'Job Kitting 2' };
        KITTING2_COLUMNS.forEach(col => { k2Stage[col] = k2Data[col] ?? '-'; });

        return {
          id         : job.id,
          jobCardNo  : job.jobCardNo,
          jobName    : job.jobName,
          quantity   : job.quantity,
          typeOfBook : job.typeOfBook,
          createdDate: job.createdDate,
          stages     : { jobKitting1: k1Stage, jobKitting2: k2Stage },
        };
      });

      const sortedData = [...transformed].sort((a, b) => b.jobCardNo.localeCompare(a.jobCardNo));
      setEntries(sortedData);

      const jobCardNos = [...new Set(sortedData.map(i => i.jobCardNo).filter(Boolean))].sort();

      // Collect all unique status values for the status filter
      const allStatuses = new Set();
      sortedData.forEach(entry => {
        KITTING1_COLUMNS.forEach(col => {
          const d = entry.stages.jobKitting1[col];
          if (d?.status) allStatuses.add(d.status);
        });
      });

      setUniqueJobCardNos(jobCardNos);
      setUniqueStatuses([...allStatuses].sort());
      setLoading(false);
      showSnackbar('Data loaded successfully', 'success');

    } catch (error) {
      setLoading(false);
      console.error('Error fetching data:', error);
      showSnackbar('Failed to load data', 'error');
    }
  };

  // ── Filter ───────────────────────────────────────────────────────────────
  useEffect(() => {
    const q = searchQuery.toLowerCase().trim();
    setFilteredEntries(entries.filter(entry => {
      const matchesSearch = !q ||
        entry.jobCardNo?.toLowerCase().includes(q)  ||
        entry.jobName?.toLowerCase().includes(q)    ||
        entry.typeOfBook?.toLowerCase().includes(q);

      const matchesJobCardNo = !filters.jobCardNo ||
        entry.jobCardNo?.trim().toUpperCase() === filters.jobCardNo.trim().toUpperCase();

      // Status filter: check if ANY kitting1 column's status matches
      const matchesStatus = !filters.currentStatus ||
        KITTING1_COLUMNS.some(col => {
          const d = entry.stages.jobKitting1[col];
          return d?.status && d.status.trim().toUpperCase() === filters.currentStatus.trim().toUpperCase();
        });

      const matchesFromDate = !filters.fromDate ||
        (entry.createdDate && new Date(entry.createdDate) >= new Date(filters.fromDate));

      const matchesToDate = !filters.toDate ||
        (entry.createdDate && new Date(entry.createdDate) <= new Date(filters.toDate));

      return matchesSearch && matchesJobCardNo && matchesStatus && matchesFromDate && matchesToDate;
    }));
  }, [entries, filters, searchQuery]);

  const handleFilterChange = (name, val) => setFilters(prev => ({ ...prev, [name]: val }));
  const clearFilters = () => {
    setFilters({ jobCardNo: '', currentStatus: '', fromDate: '', toDate: '' });
    setSearchQuery('');
  };

  const handleSelectAll   = (e) => setSelectedEntries(e.target.checked ? filteredEntries.map(e => e.id) : []);
  const handleSelectEntry = (id) => setSelectedEntries(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  const showSnackbar      = (message, severity = 'success') => setSnackbar({ open: true, message, severity });

  // ── Export ───────────────────────────────────────────────────────────────
  const handleExport = async (exportType) => {
    try {
      const dataToExport = selectedEntries.length > 0
        ? filteredEntries.filter(e => selectedEntries.includes(e.id))
        : filteredEntries;
      if (!dataToExport.length) { showSnackbar('No data to export', 'warning'); return; }

      const flattenedData = dataToExport.map(entry => {
        const row = {
          'Job Card No' : entry.jobCardNo,
          'Job Name'    : entry.jobName,
          'Quantity'    : entry.quantity,
          'Type of Book': entry.typeOfBook,
        };
        KITTING1_COLUMNS.forEach(col => {
          row[`JK1 - ${col}`] = getContentStageDisplay(entry.stages.jobKitting1[col]);
        });
        KITTING2_COLUMNS.forEach(col => {
          row[`JK2 - ${col}`] = entry.stages.jobKitting2[col] || '-';
        });
        return row;
      });

      const ws = XLSX.utils.json_to_sheet(flattenedData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Job Kitting');
      const fn = `JobKitting_${new Date().toISOString().split('T')[0]}`;

      if (exportType === 'excel') {
        XLSX.writeFile(wb, `${fn}.xlsx`);
        showSnackbar('Exported to Excel successfully', 'success');
      } else {
        const a = document.createElement('a');
        a.href     = URL.createObjectURL(new Blob([XLSX.utils.sheet_to_csv(ws)], { type: 'text/csv' }));
        a.download = `${fn}.csv`;
        a.click();
        showSnackbar('Exported to CSV successfully', 'success');
      }
      setExportMenuAnchor(null);
    } catch (error) {
      console.error('Error exporting:', error);
      showSnackbar('Error exporting data', 'error');
    }
  };

  // ── Column resizer component ─────────────────────────────────────────────
  const ColumnResizer = ({ columnKey }) => {
    const isActive = resizeStateRef.current.isResizing && resizeStateRef.current.columnKey === columnKey;
    return (
      <Box
        onMouseDown={(e) => handleMouseDown(e, columnKey)}
        sx={{
          position: 'absolute', right: -2, top: 0, width: '4px', height: '100%',
          cursor: 'col-resize', userSelect: 'none', zIndex: 100,
          backgroundColor: isActive ? '#3b82f6' : 'transparent',
          '&:hover': { backgroundColor: '#3b82f6' },
          '&:active': { backgroundColor: '#2563eb' },
        }}
      />
    );
  };

  const formatColumnHeader = (colName) => {
    if (!colName) return '';
    return String(colName).replace(/([A-Z])/g, ' $1').replace(/_/g, ' ').trim()
      .split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
  };

  // ── Render ───────────────────────────────────────────────────────────────
  return (
    <Box sx={{ p: 2, bgcolor: '#f8fafc', minHeight: '100vh' }}>
      {loading && (
        <Box sx={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, bgcolor: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(1px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
            <CircularProgress size={40} thickness={4} sx={{ color: '#0f766e' }} />
            <Typography variant="body2" sx={{ fontWeight: 600, color: '#0f766e' }}>Loading...</Typography>
          </Box>
        </Box>
      )}

      <Typography variant="caption" sx={{ display: 'block', textAlign: 'center', letterSpacing: 4, fontWeight: 700, color: 'text.secondary', mb: 3 }}>
        JOB KITTING WORKFLOW - FMS
      </Typography>

      <Paper elevation={2} sx={{ borderRadius: 2, overflow: 'hidden' }}>

        {/* ── Toolbar ── */}
        <Box sx={{ p: 1.5, bgcolor: '#f1f5f9', borderBottom: '1px solid #e2e8f0' }}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Tooltip title="Toggle Filters">
              <IconButton size="small" onClick={() => setShowFilters(!showFilters)}
                sx={{ border: '1px solid #cbd5e1', borderRadius: 1, bgcolor: showFilters ? '#0f766e' : 'white', color: showFilters ? 'white' : 'inherit' }}>
                <Filter size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Column Settings">
              <IconButton size="small" onClick={(e) => setColumnMenuAnchor(e.currentTarget)}
                sx={{ border: '1px solid #cbd5e1', borderRadius: 1, bgcolor: 'white' }}>
                <Settings size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Refresh Data">
              <IconButton size="small" onClick={fetchJobKittingData} disabled={loading}
                sx={{ border: '1px solid #cbd5e1', borderRadius: 1, bgcolor: 'white' }}>
                <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
              </IconButton>
            </Tooltip>
            <TextField size="small" placeholder="Search..." value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              sx={{ bgcolor: 'white', width: 220 }}
              InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} /></InputAdornment> }} />
            <Box sx={{ flexGrow: 1 }} />
            <Tooltip title="Export Data">
              <Button size="small" variant="contained" startIcon={<FileDown size={16} />}
                onClick={(e) => setExportMenuAnchor(e.currentTarget)}
                sx={{ bgcolor: '#3b82f6', borderRadius: 1 }}>
                EXPORT
              </Button>
            </Tooltip>
            <Chip
              label={`${filteredEntries.length} / ${entries.length} Records`}
              size="small"
              sx={{
                bgcolor: filteredEntries.length === entries.length ? '#10b981' : '#3b82f6',
                color: 'white', fontWeight: 700, fontSize: '0.75rem', height: '28px',
              }}
            />
          </Stack>
        </Box>

        {/* Export menu */}
        <Menu anchorEl={exportMenuAnchor} open={Boolean(exportMenuAnchor)} onClose={() => setExportMenuAnchor(null)}>
          <MenuItem onClick={() => handleExport('excel')}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to Excel</ListItemText></MenuItem>
          <MenuItem onClick={() => handleExport('csv')}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to CSV</ListItemText></MenuItem>
        </Menu>

        {/* Column visibility menu */}
        <Menu anchorEl={columnMenuAnchor} open={Boolean(columnMenuAnchor)} onClose={() => setColumnMenuAnchor(null)}>
          <Typography variant="overline" sx={{ px: 2, fontWeight: 900 }}>Columns</Typography>
          {Object.keys(visibleColumns).map((key) => (
            <MenuItem key={key} onClick={() => toggleColumn(key)} sx={{ py: 0.5 }}>
              <ListItemIcon>{visibleColumns[key] ? <Eye size={16} /> : <EyeOff size={16} />}</ListItemIcon>
              <ListItemText primary={key.replace(/([A-Z])/g, ' $1').toUpperCase()} primaryTypographyProps={{ fontSize: '0.75rem' }} />
              <Checkbox size="small" checked={visibleColumns[key]} color="primary" />
            </MenuItem>
          ))}
        </Menu>

        {/* ── Filters ── */}
        {showFilters && (
          <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
              <Autocomplete freeSolo options={uniqueJobCardNos} value={filters.jobCardNo || ''}
                onChange={(_, v) => handleFilterChange('jobCardNo', v || '')}
                onInputChange={(_, v) => handleFilterChange('jobCardNo', v || '')}
                renderInput={(p) => <TextField {...p} label="Job Card No" size="small" />}
                sx={{ width: 160 }} />
              <Autocomplete freeSolo options={uniqueStatuses} value={filters.currentStatus || ''}
                onChange={(_, v) => handleFilterChange('currentStatus', v || '')}
                onInputChange={(_, v) => handleFilterChange('currentStatus', v || '')}
                renderInput={(p) => <TextField {...p} label="Status" size="small" />}
                sx={{ width: 160 }} />
              <TextField sx={{ width: 160 }} label="From Date" type="date" size="small"
                InputLabelProps={{ shrink: true }} value={filters.fromDate || ''}
                onChange={(e) => handleFilterChange('fromDate', e.target.value)} />
              <TextField sx={{ width: 160 }} label="To Date" type="date" size="small"
                InputLabelProps={{ shrink: true }} value={filters.toDate || ''}
                onChange={(e) => handleFilterChange('toDate', e.target.value)} />
              <Button size="small" color="error" onClick={clearFilters} sx={{ fontWeight: 700 }}>
                <RotateCcw size={22} strokeWidth={3} />
              </Button>
            </Stack>
          </Box>
        )}

        {/* ── Table ── */}
        <TableContainer ref={tableRef} sx={{ maxHeight: '75vh', overflow: 'auto', '&::-webkit-scrollbar': { display: 'none' }, scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
          <Table size="small" sx={{ borderCollapse: 'separate' }}>
            <TableHead>

              {/* Row 1: group headers */}
              <TableRow>
                <TableCell colSpan={activeBaseColumnsCount} align="center"
                  sx={{ bgcolor: '#cbd5e1', fontWeight: 700, borderBottom: '2px solid #94a3b8', fontSize: '0.7rem', padding: '8px', whiteSpace: 'nowrap' }}>
                  📋 JOB DETAILS
                </TableCell>
                {workflowStages.map(stage => {
                  if (!visibleColumns[stage.id]) return null;
                  const deptName = getDepartmentNameForStage(stage.id);
                  return (
                    <TableCell key={stage.id} colSpan={stage.columns.length} align="center"
                      sx={{ bgcolor: stage.bgColor, fontWeight: 700, borderRight: '1px solid #cbd5e1', borderBottom: '2px solid #cbd5e1', padding: '8px 4px' }}>
                      <Typography variant="caption" sx={{ fontWeight: 900, color: '#0f766e', display: 'block', fontSize: '0.65rem' }}>{stage.stepNumber}</Typography>
                      <Typography variant="caption" sx={{ fontWeight: 800, display: 'block', fontSize: '0.7rem', mb: 0.5 }}>{stage.name}</Typography>
                      <Typography variant="caption" sx={{ fontWeight: 600, color: '#059669', display: 'block', fontSize: '0.65rem', mb: 0.5 }}>TAT: {stage.tatHours}hrs</Typography>
                      <Typography variant="caption" sx={{ fontWeight: 600, color: '#059669', display: 'block', fontSize: '0.65rem', mb: 0.5 }}>Department: {deptName || stage.tat}</Typography>
                    </TableCell>
                  );
                })}
              </TableRow>

              {/* Row 2: column headers */}
              <TableRow>
                <TableCell padding="checkbox" sx={{ bgcolor: '#f1f5f9', minWidth: columnWidths.checkbox, maxWidth: columnWidths.checkbox, borderRight: '1px solid #e0e0e0', position: 'relative' }}>
                  <Checkbox size="small" color="primary" onChange={handleSelectAll}
                    checked={selectedEntries.length === filteredEntries.length && filteredEntries.length > 0} />
                  <ColumnResizer columnKey="checkbox" />
                </TableCell>
                {visibleColumns.jobCardNo  && <TableCell sx={{ bgcolor: '#f1f5f9', minWidth: columnWidths.jobCardNo,  maxWidth: columnWidths.jobCardNo,  fontWeight: 700, color: '#0f766e', fontSize: '0.7rem', borderRight: '1px solid #e0e0e0', position: 'relative' }}>Job Card No  <ColumnResizer columnKey="jobCardNo"  /></TableCell>}
                {visibleColumns.jobName    && <TableCell sx={{ bgcolor: '#f1f5f9', minWidth: columnWidths.jobName,    maxWidth: columnWidths.jobName,    fontWeight: 700, color: '#0f766e', fontSize: '0.7rem', borderRight: '1px solid #e0e0e0', position: 'relative' }}>Job Name     <ColumnResizer columnKey="jobName"    /></TableCell>}
                {visibleColumns.quantity   && <TableCell sx={{ bgcolor: '#f1f5f9', minWidth: columnWidths.quantity,   maxWidth: columnWidths.quantity,   fontWeight: 700, color: '#0f766e', fontSize: '0.7rem', borderRight: '1px solid #e0e0e0', position: 'relative' }}>Quantity     <ColumnResizer columnKey="quantity"   /></TableCell>}
                {visibleColumns.typeOfBook && <TableCell sx={{ bgcolor: '#f1f5f9', minWidth: columnWidths.typeOfBook, maxWidth: columnWidths.typeOfBook, fontWeight: 700, color: '#0f766e', fontSize: '0.7rem', borderRight: '1px solid #e0e0e0', position: 'relative' }}>Type of Book <ColumnResizer columnKey="typeOfBook" /></TableCell>}
                {visibleColumns.action     && <TableCell sx={{ bgcolor: '#f1f5f9', minWidth: columnWidths.action,     maxWidth: columnWidths.action,     fontWeight: 700, color: '#0f766e', fontSize: '0.7rem', borderRight: '1px solid #e0e0e0', position: 'relative' }}>Action       <ColumnResizer columnKey="action"     /></TableCell>}

                {workflowStages.map(stage => {
                  if (!visibleColumns[stage.id]) return null;
                  return (
                    <React.Fragment key={stage.id}>
                      {stage.columns.map(colName => {
                        const ck = `${colName}-${stage.id}`;
                        return (
                          <TableCell key={ck} sx={{ bgcolor: stage.bgColor, minWidth: columnWidths[ck] || 130, maxWidth: columnWidths[ck] || 130, fontWeight: 600, fontSize: '0.7rem', position: 'relative' }}>
                            {formatColumnHeader(colName)}<ColumnResizer columnKey={ck} />
                          </TableCell>
                        );
                      })}
                    </React.Fragment>
                  );
                })}
              </TableRow>
            </TableHead>

            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={50} align="center" sx={{ py: 5 }} /></TableRow>
              ) : filteredEntries.length === 0 ? (
                <TableRow><TableCell colSpan={50} align="center" sx={{ py: 5 }}>No data found</TableCell></TableRow>
              ) : (
                filteredEntries.map((entry, idx) => {
                  const rowBg = idx % 2 === 0 ? 'white' : '#f8fafc';
                  return (
                    <TableRow key={entry.id} hover>
                      <TableCell padding="checkbox" sx={{ bgcolor: rowBg, minWidth: columnWidths.checkbox, maxWidth: columnWidths.checkbox }}>
                        <Checkbox size="small" color="primary" checked={selectedEntries.includes(entry.id)} onChange={() => handleSelectEntry(entry.id)} />
                      </TableCell>
                      {visibleColumns.jobCardNo  && <TableCell sx={{ bgcolor: rowBg, minWidth: columnWidths.jobCardNo,  maxWidth: columnWidths.jobCardNo,  fontWeight: 700, fontSize: '0.75rem' }}>{entry.jobCardNo}</TableCell>}
                      {visibleColumns.jobName    && <TableCell sx={{ bgcolor: rowBg, minWidth: columnWidths.jobName,    maxWidth: columnWidths.jobName,    fontWeight: 600, fontSize: '0.75rem' }}>{entry.jobName}</TableCell>}
                      {visibleColumns.quantity   && <TableCell sx={{ bgcolor: rowBg, minWidth: columnWidths.quantity,   maxWidth: columnWidths.quantity,   fontSize: '0.75rem', textAlign: 'center' }}>{entry.quantity || '-'}</TableCell>}
                      {visibleColumns.typeOfBook && <TableCell sx={{ bgcolor: rowBg, minWidth: columnWidths.typeOfBook, maxWidth: columnWidths.typeOfBook, fontSize: '0.75rem' }}>{entry.typeOfBook || '-'}</TableCell>}
                      {visibleColumns.action     && (
                        <TableCell sx={{ bgcolor: rowBg, minWidth: columnWidths.action, maxWidth: columnWidths.action }}>
                          <Stack direction="row" spacing={0.5}>
                            <Tooltip title="View Details"><IconButton size="small" color="primary"><Info size={14} /></IconButton></Tooltip>
                          </Stack>
                        </TableCell>
                      )}

                      {workflowStages.map(stage => {
                        if (!visibleColumns[stage.id]) return null;
                        return (
                          <React.Fragment key={stage.id}>
                            {stage.columns.map(colName => {
                              const ck        = `${colName}-${stage.id}`;
                              const stageData = entry.stages[stage.id];

                              // Kitting-1: use progressive stage display (IndentNo → REQNo → PONo → RECNo → IssueNo/status)
                              // Kitting-2: show '✓' or '-'
                              const val = stage.id === 'jobKitting1'
                                ? getContentStageDisplay(stageData?.[colName])
                                : (stageData?.[colName] || '-');

                              const isTick      = val === '✓';
                              const isDateField  = colName.toLowerCase().includes('date');
                              const isStatusField= colName.toLowerCase().includes('status');
                              const isDelayField = colName.toLowerCase().includes('delay');

                              return (
                                <TableCell key={ck} sx={{
                                  bgcolor     : stage.bgColor,
                                  minWidth    : columnWidths[ck] || 130,
                                  maxWidth    : columnWidths[ck] || 130,
                                  fontSize    : '0.75rem',
                                  fontWeight  : isTick ? 700 : (isStatusField ? 600 : 400),
                                  textAlign   : (isTick || isDelayField || isStatusField) ? 'center' : 'left',
                                  color       : isTick ? '#10b981' : 'inherit',
                                  whiteSpace  : 'nowrap',
                                  overflow    : 'hidden',
                                  textOverflow: 'ellipsis',
                                }}>
                                  {isTick ? (
                                    <Typography sx={{ color: '#10b981', fontWeight: 700, fontSize: '1.1rem' }}>✓</Typography>
                                  ) : isDateField ? (
                                    val === '-' ? '-' : formatDate(val)
                                  ) : isStatusField ? (
                                    <StatusCell status={val} />
                                  ) : isDelayField ? (
                                    <DaysDelayCell delayText={val} />
                                  ) : (
                                    <Tooltip title={val !== '-' ? val : ''} arrow><span>{val}</span></Tooltip>
                                  )}
                                </TableCell>
                              );
                            })}
                          </React.Fragment>
                        );
                      })}
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Snackbar open={snackbar.open} autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
        <Alert severity={snackbar.severity} variant="filled">{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default JobKitting;