import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { Filter, Search, FileDown, RefreshCw, Settings, Eye, EyeOff, RotateCcw } from "lucide-react";
import { postRequest } from '../api/api';
import {
  IconButton, Tooltip, Snackbar, Alert, Button, Menu, MenuItem,
  Box, Typography, Paper, TextField, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Checkbox, Stack, CircularProgress,
  InputAdornment, ListItemIcon, ListItemText, Autocomplete, Chip
} from '@mui/material';
import * as XLSX from 'xlsx';

const fmt=(v)=>(v===null||v===undefined||v===""?"-":v);
const formatDate=(d)=>{
  if(!d||d==="-") return "-";
  try{
    if(d.includes("-")&&d.split("-")[2]?.length===4) return d;
    const dt=new Date(d);if(isNaN(dt.getTime())) return "-";
    return `${String(dt.getDate()).padStart(2,"0")}-${String(dt.getMonth()+1).padStart(2,"0")}-${dt.getFullYear()}`;
  }catch{return "-";}
};
const StatusCell=({status})=>{
  if(!status||status==="-") return <Typography sx={{color:"#6b7280",fontSize:"0.75rem"}}>-</Typography>;
  const s=status.toLowerCase();
  const color=s==="done"||s==="completed"?"#10b981":s==="pending"?"#eab308":["in progress","in process","wip"].includes(s)?"#3b82f6":s==="cancelled"||s==="rejected"?"#ef4444":"#6b7280";
  return <Typography sx={{color,fontWeight:600,fontSize:"0.75rem",whiteSpace:"nowrap"}}>{status}</Typography>;
};
const DaysDelayCell=({value})=>{
  const str=String(value??"-");const num=parseFloat(str);
  let color="#6b7280",display=str;
  if(!str||str==="-"||str==="null"||(!isNaN(num)&&num<0)){display="-";color="#6b7280";}
  else if(str.toLowerCase().includes("on time")) color="#10b981";
  else if(str.includes("min")||str.includes("hr")) color="#f59e0b";
  else if(str.includes("day")||str.includes("+")||(!isNaN(num)&&num>0)) color="#ef4444";
  return <Typography sx={{color,fontWeight:700,fontSize:"0.75rem",textAlign:"center",whiteSpace:"nowrap"}}>{display}</Typography>;
};

const STEPS=[
  {id:"step1",label:"Step 1",name:"PURCHASE REQUISITION",api:"GetRawMaterialRequisition",bgColor:"#f3e5f5"},
  {id:"step2",label:"Step 2",name:"PURCHASE ORDER",api:"GetRawMaterialPurchaseOrder",bgColor:"#e3f2fd"},
  {id:"step3",label:"Step 3",name:"GRN",api:"GetRawMaterialGRN",bgColor:"#e8f5e9"},
  {id:"step4",label:"Step 4",name:"ITEM ISSUE",api:"GetRawMaterialItemIssue",bgColor:"#fff8e1"},
];
const STEP_COLS=[
  {key:"planDate",label:"Plan Date"},
  {key:"actualDate",label:"Actual Date"},
  {key:"daysDelay",label:"Days Delay"},
  {key:"currentStatus",label:"Current Status"},
  {key:"delayReason",label:"Delay Reason"},
  {key:"doerName",label:"Doer Name"},
];
const BASE_COLS=[
  {key:"materialName",label:"Material Name"},
  {key:"category",label:"Category"},
  {key:"quantity",label:"Quantity"},
  {key:"warehouse",label:"Warehouse"},
  {key:"entryDate",label:"Entry Date"},
];

const ColumnResizer=({columnKey,resizeRef,forceUpdate})=>{
  const active=resizeRef.current.isResizing&&resizeRef.current.columnKey===columnKey;
  return <Box onMouseDown={e=>{e.preventDefault();e.stopPropagation();resizeRef.current={isResizing:true,columnKey,startX:e.clientX,startWidth:resizeRef.current.widths[columnKey]??120};document.body.style.cursor="col-resize";document.body.style.userSelect="none";forceUpdate({});}} sx={{position:"absolute",right:-2,top:0,width:"4px",height:"100%",cursor:"col-resize",userSelect:"none",zIndex:100,bgcolor:active?"#3b82f6":"transparent","&:hover":{bgcolor:"#3b82f6"}}}/>;
};

const RawMaterialFMS=()=>{
  const [rows,setRows]=useState([]);const [stepData,setStepData]=useState({step1:[],step2:[],step3:[],step4:[]});const [loading,setLoading]=useState(false);
  const [showFilters,setShowFilters]=useState(false);const [searchQuery,setSearchQuery]=useState("");const [filters,setFilters]=useState({materialName:"",currentStatus:"",fromDate:"",toDate:""});
  const [uniqueNames,setUniqueNames]=useState([]);const [uniqueStatuses,setUniqueStatuses]=useState([]);
  const [selected,setSelected]=useState([]);const [exportAnchor,setExportAnchor]=useState(null);const [colMenuAnchor,setColMenuAnchor]=useState(null);
  const [snackbar,setSnackbar]=useState({open:false,message:"",severity:"success"});
  const [visibleColumns,setVisibleColumns]=useState(Object.fromEntries([...BASE_COLS.map(c=>[c.key,true]),...STEPS.map(s=>[s.id,true])]));
  const initWidths=()=>{const w={checkbox:50};BASE_COLS.forEach(c=>{w[c.key]=130;});STEPS.forEach(s=>STEP_COLS.forEach(c=>{w[`${c.key}-${s.id}`]=120;}));return w;};
  const [colWidths,setColWidths]=useState(initWidths);
  const resizeRef=useRef({isResizing:false,columnKey:null,startX:0,startWidth:0,widths:colWidths});resizeRef.current.widths=colWidths;
  const [,forceUpdate]=useState({});
  const handleMouseMove=useCallback(e=>{if(!resizeRef.current.isResizing)return;const{columnKey,startX,startWidth}=resizeRef.current;setColWidths(p=>({...p,[columnKey]:Math.max(50,startWidth+(e.clientX-startX))}));},[]);
  const handleMouseUp=useCallback(()=>{if(resizeRef.current.isResizing){resizeRef.current.isResizing=false;document.body.style.cursor="";document.body.style.userSelect="";forceUpdate({});}},[]);
  useEffect(()=>{document.addEventListener("mousemove",handleMouseMove);document.addEventListener("mouseup",handleMouseUp);return()=>{document.removeEventListener("mousemove",handleMouseMove);document.removeEventListener("mouseup",handleMouseUp);};},[handleMouseMove,handleMouseUp]);

  const showSnackbar=(msg,sev="success")=>setSnackbar({open:true,message:msg,severity:sev});
  const fetchAll=async()=>{
    setLoading(true);
    try{
      const payload={};if(filters.materialName) payload.materialName=filters.materialName;if(filters.fromDate) payload.fromDate=filters.fromDate;if(filters.toDate) payload.toDate=filters.toDate;if(searchQuery) payload.search=searchQuery;
      const mainRes=await postRequest("GetRawMaterialDetail",payload);const data=Array.isArray(mainRes)?mainRes:[];
      setRows(data);setUniqueNames([...new Set(data.map(r=>r.materialName).filter(Boolean))].sort());
      const stepResults=await Promise.all(STEPS.map(s=>postRequest(s.api,{}).catch(()=>[])));const updates={};const allSt=new Set();
      STEPS.forEach((s,i)=>{const arr=Array.isArray(stepResults[i])?stepResults[i]:[];updates[s.id]=arr;arr.forEach(r=>{const st=r.currentStatus||r.status||r.Status;if(st) allSt.add(st);});});
      setStepData(updates);setUniqueStatuses([...allSt].sort());showSnackbar("Data loaded successfully","success");
    }catch(e){console.error(e);showSnackbar("Failed to load data","error");}finally{setLoading(false);}
  };
  useEffect(()=>{fetchAll();},[]);

  const handleFilterChange=(name,val)=>setFilters(p=>({...p,[name]:val}));
  const clearFilters=()=>{setFilters({materialName:"",currentStatus:"",fromDate:"",toDate:""});setSearchQuery("");};
  const filteredRows=useMemo(()=>rows.filter(row=>{
    const q=searchQuery.toLowerCase();
    return(!searchQuery||String(row.materialName??"").toLowerCase().includes(q)||String(row.category??"").toLowerCase().includes(q))
      &&(!filters.materialName||String(row.materialName??"").trim().toUpperCase()===filters.materialName.trim().toUpperCase())
      &&(!filters.fromDate||new Date(row.entryDate)>=new Date(filters.fromDate))
      &&(!filters.toDate||new Date(row.entryDate)<=new Date(filters.toDate));
  }),[rows,filters,searchQuery]);

  const rowCount=Math.max(filteredRows.length,...STEPS.map(s=>stepData[s.id]?.length??0),0);
  const baseColSpan=1+BASE_COLS.filter(c=>visibleColumns[c.key]).length;
  const handleSelectAll=e=>setSelected(e.target.checked?filteredRows.map((_,i)=>i):[]);
  const handleSelectRow=i=>setSelected(p=>p.includes(i)?p.filter(x=>x!==i):[...p,i]);

  const handleExport=type=>{
    const data=selected.length>0?filteredRows.filter((_,i)=>selected.includes(i)):filteredRows;
    if(!data.length){showSnackbar("No data to export","warning");return;}
    const flat=data.map(r=>Object.fromEntries(BASE_COLS.map(c=>[c.label,fmt(r[c.key])])));const ws=XLSX.utils.json_to_sheet(flat);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,"RawMaterialFMS");
    if(type==="excel"){XLSX.writeFile(wb,`RawMaterialFMS_${new Date().toISOString().split("T")[0]}.xlsx`);showSnackbar("Exported to Excel","success");}
    else{const csv=XLSX.utils.sheet_to_csv(ws);const blob=new Blob([csv],{type:"text/csv"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`RawMaterialFMS_${new Date().toISOString().split("T")[0]}.csv`;a.click();showSnackbar("Exported to CSV","success");}
    setExportAnchor(null);
  };

  return(
    <Box sx={{p:2,bgcolor:"#f8fafc",minHeight:"100vh",position:"relative"}}>
      {loading&&<Box sx={{position:"fixed",inset:0,bgcolor:"rgba(255,255,255,0.15)",backdropFilter:"blur(1px)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999}}><Box sx={{display:"flex",flexDirection:"column",alignItems:"center",gap:1.5}}><CircularProgress size={40} thickness={4} sx={{color:"#0f766e"}}/><Typography variant="body2" sx={{fontWeight:600,color:"#0f766e"}}>Loading...</Typography></Box></Box>}
      <Typography variant="caption" sx={{display:"block",textAlign:"center",letterSpacing:4,fontWeight:700,color:"text.secondary",mb:3}}>RAW MATERIAL - FMS</Typography>
      <Paper elevation={2} sx={{borderRadius:2,overflow:"hidden"}}>
        <Box sx={{p:1.5,bgcolor:"#f1f5f9",borderBottom:"1px solid #e2e8f0"}}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Tooltip title="Toggle Filters"><IconButton size="small" onClick={()=>setShowFilters(!showFilters)} sx={{border:"1px solid #cbd5e1",borderRadius:1,bgcolor:showFilters?"#0f766e":"white",color:showFilters?"white":"inherit"}}><Filter size={18}/></IconButton></Tooltip>
            <Tooltip title="Column Settings"><IconButton size="small" onClick={e=>setColMenuAnchor(e.currentTarget)} sx={{border:"1px solid #cbd5e1",borderRadius:1,bgcolor:"white"}}><Settings size={18}/></IconButton></Tooltip>
            <Tooltip title="Refresh"><IconButton size="small" onClick={fetchAll} disabled={loading} sx={{border:"1px solid #cbd5e1",borderRadius:1,bgcolor:"white"}}><RefreshCw size={18} style={{animation:loading?"spin 1s linear infinite":"none",transformOrigin:"center"}}/></IconButton></Tooltip>
            <TextField size="small" placeholder="Search..." value={searchQuery} onChange={e=>setSearchQuery(e.target.value)} sx={{bgcolor:"white",width:220}} InputProps={{startAdornment:<InputAdornment position="start"><Search size={16}/></InputAdornment>}}/>
            <Box sx={{flexGrow:1}}/>
            <Button size="small" variant="contained" startIcon={<FileDown size={16}/>} onClick={e=>setExportAnchor(e.currentTarget)} sx={{bgcolor:"#3b82f6",borderRadius:1}}>EXPORT</Button>
            <Chip label={`${filteredRows.length} / ${rows.length} Records`} size="small" sx={{bgcolor:"gray",color:"white",fontWeight:700,fontSize:"0.75rem",height:28}}/>
          </Stack>
        </Box>
        <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
        <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)} onClose={()=>setExportAnchor(null)}>
          <MenuItem onClick={()=>handleExport("excel")}><ListItemIcon><FileDown size={16}/></ListItemIcon><ListItemText>Export to Excel</ListItemText></MenuItem>
          <MenuItem onClick={()=>handleExport("csv")}><ListItemIcon><FileDown size={16}/></ListItemIcon><ListItemText>Export to CSV</ListItemText></MenuItem>
        </Menu>
        <Menu anchorEl={colMenuAnchor} open={Boolean(colMenuAnchor)} onClose={()=>setColMenuAnchor(null)}>
          <Typography variant="overline" sx={{px:2,fontWeight:900}}>Columns</Typography>
          {Object.keys(visibleColumns).map(key=>(
            <MenuItem key={key} onClick={()=>setVisibleColumns(p=>({...p,[key]:!p[key]}))} sx={{py:0.5}}>
              <ListItemIcon>{visibleColumns[key]?<Eye size={16}/>:<EyeOff size={16}/>}</ListItemIcon>
              <ListItemText primary={key.replace(/([A-Z])/g," $1").toUpperCase()} primaryTypographyProps={{fontSize:"0.75rem"}}/>
              <Checkbox size="small" checked={visibleColumns[key]} color="primary"/>
            </MenuItem>
          ))}
        </Menu>
        {showFilters&&(
          <Box sx={{p:1.5,bgcolor:"#f8fafc",borderBottom:"1px solid #e2e8f0"}}>
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
              <Autocomplete freeSolo options={uniqueNames} value={filters.materialName} onChange={(_,v)=>handleFilterChange("materialName",v||"")} onInputChange={(_,v)=>handleFilterChange("materialName",v||"")} renderInput={p=><TextField {...p} label="Material Name" size="small"/>} sx={{width:160}}/>
              <Autocomplete freeSolo options={uniqueStatuses} value={filters.currentStatus} onChange={(_,v)=>handleFilterChange("currentStatus",v||"")} onInputChange={(_,v)=>handleFilterChange("currentStatus",v||"")} renderInput={p=><TextField {...p} label="Current Status" size="small"/>} sx={{width:160}}/>
              <TextField label="From Date" type="date" size="small" InputLabelProps={{shrink:true}} value={filters.fromDate} onChange={e=>handleFilterChange("fromDate",e.target.value)} sx={{width:150}}/>
              <TextField label="To Date" type="date" size="small" InputLabelProps={{shrink:true}} value={filters.toDate} onChange={e=>handleFilterChange("toDate",e.target.value)} sx={{width:150}}/>
              <Button size="small" color="error" onClick={clearFilters} sx={{fontWeight:700}}><RotateCcw size={22} strokeWidth={3}/></Button>
            </Stack>
          </Box>
        )}
        <TableContainer sx={{maxHeight:"75vh",overflow:"auto","&::-webkit-scrollbar":{display:"none"},scrollbarWidth:"none",msOverflowStyle:"none"}}>
          <Table size="small" sx={{borderCollapse:"separate"}}>
            <TableHead>
              <TableRow>
                <TableCell colSpan={baseColSpan} align="center" sx={{bgcolor:"#cbd5e1",fontWeight:700,borderBottom:"2px solid #94a3b8",fontSize:"0.7rem",padding:"8px",whiteSpace:"nowrap"}}>🏷️ RAW MATERIAL DETAIL</TableCell>
                {STEPS.map(step=>!visibleColumns[step.id]?null:(
                  <TableCell key={step.id} colSpan={STEP_COLS.length} align="center" sx={{bgcolor:step.bgColor,fontWeight:700,borderRight:"1px solid #cbd5e1",borderBottom:"2px solid #cbd5e1",padding:"8px 4px"}}>
                    <Typography variant="caption" sx={{fontWeight:900,color:"#0f766e",display:"block",fontSize:"0.65rem"}}>{step.label}</Typography>
                    <Typography variant="caption" sx={{fontWeight:800,display:"block",fontSize:"0.7rem",mb:0.5}}>{step.name}</Typography>
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell padding="checkbox" sx={{bgcolor:"#f1f5f9",minWidth:colWidths.checkbox,maxWidth:colWidths.checkbox,borderRight:"1px solid #e0e0e0",position:"relative"}}>
                  <Checkbox size="small" color="primary" onChange={handleSelectAll} checked={selected.length===filteredRows.length&&filteredRows.length>0}/>
                  <ColumnResizer columnKey="checkbox" resizeRef={resizeRef} forceUpdate={forceUpdate}/>
                </TableCell>
                {BASE_COLS.map(({key,label})=>!visibleColumns[key]?null:(
                  <TableCell key={key} sx={{bgcolor:"#f1f5f9",minWidth:colWidths[key],maxWidth:colWidths[key],fontWeight:700,color:"#0f766e",fontSize:"0.7rem",borderRight:"1px solid #e0e0e0",position:"relative"}}>
                    {label}<ColumnResizer columnKey={key} resizeRef={resizeRef} forceUpdate={forceUpdate}/>
                  </TableCell>
                ))}
                {STEPS.map(step=>!visibleColumns[step.id]?null:(
                  <React.Fragment key={step.id}>
                    {STEP_COLS.map(col=>{const ck=`${col.key}-${step.id}`;return(
                      <TableCell key={ck} sx={{bgcolor:step.bgColor,minWidth:colWidths[ck],maxWidth:colWidths[ck],fontWeight:600,fontSize:"0.7rem",textAlign:col.key==="daysDelay"||col.key==="currentStatus"?"center":"left",position:"relative"}}>
                        {col.label}<ColumnResizer columnKey={ck} resizeRef={resizeRef} forceUpdate={forceUpdate}/>
                      </TableCell>
                    );})}
                  </React.Fragment>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {rowCount===0?(<TableRow><TableCell colSpan={100} align="center" sx={{py:5}}>{loading?"":"No data found"}</TableCell></TableRow>)
              :Array.from({length:rowCount}).map((_,i)=>{
                const row=filteredRows[i]??{};const isSel=selected.includes(i);const rowBg=isSel?"#e0f2fe":i%2===0?"white":"#f8fafc";
                return(
                  <TableRow key={i} hover>
                    <TableCell padding="checkbox" sx={{bgcolor:rowBg,minWidth:colWidths.checkbox,maxWidth:colWidths.checkbox}}><Checkbox size="small" color="primary" checked={isSel} onChange={()=>handleSelectRow(i)}/></TableCell>
                    {BASE_COLS.map(({key})=>!visibleColumns[key]?null:(
                      <TableCell key={key} sx={{bgcolor:rowBg,minWidth:colWidths[key],maxWidth:colWidths[key],fontWeight:key==="materialName"?700:600,fontSize:"0.75rem"}}>
                        {key==="entryDate"?formatDate(fmt(row[key])):fmt(row[key])}
                      </TableCell>
                    ))}
                    {STEPS.map(step=>!visibleColumns[step.id]?null:(
                      <React.Fragment key={step.id}>
                        {STEP_COLS.map(col=>{const ck=`${col.key}-${step.id}`;const r=(stepData[step.id]??[])[i]??{};const val=fmt(r[col.key]);
                          if(col.key==="planDate"||col.key==="actualDate") return <TableCell key={ck} sx={{bgcolor:step.bgColor,fontSize:"0.75rem",minWidth:colWidths[ck]}}>{formatDate(val)}</TableCell>;
                          if(col.key==="daysDelay") return <TableCell key={ck} align="center" sx={{bgcolor:step.bgColor,minWidth:colWidths[ck],padding:"6px 8px"}}><DaysDelayCell value={r[col.key]}/></TableCell>;
                          if(col.key==="currentStatus") return <TableCell key={ck} align="center" sx={{bgcolor:step.bgColor,minWidth:colWidths[ck],padding:"6px 8px"}}><StatusCell status={val}/></TableCell>;
                          if(col.key==="delayReason") return <TableCell key={ck} sx={{bgcolor:step.bgColor,color:val==="-"?"#6b7280":"#ea580c",fontWeight:600,fontSize:"0.7rem",minWidth:colWidths[ck],overflow:"hidden",textOverflow:"ellipsis"}}>{val}</TableCell>;
                          if(col.key==="doerName") return <TableCell key={ck} sx={{bgcolor:step.bgColor,fontSize:"0.75rem",minWidth:colWidths[ck],fontWeight:600,color:val==="-"?"#6b7280":"#0f766e"}}>{val}</TableCell>;
                          return <TableCell key={ck} sx={{bgcolor:step.bgColor,fontSize:"0.75rem",minWidth:colWidths[ck]}}>{val}</TableCell>;
                        })}
                      </React.Fragment>
                    ))}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
      <Snackbar open={snackbar.open} autoHideDuration={3000} onClose={()=>setSnackbar(p=>({...p,open:false}))} anchorOrigin={{vertical:"bottom",horizontal:"right"}}>
        <Alert severity={snackbar.severity} variant="filled">{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};
export default RawMaterialFMS;