import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import {
  Filter, Search, FileDown, RefreshCw, Settings, Eye, EyeOff, RotateCcw, Info
} from "lucide-react";
import { postRequest } from '../api/api';
import {
  IconButton, Tooltip, Snackbar, Alert, Button, Menu, MenuItem,
  Box, Typography, Paper, TextField, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Checkbox, Stack, CircularProgress,
  InputAdornment, ListItemIcon, ListItemText, Autocomplete, Chip,
} from '@mui/material';
import * as XLSX from 'xlsx';

// ─── helpers ──────────────────────────────────────────────────────────────────
const fmt = (v) => (v === null || v === undefined || v === "" ? "-" : v);

const formatDate = (dateString) => {
  if (!dateString || dateString === "-" || dateString === "null") return "-";
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "-";
    return [
      String(date.getDate()).padStart(2, "0"),
      String(date.getMonth() + 1).padStart(2, "0"),
      date.getFullYear(),
    ].join("-");
  } catch { return "-"; }
};

const getStatusStyle = (status) => {
  if (!status || status === "-") return { text: "-", color: "#6b7280" };
  const s = status.toLowerCase().trim();
  let color = "#6b7280";
  if (s === "done" || s === "completed" || s === "approved" || s === "yes") color = "#10b981";
  else if (s === "pending") color = "#f59e0b";
  else if (["in progress", "in process", "wip", "running"].includes(s)) color = "#f59e0b";
  else if (s === "cancelled" || s === "cancel" || s === "rejected" || s === "no" || s === "delay") color = "#ef4444";
  return { text: status, color };
};

const StatusCell = ({ status }) => {
  const { text, color } = getStatusStyle(status);
  return (
    <Typography sx={{ color, fontWeight: 700, fontSize: "0.73rem", whiteSpace: "nowrap" }}>
      {text}
    </Typography>
  );
};

const DaysDelayCell = ({ value }) => {
  const textStr = String(value || "-");
  let color = "#6b7280";
  if (!textStr || textStr === "-" || textStr === "null") color = "#6b7280";
  else if (textStr.toLowerCase().includes("on time")) color = "#10b981";
  else if (textStr.includes("min") || textStr.includes("hr")) color = "#f59e0b";
  else if (textStr.includes("day") || textStr.includes("+")) color = "#ef4444";
  return (
    <Typography sx={{ color, fontWeight: 700, fontSize: "0.73rem", textAlign: "center", whiteSpace: "nowrap" }}>
      {textStr}
    </Typography>
  );
};

// ─── step config ──────────────────────────────────────────────────────────────
const STEPS = [
  {
    id: "step1", label: "Step 1", name: "JOB DETAILS",
    api: "GetRMDetail", bgColor: "#fce4ec", icon: "📋",
    cols: [
      { key: "createdTime", label: "Created Time", apiKey: "CreatedTime" },
      { key: "jobNo", label: "Job No", apiKey: "JobNo" },
      { key: "jobName", label: "Job Name", apiKey: "JobName" },
      { key: "quantity", label: "Quantity", apiKey: "Quantity" },
      { key: "unit", label: "Unit", apiKey: "Unit" },
    ],
  },
  {
    id: "step2", label: "Step 2", name: "PO STATUS",
    api: "GetRMPODetail", bgColor: "#e3f2fd", icon: "📦",
    cols: [
      { key: "planDate", label: "Plan Date", apiKey: "PlanDate" },
      { key: "actualDate", label: "Actual Date", apiKey: "ActualDate" },
      { key: "delay", label: "Delay", apiKey: "Delay" },
      { key: "vendorName", label: "Vendor Name", apiKey: "VendorName" },
      { key: "rate", label: "Rate", apiKey: "Rate" },
    ],
  },
  {
    id: "step3", label: "Step 3", name: "GRN STATUS",
    api: "GetRMGRNDetail", bgColor: "#e8f5e9", icon: "✅",
    cols: [
      { key: "planDate", label: "Plan Date", apiKey: "PlanDate" },
      { key: "actualDate", label: "Actual Date", apiKey: "ActualDate" },
      { key: "delay", label: "Delay", apiKey: "Delay" },
      { key: "status", label: "Status", apiKey: "Status" },
      { key: "location", label: "Location", apiKey: "Location" },
    ],
  },
];


const ColumnResizer = ({ columnKey, resizeRef, forceUpdate }) => {
  const isActive = resizeRef.current.isResizing && resizeRef.current.columnKey === columnKey;
  return (
    <Box
      onMouseDown={(e) => {
        e.preventDefault(); e.stopPropagation();
        resizeRef.current = {
          ...resizeRef.current,
          isResizing: true,
          columnKey,
          startX: e.clientX,
          startWidth: resizeRef.current.widths[columnKey] ?? 120,
        };
        document.body.style.cursor = "col-resize";
        document.body.style.userSelect = "none";
        forceUpdate({});
      }}
      sx={{
        position: "absolute", right: -2, top: 0,
        width: "4px", height: "100%",
        cursor: "col-resize", userSelect: "none", zIndex: 100,
        bgcolor: isActive ? "#3b82f6" : "transparent",
        "&:hover": { bgcolor: "#3b82f6" },
      }}
    />
  );
};

const RawMaterialPurchaseFMS = () => {
  const [rows, setRows] = useState([]);
  const [stepData, setStepData] = useState(Object.fromEntries(STEPS.map((s) => [s.id, []])));
  const [loading, setLoading] = useState(false);

  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const [filters, setFilters] = useState({
    jobNo: "",
    jobName: "",
    vendorName: "",
    status: "",
    fromDate: "",
    toDate: "",
  });

  const [uniqueJobNos, setUniqueJobNos] = useState([]);
  const [uniqueJobNames, setUniqueJobNames] = useState([]);
  const [uniqueVendorNames, setUniqueVendorNames] = useState([]);
  const [uniqueStatuses, setUniqueStatuses] = useState([]);

  const [selected, setSelected] = useState([]);
  const [exportAnchor, setExportAnchor] = useState(null);
  const [colMenuAnchor, setColMenuAnchor] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "success" });

  const row1Ref = useRef(null);
  const [row1Height, setRow1Height] = useState(72);

  const [visibleColumns, setVisibleColumns] = useState({
    step1: true, step2: true, step3: true,
  });

  const initWidths = () => {
    const w = {
      checkbox: 50,
    };
    STEPS.forEach((s) => s.cols.forEach((c) => {
      w[`${c.key}-${s.id}`] = 130;
    }));
    return w;
  };

  const [colWidths, setColWidths] = useState(initWidths);
  const resizeRef = useRef({ isResizing: false, columnKey: null, startX: 0, startWidth: 0, widths: colWidths });
  resizeRef.current.widths = colWidths;
  const [, forceUpdate] = useState({});

  const handleMouseMove = useCallback((e) => {
    if (!resizeRef.current.isResizing) return;
    const { columnKey, startX, startWidth } = resizeRef.current;
    setColWidths((p) => ({ ...p, [columnKey]: Math.max(50, startWidth + (e.clientX - startX)) }));
  }, []);

  const handleMouseUp = useCallback(() => {
    if (resizeRef.current.isResizing) {
      resizeRef.current.isResizing = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      forceUpdate({});
    }
  }, []);

  useEffect(() => {
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  useEffect(() => {
    const el = row1Ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => {
      const h = entry.borderBoxSize?.[0]?.blockSize ?? entry.contentRect.height;
      if (h > 0) setRow1Height(Math.ceil(h));
    });
    ro.observe(el);
    setRow1Height(Math.ceil(el.getBoundingClientRect().height) || 72);
    return () => ro.disconnect();
  }, []);

  const toArr = (r) => {
    let d = Array.isArray(r) ? r : (r?.data ?? r);
    if (!Array.isArray(d)) d = d?.data ?? [];
    return Array.isArray(d) ? d : [];
  };

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [mainRes, ...stepResults] = await Promise.all([
        postRequest("GetRMDetail"),
        ...STEPS.map((s) => postRequest(s.api, {}).catch(() => [])),
      ]);

      const mainData = toArr(mainRes);
      setRows(mainData);
      setUniqueJobNos([...new Set(mainData.map((r) => r.JobNo || r.jobNo).filter(Boolean))].sort());
      setUniqueJobNames([...new Set(mainData.map((r) => r.JobName || r.jobName).filter(Boolean))].sort());

      const updates = {};
      const allStatuses = new Set();
      STEPS.forEach((s, idx) => {
        const rows = toArr(stepResults[idx]);
        updates[s.id] = rows;
        rows.forEach((r) => {
          const st = r.Status ?? r.status ?? r.currentStatus;
          if (st) allStatuses.add(st);
        });
      });
      setStepData(updates);
      setUniqueVendorNames([...new Set(updates.step2.map(r => r.VendorName).filter(Boolean))].sort());
      setUniqueStatuses([...allStatuses].sort());
      showSnackbar("Data loaded successfully", "success");
    } catch (e) {
      console.error("fetchAll:", e);
      showSnackbar("Failed to load data", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchAll(); }, []); // eslint-disable-line

  const showSnackbar = (msg, sev = "success") =>
    setSnackbar({ open: true, message: msg, severity: sev });

  const filteredRows = useMemo(() => {
    return rows.filter((row) => {
      const q = searchQuery.toLowerCase();
      const matchSearch = !searchQuery ||
        String(row.JobNo ?? row.jobNo ?? "").toLowerCase().includes(q) ||
        String(row.JobName ?? row.jobName ?? "").toLowerCase().includes(q);

      const matchJobNo = !filters.jobNo ||
        String(row.JobNo ?? row.jobNo ?? "").trim().toUpperCase() ===
        filters.jobNo.trim().toUpperCase();

      const matchJobName = !filters.jobName ||
        String(row.JobName ?? row.jobName ?? "").trim().toUpperCase() ===
        filters.jobName.trim().toUpperCase();

      // For Vendor and Status, we check step data at index [i]
      const step2Row = (stepData.step2 ?? [])[rows.indexOf(row)] ?? {};
      const matchVendor = !filters.vendorName ||
        String(step2Row.VendorName ?? "").trim().toUpperCase() ===
        filters.vendorName.trim().toUpperCase();

      const step3Row = (stepData.step3 ?? [])[rows.indexOf(row)] ?? {};
      const matchStatus = !filters.status ||
        String(step3Row.Status ?? step3Row.status ?? "").toLowerCase() === filters.status.toLowerCase();

      const rowDate = row.CreatedTime || row.createdTime;
      const matchDate =
        (!filters.fromDate || new Date(rowDate) >= new Date(filters.fromDate)) &&
        (!filters.toDate || new Date(rowDate) <= new Date(filters.toDate));

      return matchSearch && matchJobNo && matchJobName && matchVendor && matchStatus && matchDate;
    });
  }, [rows, filters, searchQuery]);

  const rowCount = Math.max(filteredRows.length, ...STEPS.map(s => stepData[s.id]?.length ?? 0), 0);

  const handleFilterChange = (name, val) => setFilters((p) => ({ ...p, [name]: val }));
  const clearFilters = () => {
    setFilters({ jobNo: "", jobName: "", vendorName: "", status: "", fromDate: "", toDate: "" });
    setSearchQuery("");
  };

  const handleSelectAll = (e) =>
    setSelected(e.target.checked ? filteredRows.map((_, i) => i) : []);
  const handleSelectRow = (i) =>
    setSelected((p) => p.includes(i) ? p.filter((x) => x !== i) : [...p, i]);

  const handleExport = (type) => {
    const exportRows = selected.length > 0
      ? filteredRows.filter((_, i) => selected.includes(i))
      : filteredRows;
    if (!exportRows.length) { showSnackbar("No data to export", "warning"); return; }

    const flat = exportRows.map((r, i) => {
      const data = {};
      STEPS.forEach((step) => {
        const sr = (stepData[step.id] ?? [])[i] ?? {};
        step.cols.forEach((col) => {
          let val = sr[col.apiKey];
          if (col.key.toLowerCase().includes("date") || col.key.toLowerCase().includes("time")) {
            val = formatDate(val);
          }
          data[`${step.name} - ${col.label}`] = fmt(val);
        });
      });
      return data;
    });

    const ws = XLSX.utils.json_to_sheet(flat);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "RawMaterialPurchaseFMS");
    const dateStr = new Date().toISOString().split("T")[0];
    if (type === "excel") {
      XLSX.writeFile(wb, `RawMaterialPurchaseFMS_${dateStr}.xlsx`);
      showSnackbar("Exported to Excel", "success");
    } else {
      const csv = XLSX.utils.sheet_to_csv(ws);
      const blob = new Blob([csv], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url;
      a.download = `RawMaterialPurchaseFMS_${dateStr}.csv`; a.click();
      showSnackbar("Exported to CSV", "success");
    }
    setExportAnchor(null);
  };

  const baseColSpan = 1;

  const renderStepCell = (step, col, stepRow) => {
    const ck = `${col.key}-${step.id}`;
    const raw = stepRow[col.apiKey];
    const cellSx = {
      bgcolor: step.bgColor,
      minWidth: colWidths[ck],
      maxWidth: colWidths[ck],
      fontSize: "0.75rem",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      padding: "4px 8px",
      borderRight: col.isLast ? "2px solid #94a3b8" : "1px solid #e2e8f0",
      textAlign: (col.key === "delay" || col.key === "status") ? "center" : "left",
    };

    if (col.key.toLowerCase().includes("date") || col.key.toLowerCase().includes("time")) {
      return <TableCell key={ck} sx={cellSx}>{formatDate(raw)}</TableCell>;
    }
    if (col.key === "delay") {
      return (
        <TableCell key={ck} align="center" sx={cellSx}>
          <DaysDelayCell value={raw} />
        </TableCell>
      );
    }
    if (col.key === "status") {
      return (
        <TableCell key={ck} align="center" sx={cellSx}>
          <StatusCell status={fmt(raw)} />
        </TableCell>
      );
    }
    return <TableCell key={ck} sx={cellSx}>{fmt(raw)}</TableCell>;
  };

  return (
    <Box sx={{ p: 2, bgcolor: "#f8fafc", minHeight: "100vh", position: "relative" }}>
      {loading && (
        <Box sx={{ position: "fixed", inset: 0, bgcolor: "rgba(255,255,255,0.15)", backdropFilter: "blur(1px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999 }}>
          <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 1.5 }}>
            <CircularProgress size={40} thickness={4} sx={{ color: "#0f766e" }} />
            <Typography variant="body2" sx={{ fontWeight: 600, color: "#0f766e" }}>Loading...</Typography>
          </Box>
        </Box>
      )}

      <Typography variant="caption" sx={{ display: "block", textAlign: "center", letterSpacing: 4, fontWeight: 700, color: "text.secondary", mb: 3 }}>
        RAW MATERIAL PURCHASE WORKFLOW - FMS
      </Typography>

      <Paper elevation={2} sx={{ borderRadius: 2, overflow: "hidden" }}>
        {/* Toolbar */}
        <Box sx={{ p: 1.5, bgcolor: "#f1f5f9", borderBottom: "1px solid #e2e8f0" }}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Tooltip title="Toggle Filters">
              <IconButton size="small" onClick={() => setShowFilters(!showFilters)} sx={{ border: "1px solid #cbd5e1", borderRadius: 1.5, bgcolor: showFilters ? "#0f766e" : "white", color: showFilters ? "white" : "inherit", transition: "all 0.2s", "&:hover": { bgcolor: showFilters ? "#0d9488" : "#f1f5f9" } }}>
                <Filter size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Column Settings">
              <IconButton size="small" onClick={(e) => setColMenuAnchor(e.currentTarget)} sx={{ border: "1px solid #cbd5e1", borderRadius: 1.5, bgcolor: "white", "&:hover": { bgcolor: "#f1f5f9" } }}>
                <Settings size={18} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Refresh">
              <IconButton size="small" onClick={fetchAll} disabled={loading} sx={{ border: "1px solid #cbd5e1", borderRadius: 1.5, bgcolor: "white", "&:hover": { bgcolor: "#f1f5f9" } }}>
                <RefreshCw size={18} style={{ animation: loading ? "spin 1s linear infinite" : "none", transformOrigin: "center" }} />
              </IconButton>
            </Tooltip>
            <TextField size="small" placeholder="Search orders, jobs..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} sx={{ bgcolor: "white", width: 300, "& .MuiOutlinedInput-root": { borderRadius: 2 } }} InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} color="#64748b" /></InputAdornment> }} />
            <Box sx={{ flexGrow: 1 }} />
            <Button size="small" variant="contained" startIcon={<FileDown size={16} />} onClick={(e) => setExportAnchor(e.currentTarget)} sx={{ bgcolor: "#0f766e", borderRadius: 2, px: 2, fontWeight: 700, "&:hover": { bgcolor: "#0d9488" } }}>EXPORT</Button>
            <Chip label={`${filteredRows.length} Records`} size="small" sx={{ bgcolor: "#f1f5f9", color: "#475569", fontWeight: 700, border: "1px solid #e2e8f0", borderRadius: 1.5 }} />
          </Stack>
        </Box>

        <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>

        {/* Export menu */}
        <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)} onClose={() => setExportAnchor(null)}>
          <MenuItem onClick={() => handleExport("excel")}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to Excel</ListItemText></MenuItem>
          <MenuItem onClick={() => handleExport("csv")}><ListItemIcon><FileDown size={16} /></ListItemIcon><ListItemText>Export to CSV</ListItemText></MenuItem>
        </Menu>

        {/* Column visibility menu */}
        <Menu anchorEl={colMenuAnchor} open={Boolean(colMenuAnchor)} onClose={() => setColMenuAnchor(null)}>
          <Typography variant="overline" sx={{ px: 2, fontWeight: 900, display: "block", mt: 1 }}>Steps</Typography>
          {STEPS.map((s) => (
            <MenuItem key={s.id} onClick={() => setVisibleColumns((p) => ({ ...p, [s.id]: !p[s.id] }))} sx={{ py: 0.5 }}>
              <ListItemIcon>{visibleColumns[s.id] ? <Eye size={16} /> : <EyeOff size={16} />}</ListItemIcon>
              <ListItemText primary={`${s.label} — ${s.name}`} primaryTypographyProps={{ fontSize: "0.75rem" }} />
              <Checkbox size="small" checked={!!visibleColumns[s.id]} color="primary" />
            </MenuItem>
          ))}
        </Menu>

        {/* Filters panel */}
        {showFilters && (
          <Box sx={{ p: 1.5, bgcolor: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
              <Autocomplete freeSolo options={uniqueJobNos}
                value={filters.jobNo}
                onChange={(_, v) => handleFilterChange("jobNo", v || "")}
                onInputChange={(_, v) => handleFilterChange("jobNo", v || "")}
                renderInput={(p) => <TextField {...p} label="Job No" size="small" />}
                sx={{ width: 180 }}
              />
              <Autocomplete freeSolo options={uniqueJobNames}
                value={filters.jobName}
                onChange={(_, v) => handleFilterChange("jobName", v || "")}
                onInputChange={(_, v) => handleFilterChange("jobName", v || "")}
                renderInput={(p) => <TextField {...p} label="Job Name" size="small" />}
                sx={{ width: 220 }}
              />
              <Autocomplete freeSolo options={uniqueVendorNames}
                value={filters.vendorName}
                onChange={(_, v) => handleFilterChange("vendorName", v || "")}
                onInputChange={(_, v) => handleFilterChange("vendorName", v || "")}
                renderInput={(p) => <TextField {...p} label="Vendor Name" size="small" />}
                sx={{ width: 220 }}
              />
              <Autocomplete freeSolo options={uniqueStatuses}
                value={filters.status}
                onChange={(_, v) => handleFilterChange("status", v || "")}
                onInputChange={(_, v) => handleFilterChange("status", v || "")}
                renderInput={(p) => <TextField {...p} label="Status" size="small" />}
                sx={{ width: 180 }}
              />
              <TextField label="From Date" type="date" size="small" InputLabelProps={{ shrink: true }} value={filters.fromDate} onChange={(e) => handleFilterChange("fromDate", e.target.value)} sx={{ width: 160 }} />
              <TextField label="To Date" type="date" size="small" InputLabelProps={{ shrink: true }} value={filters.toDate} onChange={(e) => handleFilterChange("toDate", e.target.value)} sx={{ width: 160 }} />
              <Button size="small" color="error" onClick={clearFilters} title="Clear all filters"><RotateCcw size={22} strokeWidth={3} /></Button>
            </Stack>
          </Box>
        )}

        {/* Table */}
        <TableContainer sx={{ maxHeight: "75vh", overflow: "auto", "&::-webkit-scrollbar": { display: "none" }, scrollbarWidth: "none", msOverflowStyle: "none" }}>
          <Table size="small" stickyHeader sx={{ borderCollapse: "separate" }}>
            <TableHead>
              {/* Row 1 – group headers */}
              <TableRow ref={row1Ref}>
                <TableCell colSpan={baseColSpan} sx={{ bgcolor: "#f8fafc", borderBottom: "2px solid #cbd5e1", position: "sticky", top: 0, zIndex: 4 }} />
                {STEPS.map((step) => !visibleColumns[step.id] ? null : (
                  <TableCell key={step.id} colSpan={step.cols.length} align="center" sx={{
                    bgcolor: step.bgColor,
                    fontWeight: 700,
                    borderRight: "2px solid #cbd5e1",
                    borderBottom: "2px solid #cbd5e1",
                    padding: "10px 4px",
                    position: "sticky",
                    top: 0,
                    zIndex: 4,
                    boxShadow: "inset 0 -2px 0 rgba(0,0,0,0.02)"
                  }}>
                    <Typography variant="caption" sx={{ fontWeight: 900, color: "#0f766e", display: "block", fontSize: "0.6rem", mb: 0.5, letterSpacing: 0.5 }}>{step.label.toUpperCase()}</Typography>
                    <Stack direction="row" alignItems="center" justifyContent="center" spacing={0.5}>
                      <span style={{ fontSize: "1.1rem" }}>{step.icon}</span>
                      <Typography variant="caption" sx={{ fontWeight: 800, fontSize: "0.72rem", color: "#1e293b", letterSpacing: 0.2 }}>{step.name}</Typography>
                    </Stack>
                  </TableCell>
                ))}
              </TableRow>

              {/* Row 2 – column headers */}
              <TableRow>
                <TableCell padding="checkbox" sx={{ bgcolor: "#f1f5f9", minWidth: colWidths.checkbox, maxWidth: colWidths.checkbox, borderRight: "1px solid #e0e0e0", position: "sticky", top: row1Height, zIndex: 3 }}>
                  <Box sx={{ position: "relative", width: "100%", height: "100%" }}>
                    <Checkbox size="small" color="primary" onChange={handleSelectAll} checked={selected.length === filteredRows.length && filteredRows.length > 0} />
                    <ColumnResizer columnKey="checkbox" resizeRef={resizeRef} forceUpdate={forceUpdate} />
                  </Box>
                </TableCell>
                {STEPS.map((step) => !visibleColumns[step.id] ? null : (
                  <React.Fragment key={step.id}>
                    {step.cols.map((col, idx) => {
                      const ck = `${col.key}-${step.id}`;
                      const isLast = idx === step.cols.length - 1;
                      return (
                        <TableCell key={ck} sx={{
                          bgcolor: step.bgColor,
                          minWidth: colWidths[ck],
                          maxWidth: colWidths[ck],
                          fontWeight: 700,
                          fontSize: "0.68rem",
                          color: "#334155",
                          borderRight: isLast ? "2px solid #cbd5e1" : "1px solid rgba(0,0,0,0.05)",
                          position: "sticky",
                          top: row1Height,
                          zIndex: 3,
                          textTransform: "uppercase",
                          letterSpacing: 0.3
                        }}>
                          <Box sx={{ position: "relative", width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: col.key === "delay" || col.key === "status" ? "center" : "flex-start" }}>
                            {col.label}
                            <ColumnResizer columnKey={ck} resizeRef={resizeRef} forceUpdate={forceUpdate} />
                          </Box>
                        </TableCell>
                      );
                    })}
                  </React.Fragment>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={100} align="center" sx={{ py: 6 }} />
                </TableRow>
              ) : rowCount === 0 ? (
                <TableRow>
                  <TableCell colSpan={100} align="center" sx={{ py: 6, color: "#94a3b8", fontSize: "0.85rem" }}>
                    No records found
                  </TableCell>
                </TableRow>
              ) : (
                Array.from({ length: rowCount }).map((_, i) => {
                  const row = filteredRows[i] ?? {};
                  const isSel = selected.includes(i);
                  const rowBg = isSel ? "#e0f2fe" : i % 2 === 0 ? "#ffffff" : "#f8fafc";

                  return (
                    <TableRow key={i} hover>
                      <TableCell padding="checkbox" sx={{ bgcolor: rowBg, minWidth: colWidths.checkbox }}>
                        <Checkbox size="small" checked={isSel} onChange={() => handleSelectRow(i)} />
                      </TableCell>
                      {STEPS.map((step) => !visibleColumns[step.id] ? null : (
                        <React.Fragment key={step.id}>
                          {step.cols.map((col, idx) => {
                            const stepRow = (stepData[step.id] ?? [])[i] ?? {};
                            const isLast = idx === step.cols.length - 1;
                            return renderStepCell({ ...step, isLast }, col, stepRow);
                          })}
                        </React.Fragment>
                      ))}
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Snackbar open={snackbar.open} autoHideDuration={3000} onClose={() => setSnackbar((p) => ({ ...p, open: false }))} anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert severity={snackbar.severity} variant="filled" sx={{ width: '100%' }}>{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default RawMaterialPurchaseFMS;