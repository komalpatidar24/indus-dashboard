import { useState, useEffect, useMemo } from 'react';
import {
  Plus,
  ChevronDown,
  ChevronUp,
  Info,
  RefreshCw,
  FileText,
  Search,
  Filter,
  Download,
  Trash2,
  X,
  RotateCcw,
  MessageSquare
} from 'lucide-react';
import {
  Typography,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box
} from '@mui/material';
import { postRequest } from '../api/api';
import * as XLSX from 'xlsx';

const UserDashboard = () => {
  const [selectedFilter, setSelectedFilter] = useState('Checklist Tasks');
  const [showTodayOnly, setShowTodayOnly] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedTasks, setSelectedTasks] = useState([]);
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [currentTaskId, setCurrentTaskId] = useState(null);
  const [activeTaskType, setActiveTaskType] = useState(null);
  const [completionNote, setCompletionNote] = useState('');
  const [filters, setFilters] = useState({
    taskDate: '',
    taskCode: '',
    assignedBy: '',
    taskTitle: '',
    status: '',
    priority: ''
  });
  const [tasks, setTasks] = useState([]);
  const [delegationTasks, setDelegationTasks] = useState([]);
  const [fmsTasks, setFmsTasks] = useState([]);
  const taskCategories = [
    { name: 'Checklist Tasks', color: 'bg-gradient-to-r from-emerald-500 to-teal-500', icon: '✓' },
    { name: 'Delegation Tasks', color: 'bg-gradient-to-r from-blue-400 to-blue-500', icon: '👥' },
    { name: 'FMS Tasks', color: 'bg-gradient-to-r from-cyan-400 to-blue-400', icon: '📋' }
  ];

  const statsData = useMemo(() => {
    const checklistPending = tasks.filter(t => t.status !== 'Completed').length;
    const checklistCompleted = tasks.filter(t => t.status === 'Completed').length;
    const delegationPending = delegationTasks.filter(t => t.status !== 'Done').length;
    const delegationCompleted = delegationTasks.filter(t => t.status === 'Done').length;
    const fmsPending = fmsTasks.filter(t => t.status !== 'Completed').length;
    const totalWork = tasks.length + delegationTasks.length + fmsTasks.length;
    const totalCompleted = checklistCompleted + delegationCompleted + fmsTasks.filter(t => t.status === 'Completed').length;
    const totalPending = totalWork - totalCompleted;
    const completionPercentage = totalWork > 0 ? Math.round((totalCompleted / totalWork) * 100) : 0;

    return {
      weekScore: {
        noOfWork: { previous: 0, current: totalWork },
        workDone: { previous: 0, current: totalCompleted },
        pending: { previous: 0, current: totalPending }
      },
      pendingTask: {
        checklist: checklistPending,
        delegation: delegationPending,
        fms: fmsPending
      },
      completionPercentage: completionPercentage,
      totalCompleted: totalCompleted,
      totalPending: totalPending
    };
  }, [tasks, delegationTasks, fmsTasks]);

  const getLoggedInUser = () => {
    const userId = localStorage.getItem('userid') || '0';
    const userName = localStorage.getItem('username') || 'Admin';
    return { userId, userName };
  };

  const fetchChecklistTasks = async () => {
    setLoading(true);
    try {
      const user = getLoggedInUser();
      const response = await postRequest("GetUserChecklist", {
        userName: user.userName
        // userName: 'Vishnu'

      });
      if (response) {
        const parsedData = typeof response === 'string' ? JSON.parse(response) : response;
        const tasksData = parsedData.data || parsedData;
        if (Array.isArray(tasksData) && tasksData.length > 0) {
          const transformedTasks = tasksData.map((task, index) => {
            const isCompleted = task.IsDone == true || task.IsDone == 1;
            const plannedDate = task.CreatedDate ? new Date(task.CreatedDate) : null;
            const currentDate = new Date();

            let delayDays = 0;
            let delayText = '0 day';
            let displayStatus = task.Status || 'Pending';

            if (isCompleted) {
              displayStatus = 'Completed';
              delayText = '0 day';
            } else {
              if (plannedDate) {
                const plannedDateOnly = new Date(plannedDate.getFullYear(), plannedDate.getMonth(), plannedDate.getDate());
                const currentDateOnly = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());

                const timeDiff = currentDateOnly - plannedDateOnly;
                delayDays = Math.floor(timeDiff / (1000 * 60 * 60 * 24));

                if (delayDays > 0) {
                  displayStatus = 'Delay';
                  delayText = `${delayDays} day${delayDays !== 1 ? 's' : ''}`;
                } else {
                  displayStatus = 'Pending';
                  delayText = '0 day';
                }
              } else {
                displayStatus = 'Pending';
                delayText = '0 day';
              }
            }

            return {
              id: task.TaskID || task.taskid || null,
              taskCode: task.TaskPrefix || null,
              taskTitle: task.TaskTitle || null,
              message: task.ProcessTaskDetails || null,
              assignedBy: task.CreatedBy ? String(task.CreatedBy) : null,
              assignedTo: task.AssignedToPerson || null,
              department: task.Department || null,
              plannedDate: task.CreatedDate ? formatDate(task.CreatedDate) : null,
              plannedTime: task.CreatedDate ? formatTime(task.CreatedDate) : null,
              completedDate: task.CompletedDates ? formatDate(task.CompletedDates) : null,
              status: displayStatus,
              isCompleted: isCompleted || task.IsDone === true,
              isDone: task.IsDone || false,
              delay: delayText,
              delayDays: delayDays,
              priority: task.Priority?.toLowerCase() || null,
              notes: task.Notes || null,
              delayReason: task.DelayReason || null
            };
          });
          setTasks(transformedTasks);
        } else {
          setTasks([]);
        }
      } else {
        setTasks([]);
      }
    } catch (error) {
      console.error('Error fetching checklist tasks:', error);
      alert('Failed to fetch checklist tasks. Please try again.');
      setTasks([]);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const day = date.getDate();
    const month = date.toLocaleString('en-US', { month: 'short' });
    const year = date.getFullYear();
    return `${day} ${month}, ${year}`;
  };

  const todayStr = formatDate(new Date());
  const formatTime = (timeString) => {
    if (!timeString) return '';
    const date = new Date(timeString);
    let hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')} ${ampm}`;
  };

  useEffect(() => {
    fetchChecklistTasks();
    fetchDelegationTasks();
  }, []);

  const fetchDelegationTasks = async () => {
    setLoading(true);
    try {
      const user = getLoggedInUser();
      const response = await postRequest("GetDelegationTasks", { 
        // userName: user.userName
        userName: 'Vishnu'
       });
      const tasksData = response?.data || response || [];
      if (Array.isArray(tasksData)) {
        const transformed = tasksData.map((task, index) => {
          const isCompleted = task.IsCompleted === true;
          const plannedDate = task.PlannedDate ? new Date(task.PlannedDate) : null;
          const currentDate = new Date();

          let delayDays = 0;
          let delayText = '0 day';
          let displayStatus = 'Pending';

          if (isCompleted) {
            displayStatus = 'Done';
            delayText = '0 day';
          } else {
            displayStatus = 'Pending';
            if (plannedDate) {
              const plannedDateOnly = new Date(plannedDate.getFullYear(), plannedDate.getMonth(), plannedDate.getDate());
              const currentDateOnly = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());

              const timeDiff = currentDateOnly - plannedDateOnly;
              delayDays = Math.floor(timeDiff / (1000 * 60 * 60 * 24));

              if (delayDays > 0) {
                displayStatus = 'Delay';
                delayText = `${delayDays} day${delayDays !== 1 ? 's' : ''}`;
              } else {
                delayText = '0 day';
              }
            }
          }

          return {
            id: task.TaskID || task.taskid || task.DelegationID || null,
            taskCode: task.TaskCode || null,
            taskTitle: task.DelegationName || null,
            message: task.Description || null,
            assignedBy: task.CreatedBy || null,
            delegatedTo: task.DelegatedTo || task.AssignTo || null,
            plannedDate: task.PlannedDate ? formatDate(task.PlannedDate) : null,
            plannedTime: task.PlannedDate ? formatTime(task.PlannedDate) : null,
            status: displayStatus,
            isCompleted: isCompleted,
            delay: delayText,
            delayDays: delayDays,
            priority: task.Priority?.toLowerCase() || null,
            notes: task.CompletedMessage || null
          };
        });
        setDelegationTasks(transformed);
      }
    } catch (error) {
      console.error('Delegation Error:', error);
      setDelegationTasks([]);
    }
    finally { setLoading(false); }
  };

  const handleComplete = async (taskId, type = 'checklist') => {
    setCurrentTaskId(taskId);
    setActiveTaskType(type);
    setCompletionNote('');
    setNoteDialogOpen(true);
  };

  const handleCompleteWithNote = async () => {
    try {
      setLoading(true);
      const user = getLoggedInUser();
      let response;

      if (activeTaskType === 'checklist') {
        response = await postRequest("UpdateTaskStatus", {
          taskId: currentTaskId,
          status: 'Completed',
          isDone: true,
          modifiedBy: user.userId,
          notes: completionNote.trim()
        });
      } else {
        response = await postRequest("UpdateDelegationStatus", {
          DelegationID: currentTaskId,
          IsCompleted: true,
          ModifyBy: user.userId,
          CompletedMessage: completionNote.trim()
        });
      }

      if (response && response.success) {
        setNoteDialogOpen(false);
        setCompletionNote('');
        setCurrentTaskId(null);
        setActiveTaskType(null);
        if (activeTaskType === 'checklist') {
          await fetchChecklistTasks();
        } else {
          await fetchDelegationTasks();
        }
      } else {
        alert('Failed to update task status');
      }
    } catch (error) {
      console.error('Error updating task status:', error);
      alert('Error updating task status');
    } finally {
      setLoading(false);
    }
  };

  const handleCancelNote = () => {
    setNoteDialogOpen(false);
    setCompletionNote('');
    setCurrentTaskId(null);
    setActiveTaskType(null);
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const resetFilters = () => {
    setFilters({
      taskDate: '',
      taskCode: '',
      assignedBy: '',
      taskTitle: '',
      status: '',
      priority: ''
    });
    setSearchQuery('');
  };

  const handleRefresh = () => {
      fetchChecklistTasks();
      fetchDelegationTasks();
    setSelectedTasks([]);
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'border-l-4 border-red-500';
      case 'medium': return 'border-l-4 border-yellow-500';
      case 'low': return 'border-l-4 border-green-500';
      default: return 'border-l-4 border-gray-500';
    }
  };

  const handleSelectAll = (e) => {
    if (e.target.checked) {
      const currentTasks = selectedFilter === 'Checklist Tasks' ? filteredTasks : filteredDelegationTasks;
      setSelectedTasks(currentTasks.map(t => t.id));
    } else {
      setSelectedTasks([]);
    }
  };

  const handleSelectTask = (taskId) => {
    setSelectedTasks(prev =>
      prev.includes(taskId) ? prev.filter(id => id !== taskId) : [...prev, taskId]
    );
  };

  const handleExport = () => {
    try {
      const currentTasks = selectedFilter === 'Checklist Tasks' ? filteredTasks : filteredDelegationTasks;
      const dataToExport = selectedTasks.length > 0
        ? currentTasks.filter(t => selectedTasks.includes(t.id))
        : currentTasks;

      if (dataToExport.length === 0) {
        alert('No tasks to export');
        return;
      }

      const exportData = dataToExport.map(task => ({
        'Task Code': task.taskCode || '-',
        'Task Title': task.taskTitle,
        'Message': task.message,
        'Assigned By': task.assignedBy,
        'Delegated To': task.delegatedTo || '-',
        'Planned Date': task.plannedDate,
        'Planned Time': task.plannedTime,
        'Status': task.status,
        'Delay': task.delay,
        'Priority': task.priority
      }));

      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, selectedFilter.replace(' ', '_'));
      XLSX.writeFile(wb, `${selectedFilter.replace(' ', '_')}_${new Date().toISOString().split('T')[0]}.xlsx`);

      alert('Tasks exported successfully');
    } catch (error) {
      console.error('Export error:', error);
      alert('Failed to export tasks');
    }
  };

  const handleDelete = async () => {
    if (selectedTasks.length === 0) {
      alert('Please select tasks to delete');
      return;
    }

    if (!window.confirm(`Are you sure you want to delete ${selectedTasks.length} task(s)?`)) {
      return;
    }

    setLoading(true);
    try {
      if (selectedFilter === 'Checklist Tasks') {
        await postRequest("DeleteChecklist", {
          taskIds: selectedTasks
        });
        setTasks(tasks.filter(t => !selectedTasks.includes(t.id)));
        alert('Checklist tasks deleted successfully');
      } else if (selectedFilter === 'Delegation Tasks') {
        await postRequest("DeleteDelegation", {
          taskIds: selectedTasks
        });
        setDelegationTasks(delegationTasks.filter(t => !selectedTasks.includes(t.id)));
        alert('Delegation tasks deleted successfully');
      }
      setSelectedTasks([]);
    } catch (error) {
      console.error('Delete error:', error);
      alert('Failed to delete tasks');
    } finally {
      setLoading(false);
    }
  };

  const filteredTasks = tasks.filter(task => {
    if (showTodayOnly && task.plannedDate !== todayStr) return false;
    if (searchQuery && !task.taskTitle.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !task.taskCode.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !task.assignedBy.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    if (filters.taskCode && !task.taskCode.toLowerCase().includes(filters.taskCode.toLowerCase())) return false;
    if (filters.assignedBy && !task.assignedBy.toLowerCase().includes(filters.assignedBy.toLowerCase())) return false;
    if (filters.taskTitle && !task.taskTitle.toLowerCase().includes(filters.taskTitle.toLowerCase())) return false;
    if (filters.status && task.status !== filters.status) return false;
    if (filters.priority && task.priority !== filters.priority) return false;
    return true;
  });

  const filteredDelegationTasks = delegationTasks.filter(task => {
    if (showTodayOnly && task.plannedDate !== todayStr) return false;
    if (searchQuery && !task.taskTitle.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !task.taskCode.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !task.assignedBy.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    if (filters.taskCode && !task.taskCode.toLowerCase().includes(filters.taskCode.toLowerCase())) return false;
    if (filters.assignedBy && !task.assignedBy.toLowerCase().includes(filters.assignedBy.toLowerCase())) return false;
    if (filters.taskTitle && !task.taskTitle.toLowerCase().includes(filters.taskTitle.toLowerCase())) return false;
    if (filters.status && task.status !== filters.status) return false;
    if (filters.priority && task.priority !== filters.priority) return false;
    return true;
  });

  const filteredFmsTasks = fmsTasks.filter(task => {
    if (searchQuery && !task.taskTitle.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !task.taskCode.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !task.assignedBy.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    if (filters.taskCode && !task.taskCode.toLowerCase().includes(filters.taskCode.toLowerCase())) return false;
    if (filters.assignedBy && !task.assignedBy.toLowerCase().includes(filters.assignedBy.toLowerCase())) return false;
    if (filters.taskTitle && !task.taskTitle.toLowerCase().includes(filters.taskTitle.toLowerCase())) return false;
    if (filters.status && task.status !== filters.status) return false;
    if (filters.priority && task.priority !== filters.priority) return false;
    return true;
  });

  return (
    <div className="flex h-screen bg-gray-100">
      {loading && (
        <div className="fixed inset-0 bg-white bg-opacity-15 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 flex flex-col items-center gap-3 shadow-lg">
            <CircularProgress size={40} thickness={4} sx={{ color: '#0f766e' }} />
            <Typography variant="body2" sx={{ fontWeight: 600, color: '#0f766e' }}>
              Loading...
            </Typography>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-auto">
        <div className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
          <Typography variant="caption" sx={{ display: 'block', textAlign: 'center', letterSpacing: 4, fontWeight: 700, color: 'text.secondary', mb: 3 }}>
            USER DASHBOARD - FMS
          </Typography>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-lg font-bold text-gray-800 mb-3">Week Score</h3>
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>Previous</span>
                <span>Current</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">No of Work</span>
                  <div className="flex gap-8">
                    <span className="font-semibold">{statsData.weekScore.noOfWork.previous}</span>
                    <span className="font-semibold text-emerald-600">{statsData.weekScore.noOfWork.current}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Work Done</span>
                  <div className="flex gap-8">
                    <span className="font-semibold">{statsData.weekScore.workDone.previous}</span>
                    <span className="font-semibold text-emerald-600">{statsData.weekScore.workDone.current}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Pending</span>
                  <div className="flex gap-8">
                    <span className="font-semibold">{statsData.weekScore.pending.previous}</span>
                    <span className="font-semibold text-emerald-600">{statsData.weekScore.pending.current}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-lg font-bold text-gray-800 mb-3">Pending Task</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Checklist</span>
                  <div className="flex gap-8">
                    <span className="font-semibold text-emerald-600">{statsData.pendingTask.checklist}</span>
                    <span className="text-sm text-gray-600">Delegation</span>
                    <span className="font-semibold">{statsData.pendingTask.delegation}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">FMS</span>
                  <div className="flex gap-0">
                    <span className="font-semibold">{statsData.pendingTask.fms}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-bold text-gray-800">Weekly Task Chart</h3>
              </div>
              <div className="flex items-center justify-center h-32">
                <div className="relative w-24 h-24">
                  <svg className="w-full h-full" viewBox="0 0 100 100">
                    <circle
                      cx="50" cy="50" r="40"
                      fill="none"
                      stroke="#fbbf24"
                      strokeWidth="20"
                      strokeDasharray={`${100 - statsData.completionPercentage} 251`}
                      transform="rotate(-90 50 50)"
                    />
                    <circle
                      cx="50" cy="50" r="40"
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="20"
                      strokeDasharray={`${statsData.completionPercentage} 251`}
                      strokeDashoffset={`-${100 - statsData.completionPercentage}`}
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-lg font-bold text-gray-800">{statsData.completionPercentage}%</span>
                  </div>
                </div>
              </div>
              <div className="flex justify-center gap-4 mt-2">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-emerald-500 rounded"></div>
                  <span className="text-xs text-gray-600">Complete ({statsData.totalCompleted})</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-400 rounded"></div>
                  <span className="text-xs text-gray-600">Pending ({statsData.totalPending})</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 mb-6">
            {taskCategories.map((category) => (
              <button
                key={category.name}
                onClick={() => {
                  setSelectedFilter(category.name);
                  setSelectedTasks([]);
                }}
                className={`${category.color} text-white px-6 py-2.5 rounded-lg font-medium hover:opacity-90 transition shadow-md ${selectedFilter === category.name ? 'ring-2 ring-offset-2 ring-emerald-400' : ''
                  }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow p-4 mb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className={`p-2 rounded-lg transition ${showFilters ? 'bg-emerald-100 text-emerald-600' : 'text-gray-600 hover:bg-gray-100'}`}
                >
                  <Filter className="w-5 h-5" />
                </button>
                <div className="relative flex-1 min-w-[300px]">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search tasks..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  />
                  <Search className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">All</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showTodayOnly}
                      onChange={(e) => setShowTodayOnly(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                  <span className="text-sm text-gray-600">Today Only</span>
                </div>

                <button
                  onClick={handleExport}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition"
                >
                  <Download className="w-4 h-4" />
                  EXPORT
                </button>

                <button
                  onClick={handleDelete}
                  disabled={selectedTasks.length === 0}
                  className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-medium hover:bg-red-600 transition disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  <Trash2 className="w-4 h-4" />
                  DELETE ({selectedTasks.length})
                </button>
              </div>
            </div>

            {showFilters && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="grid grid-cols-6 gap-3 items-end">
                  <div className="relative">
                    <label className="block text-xs font-medium text-gray-600 mb-1">Task Date</label>
                    <input
                      type="date"
                      value={filters.taskDate}
                      onChange={(e) => handleFilterChange('taskDate', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Assigned By</label>
                    <input
                      type="text"
                      value={filters.assignedBy}
                      onChange={(e) => handleFilterChange('assignedBy', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                      placeholder="Name"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Task Title</label>
                    <div className="relative">
                      <input
                        type="text"
                        value={filters.taskTitle}
                        onChange={(e) => handleFilterChange('taskTitle', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent pr-8"
                        placeholder="Title"
                      />
                      <ChevronDown className="w-4 h-4 text-gray-400 absolute right-2 top-3" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Status</label>
                    <div className="relative">
                      <select
                        value={filters.status}
                        onChange={(e) => handleFilterChange('status', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent appearance-none pr-8"
                      >
                        <option value="">All</option>
                        <option value="Pending">Pending</option>
                        <option value="Completed">Completed</option>
                        <option value="Delay">Delay</option>
                      </select>
                      <ChevronDown className="w-4 h-4 text-gray-400 absolute right-2 top-3 pointer-events-none" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Priority</label>
                    <div className="relative">
                      <select
                        value={filters.priority}
                        onChange={(e) => handleFilterChange('priority', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent appearance-none pr-8"
                      >
                        <option value="">All</option>
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option>
                      </select>
                      <ChevronDown className="w-4 h-4 text-gray-400 absolute right-2 top-3 pointer-events-none" />
                    </div>
                  </div>

                  <div className="flex justify-end pb-0.5">
                    <button
                      onClick={resetFilters}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition flex items-center justify-center"
                      title="Reset Filters"
                    >
                      <RotateCcw size={22} strokeWidth={2.5} />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {selectedFilter === 'Checklist Tasks' && (
            <div className="bg-white rounded-lg shadow">
              <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-800">CHECKLIST TASKS</h2>
                <div className="flex gap-2">
                  <button
                    onClick={handleRefresh}
                    className="p-2 text-emerald-500 hover:bg-emerald-50 rounded-lg transition"
                    disabled={loading}
                  >
                    <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>

              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <RefreshCw className="w-8 h-8 text-emerald-500 animate-spin mx-auto mb-2" />
                    <p className="text-gray-600">Loading tasks...</p>
                  </div>
                </div>
              ) : filteredTasks.length === 0 ? (
                <div className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">No checklist tasks found</p>
                  </div>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-200">
                        <th className="px-4 py-3 text-left">
                          <input
                            type="checkbox"
                            onChange={handleSelectAll}
                            checked={selectedTasks.length === filteredTasks.length && filteredTasks.length > 0}
                            className="w-4 h-4 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500"
                          />
                        </th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Task Title</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Message</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Assigned By</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Planned Date</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Status</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Delay</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Notes</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {filteredTasks.map((task) => (
                        <tr key={task.id} className={`hover:bg-gray-50 transition ${getPriorityColor(task.priority)}`}>
                          <td className="px-4 py-4">
                            <input
                              type="checkbox"
                              checked={selectedTasks.includes(task.id)}
                              onChange={() => handleSelectTask(task.id)}
                              className="w-4 h-4 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500"
                            />
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900 font-medium">{task.taskTitle || '-'}</td>
                          <td className="px-4 py-4">
                            <div className="flex items-center gap-2">
                              {task.message ? (
                                <>
                                  <span className="text-sm text-gray-600 truncate max-w-[200px]" title="">
                                    {task.message}
                                  </span>
                                  <div className="relative group">
                                    <Info className="w-4 h-4 text-gray-400 cursor-pointer hover:text-emerald-600 flex-shrink-0" />
                                    <div className="absolute bottom-full left-0 mb-3 w-80 bg-white border border-gray-200 rounded-lg shadow-2xl p-4 z-[9999] hidden group-hover:block pointer-events-none">
                                      <div className="text-sm text-gray-700 whitespace-pre-wrap break-words leading-relaxed">
                                        {task.message}
                                      </div>
                                      <div className="absolute -bottom-2 left-3 w-0 h-0 border-l-[8px] border-r-[8px] border-t-[8px] border-transparent border-t-white"></div>
                                    </div>
                                  </div>
                                </>
                              ) : (
                                <span className="text-sm text-gray-400">-</span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900">{task.assignedBy || '-'}</td>
                          <td className="px-4 py-4">
                            <div className="text-sm text-gray-900">{task.plannedDate || '-'}</div>
                            <div className="text-xs text-gray-500">{task.plannedTime || '-'}</div>
                          </td>
                          <td className="px-4 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${task.status === 'Completed'
                              ? 'bg-emerald-100 text-emerald-700'
                              : task.status === 'Delay'
                                ? 'bg-red-100 text-red-700'
                                : 'bg-yellow-100 text-yellow-700'
                              }`}>
                              {task.status}
                            </span>
                          </td>
                          <td className="px-4 py-4">
                            <span className={`text-sm font-medium ${task.delay === '0 day' || task.status === 'Completed'
                              ? 'text-gray-600'
                              : 'text-red-600 font-bold'
                              }`}>
                              {task.delay}
                            </span>
                          </td>
                          <td className="px-4 py-4">
                            <div className="flex items-center justify-center">
                              <div className="relative group">
                                <MessageSquare
                                  className={`w-5 h-5 cursor-pointer transition ${task.notes ? 'text-emerald-600 fill-emerald-100' : 'text-gray-300'}`}
                                />
                                {task.notes && (
                                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 bg-white border border-gray-200 p-3 rounded-lg shadow-xl z-50 hidden group-hover:block pointer-events-none">
                                    <p className="text-xs font-bold text-emerald-600 mb-1">Note:</p>
                                    <p className="text-sm text-gray-700 whitespace-pre-wrap break-words">{task.notes}</p>
                                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-8 border-r-8 border-t-8 border-transparent border-t-white"></div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-4">
                            {task.status !== 'Completed' ? (
                              <button
                                onClick={() => handleComplete(task.id, 'checklist')}
                                className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-4 py-1.5 rounded text-sm font-medium hover:from-emerald-600 hover:to-teal-600 transition"
                              >
                                COMPLETE
                              </button>
                            ) : (
                              <span className="text-emerald-600 font-medium text-sm">✓ Done</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {!loading && (
                <div className="p-4 border-t border-gray-200 text-sm text-gray-600">
                  Showing {filteredTasks.length} of {tasks.length} tasks
                  {selectedTasks.length > 0 && ` | ${selectedTasks.length} selected`}
                </div>
              )}
            </div>
          )}

          {selectedFilter === 'Delegation Tasks' && (
            <div className="bg-white rounded-lg shadow">
              <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-800">DELEGATION TASKS</h2>
                <div className="flex gap-2">
                  <button
                    onClick={handleRefresh}
                    className="p-2 text-emerald-500 hover:bg-emerald-50 rounded-lg transition"
                    disabled={loading}
                  >
                    <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      <th className="px-4 py-3 text-left">
                        <input
                          type="checkbox"
                          onChange={handleSelectAll}
                          checked={selectedTasks.length === filteredDelegationTasks.length && filteredDelegationTasks.length > 0}
                          className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                      </th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Task Title</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Message</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Assigned By</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Delegated To</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Planned Date</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Status</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Delay</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Notes</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filteredDelegationTasks.map((task) => (
                      <tr key={task.id} className={`hover:bg-gray-50 transition ${getPriorityColor(task.priority)}`}>
                        <td className="px-4 py-4">
                          <input
                            type="checkbox"
                            checked={selectedTasks.includes(task.id)}
                            onChange={() => handleSelectTask(task.id)}
                            className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                          />
                        </td>
                        <td className="px-4 py-4 text-sm text-gray-900 font-medium">{task.taskTitle || '-'}</td>
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-2">
                            {task.message ? (
                              <>
                                <span className="text-sm text-gray-600 truncate max-w-[200px]" title="">
                                  {task.message}
                                </span>
                                <div className="relative group">
                                  <Info className="w-4 h-4 text-gray-400 cursor-pointer hover:text-emerald-600 flex-shrink-0" />
                                  <div className="absolute bottom-full left-0 mb-3 w-80 bg-white border border-gray-200 rounded-lg shadow-2xl p-4 z-[9999] hidden group-hover:block pointer-events-none">
                                    <div className="text-sm text-gray-700 whitespace-pre-wrap break-words leading-relaxed">
                                      {task.message}
                                    </div>
                                    <div className="absolute -bottom-2 left-3 w-0 h-0 border-l-[8px] border-r-[8px] border-t-[8px] border-transparent border-t-white"></div>
                                  </div>
                                </div>
                              </>
                            ) : (
                              <span className="text-sm text-gray-400">-</span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-sm text-gray-900">{task.assignedBy || '-'}</td>
                        <td className="px-4 py-4 text-sm text-gray-900 font-medium">{task.delegatedTo || '-'}</td>
                        <td className="px-4 py-4">
                          <div className="text-sm text-gray-900">{task.plannedDate || '-'}</div>
                          <div className="text-xs text-gray-500">{task.plannedTime || '-'}</div>
                        </td>
                        <td className="px-4 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${task.status === 'Done'
                            ? 'bg-emerald-100 text-emerald-700'
                            : task.status === 'Delay'
                              ? 'bg-red-100 text-red-700'
                              : 'bg-yellow-100 text-yellow-700'
                            }`}>
                            {task.status}
                          </span>
                        </td>
                        <td className="px-4 py-4">
                          <span className={`text-sm font-medium ${task.delay === '0 day' || task.status === 'Done'
                            ? 'text-gray-600'
                            : 'text-red-600 font-bold'
                            }`}>
                            {task.delay}
                          </span>
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center justify-center">
                            <div className="relative group">
                              <MessageSquare
                                className={`w-5 h-5 cursor-pointer transition ${task.notes ? 'text-blue-600 fill-blue-100' : 'text-gray-300'}`}
                              />
                              {task.notes && (
                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 bg-white border border-gray-200 p-3 rounded-lg shadow-xl z-50 hidden group-hover:block pointer-events-none">
                                  <p className="text-xs font-bold text-blue-600 mb-1">Note:</p>
                                  <p className="text-sm text-gray-700 whitespace-pre-wrap break-words">{task.notes}</p>
                                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-8 border-r-8 border-t-8 border-transparent border-t-white"></div>
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          {task.status !== 'Done' ? (
                            <button
                              onClick={() => handleComplete(task.id, 'delegation')}
                              className="bg-gradient-to-r from-blue-400 to-blue-500 text-white px-4 py-1.5 rounded text-sm font-medium hover:from-blue-500 hover:to-blue-600 transition"
                            >
                              COMPLETE
                            </button>
                          ) : (
                            <span className="text-emerald-600 font-medium text-sm">✓ Done</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="p-4 border-t border-gray-200 text-sm text-gray-600">
                Showing {filteredDelegationTasks.length} of {delegationTasks.length} tasks
                {selectedTasks.length > 0 && ` | ${selectedTasks.length} selected`}
              </div>
            </div>
          )}

          {selectedFilter === 'FMS Tasks' && (
            <div className="bg-white rounded-lg shadow">
              <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-800">FMS TASKS</h2>
                <div className="flex gap-2">
                  <button className="p-2 text-emerald-500 hover:bg-emerald-50 rounded-lg transition">
                    <RefreshCw className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <FileText className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">FMS tasks coming soon</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <Dialog
        open={noteDialogOpen}
        onClose={handleCancelNote}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography >
            </Typography>
            <button
              onClick={handleCancelNote}
              className="text-gray-400 hover:text-gray-600 transition"
            >
              <X size={20} />
            </button>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 0 }}>

            <TextField
              fullWidth
              multiline
              rows={4}
              placeholder="Enter your completion note here..."
              value={completionNote}
              onChange={(e) => setCompletionNote(e.target.value)}
              variant="outlined"
              sx={{
                '& .MuiOutlinedInput-root': {
                  '&:hover fieldset': {
                    borderColor: '#0f766e',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: '#0f766e',
                  },
                }
              }}
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 2.5, gap: 1 }}>
          <Button
            onClick={handleCompleteWithNote}
            variant="contained"
            sx={{
              bgcolor: '#0f766e',
              '&:hover': {
                bgcolor: '#0d665f'
              }
            }}
          >
            Complete
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};
export default UserDashboard;